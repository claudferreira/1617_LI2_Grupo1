
          window.__NEXT_REGISTER_PAGE('/', function() {
            var comp = module.exports =
webpackJsonp([5],{

/***/ 1061:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 1062:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(799);


/***/ }),

/***/ 623:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initStore = exports.setConnectionStatus = exports.deleteUser = exports.setCurrentUser = exports.setUsers = exports.reducer = exports.actionTypes = undefined;

var _defineProperty2 = __webpack_require__(651);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _extends2 = __webpack_require__(93);

var _extends3 = _interopRequireDefault(_extends2);

var _assign = __webpack_require__(91);

var _assign2 = _interopRequireDefault(_assign);

var _redux = __webpack_require__(706);

var _reduxThunk = __webpack_require__(968);

var _reduxThunk2 = _interopRequireDefault(_reduxThunk);

var _omit = __webpack_require__(592);

var _omit2 = _interopRequireDefault(_omit);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var initialState = {
  users: null,
  currentUser: null,
  connection: {
    master: true,
    slave: true
  }
};

var actionTypes = exports.actionTypes = {
  SET_USERS: 'SET_USERS',
  SET_CURRENT_USER: 'SET_CURRENT_USER',
  DELETE_USER: 'DELETE_USER',

  SET_CONNECTION_STATUS: 'SET_CONNECTION_STATUS'
};

// REDUCERS
var reducer = exports.reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  var action = arguments[1];

  switch (action.type) {
    case actionTypes.SET_USERS:
      return (0, _assign2.default)({}, state, { users: action.payload });
    case actionTypes.SET_CURRENT_USER:
      return (0, _assign2.default)({}, state, { currentUser: action.payload });
    case actionTypes.DELETE_USER:
      return (0, _assign2.default)({}, state, { users: (0, _omit2.default)(state.users, [action.id]) });

    case actionTypes.SET_CONNECTION_STATUS:
      return (0, _assign2.default)({}, state, { connection: (0, _extends3.default)({}, state.connection, (0, _defineProperty3.default)({}, action.payload.type, action.payload.status)) });

    default:
      return state;
  }
};

// ACTIONS
var setUsers = exports.setUsers = function setUsers(payload) {
  return function (dispatch) {
    return dispatch({ type: actionTypes.SET_USERS, payload: payload });
  };
};
var setCurrentUser = exports.setCurrentUser = function setCurrentUser(payload) {
  return function (dispatch) {
    return dispatch({ type: actionTypes.SET_CURRENT_USER, payload: payload });
  };
};
var deleteUser = exports.deleteUser = function deleteUser(id) {
  return function (dispatch) {
    return dispatch({ type: actionTypes.DELETE_USER, id: id });
  };
};

var setConnectionStatus = exports.setConnectionStatus = function setConnectionStatus(type, status) {
  return function (dispatch) {
    return dispatch({
      type: actionTypes.SET_CONNECTION_STATUS,
      payload: { type: type, status: status }
    });
  };
};

var initStore = exports.initStore = function initStore() {
  var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;

  return (0, _redux.createStore)(reducer, initialState, (0, _redux.applyMiddleware)(_reduxThunk2.default));
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/helpers/store.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/helpers/store.js"); } } })();

/***/ }),

/***/ 799:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__resourceQuery) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__(93);

var _extends3 = _interopRequireDefault(_extends2);

var _objectWithoutProperties2 = __webpack_require__(579);

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _getPrototypeOf = __webpack_require__(36);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(39);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(38);

var _inherits3 = _interopRequireDefault(_inherits2);

var _keys = __webpack_require__(240);

var _keys2 = _interopRequireDefault(_keys);

var _style = __webpack_require__(578);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(10);

var _react2 = _interopRequireDefault(_react);

var _index = __webpack_require__(81);

var _index2 = _interopRequireDefault(_index);

var _nextReduxWrapper = __webpack_require__(697);

var _nextReduxWrapper2 = _interopRequireDefault(_nextReduxWrapper);

var _semanticUiReact = __webpack_require__(602);

var _layout = __webpack_require__(957);

var _layout2 = _interopRequireDefault(_layout);

var _trainingOverlay = __webpack_require__(958);

var _trainingOverlay2 = _interopRequireDefault(_trainingOverlay);

var _store = __webpack_require__(623);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var canvasSize = { width: 800, height: 600 };
var recognizingIntervalTimeout = 750;
var trainingPhotosCount = 30;

var hideMessageTimeout = void 0;
var lastUserId = function lastUserId(users) {
  return (0, _keys2.default)(users).map(function (id) {
    return parseInt(id);
  }).sort().pop() || 0;
};

var HomePage = function (_Component) {
  (0, _inherits3.default)(HomePage, _Component);

  function HomePage(props) {
    (0, _classCallCheck3.default)(this, HomePage);

    var _this = (0, _possibleConstructorReturn3.default)(this, (HomePage.__proto__ || (0, _getPrototypeOf2.default)(HomePage)).call(this, props));

    _this.onDismissMessage = function () {
      _this.setState({ savedUserName: null });
    };

    _this.handleFaceDetected = function (data) {
      var _this$props = _this.props,
          dispatch = _this$props.dispatch,
          users = _this$props.users,
          currentUser = _this$props.currentUser;
      var isTraining = _this.state.isTraining;

      var id = data.id,
          position = data.position,
          userData = (0, _objectWithoutProperties3.default)(data, ['id', 'position']);

      _this.clearFaceOverlay();

      if (isTraining) {
        return;
      }

      if (id) {
        if (currentUser && currentUser.id === id) {
          return;
        }

        _this.setState({ showAddUserButton: false });

        dispatch((0, _store.setCurrentUser)((0, _extends3.default)({ id: id }, userData)));

        window.socket.emit('update-settings', userData.settings);
      } else if (position) {
        _this.drawFaceOverlay(position);

        _this.setState({ showAddUserButton: true });
      }
    };

    _this.startDetecting = function () {
      _this.recognizingInterval = setInterval(function () {
        _this.videoContext.drawImage(_this.video, 0, 0, canvasSize.width, canvasSize.height);

        window.socket.emit('recognizeFace', _this.videoCanvas.toDataURL('image/jpeg', 1));
      }, recognizingIntervalTimeout);
    };

    _this.trainNewUser = function () {
      var users = _this.props.users;

      clearInterval(_this.recognizingInterval);
      clearInterval(_this.trainingInterval);

      _this.setState({
        showAddUserButton: false,
        trainingPhotoIndex: 0,
        isTraining: true
      });

      var newUserId = lastUserId(users) + 1;

      window.socket.emit('removeUser', newUserId);

      _this.trainingInterval = setInterval(function () {
        _this.setState({ trainingPhotoIndex: _this.state.trainingPhotoIndex + 1 }, function () {
          if (_this.state.trainingPhotoIndex >= trainingPhotosCount) {
            clearInterval(_this.trainingInterval);

            window.socket.emit('trainUser', newUserId);
          } else {
            _this.videoContext.drawImage(_this.video, 0, 0, canvasSize.width, canvasSize.height);

            window.socket.emit('saveUserPhoto', _this.videoCanvas.toDataURL('image/jpeg', 1), newUserId, _this.state.trainingPhotoIndex);
          }
        });
      }, 100);
    };

    _this.canceltraining = function () {
      var users = _this.props.users;

      clearInterval(_this.trainingInterval);

      var userId = lastUserId(users) + 1;

      window.socket.emit('removeUser', userId);

      _this.setState({ isTraining: false, trainingPhotoIndex: 0 });
      _this.startDetecting();
    };

    _this.handleUserTrainned = function (id) {
      _index2.default.push('/profile?id=' + id + '&isNew=1');
    };

    _this.state = {
      showAddUserButton: false,
      isTraining: false,
      percentage: 0,
      savedUserName: props.url.query.saved
    };
    return _this;
  }

  (0, _createClass3.default)(HomePage, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var _this2 = this;

      var isTraining = this.props.url.query.training !== undefined;
      var savedUserName = this.state.savedUserName;

      if (savedUserName) {
        hideMessageTimeout = setTimeout(this.onDismissMessage, 5000);
      }

      this.videoContext = this.videoCanvas.getContext('2d');

      this.overlayContext = this.overlayCanvas.getContext('2d');
      this.overlayContext.strokeStyle = 'rgb(0, 184, 174)';
      this.overlayContext.lineWidth = 4;
      this.overlayContext.lineCap = 'round';
      this.overlayContext.setLineDash([2, 15]);

      window.socket.on('faceDetected', this.handleFaceDetected);
      window.socket.on('userTrainned', this.handleUserTrainned);
      window.socket.on('start-training', function () {
        return _index2.default.push('/?training=1');
      });

      if (this.video && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true }).then(function (stream) {
          _this2.cameraStream = stream;
          _this2.video.src = window.URL.createObjectURL(_this2.cameraStream);

          _this2.video.play().then(function () {
            if (!isTraining) {
              _this2.startDetecting();
            } else {
              _this2.trainNewUser();
            }
          });
        });
      }
    }
  }, {
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {
      if (!this.props.url.query.training && nextProps.url.query.training) {
        this.trainNewUser();
      }
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      clearInterval(this.recognizingInterval);
      clearInterval(this.trainingInterval);
      clearTimeout(hideMessageTimeout);

      if (this.video) {
        this.video.pause();
        this.cameraStream.getTracks()[0].stop();
      }
    }
  }, {
    key: 'drawFaceOverlay',
    value: function drawFaceOverlay(_ref) {
      var x = _ref.x,
          y = _ref.y,
          width = _ref.width,
          height = _ref.height;

      this.overlayContext.beginPath();
      this.overlayContext.arc(x + width / 2, y + width / 2, width / 1.7, 0, Math.PI * 2, true);
      this.overlayContext.stroke();

      this.lastFacePosition = { x: x, y: y, width: width, height: height };
    }
  }, {
    key: 'clearFaceOverlay',
    value: function clearFaceOverlay() {
      if (this.lastFacePosition) {
        var _lastFacePosition = this.lastFacePosition,
            x = _lastFacePosition.x,
            y = _lastFacePosition.y,
            width = _lastFacePosition.width;

        this.overlayContext.clearRect(x - width / 2, y - width / 2, width * 2, width * 2);
      }
    }
  }, {
    key: 'render',
    value: function render() {
      var _this3 = this;

      var _state = this.state,
          savedUserName = _state.savedUserName,
          showAddUserButton = _state.showAddUserButton,
          isTraining = _state.isTraining,
          trainingPhotoIndex = _state.trainingPhotoIndex;

      return _react2.default.createElement(_layout2.default, { hideHeader: isTraining, hideFooter: isTraining }, savedUserName ? _react2.default.createElement(_semanticUiReact.Message, {
        onDismiss: this.onDismissMessage,
        header: 'Perfil "' + savedUserName + '" salvo com sucesso.',
        onClick: this.onDismissMessage
      }) : '', _react2.default.createElement('div', {
        'data-jsx': 1356100837
      }, _react2.default.createElement(_semanticUiReact.Loader, { active: true, inverted: true, size: 'massive' }), _react2.default.createElement('video', {
        ref: function ref(el) {
          return _this3.video = el;
        },
        width: canvasSize.width,
        height: canvasSize.height,
        autoPlay: true,
        'data-jsx': 1356100837
      }), _react2.default.createElement('canvas', {
        ref: function ref(el) {
          return _this3.videoCanvas = el;
        },
        className: 'videoCanvas',
        width: canvasSize.width,
        height: canvasSize.height,
        'data-jsx': 1356100837
      }), _react2.default.createElement('canvas', {
        ref: function ref(el) {
          return _this3.overlayCanvas = el;
        },
        className: 'overlayCanvas ' + (isTraining ? 'hidden' : ''),
        width: canvasSize.width,
        height: canvasSize.height,
        'data-jsx': 1356100837
      }), isTraining ? _react2.default.createElement('div', { className: 'training-container', 'data-jsx': 1356100837
      }, _react2.default.createElement(_trainingOverlay2.default, { percentage: Math.round(trainingPhotoIndex / trainingPhotosCount * 100) }), trainingPhotoIndex < trainingPhotosCount ? _react2.default.createElement('div', {
        'data-jsx': 1356100837
      }, _react2.default.createElement(_semanticUiReact.Button, { basic: true, inverted: true, onClick: this.canceltraining }, 'Cancelar'), _react2.default.createElement(_semanticUiReact.Header, { as: 'h1', textAlign: 'center' }, 'Cria\xE7\xE3o de perfil em progresso...'), _react2.default.createElement(_semanticUiReact.Header, { as: 'h3', textAlign: 'center' }, 'Aguarde enquanto movimenta a cabe\xE7a')) : null) : null, showAddUserButton ? _react2.default.createElement('div', { className: 'buttons', 'data-jsx': 1356100837
      }, _react2.default.createElement(_semanticUiReact.Button, {
        content: 'Adicionar Perfil',
        icon: 'add user',
        labelPosition: 'left',
        color: 'teal',
        size: 'big',
        onClick: this.trainNewUser
      })) : null), _react2.default.createElement(_style2.default, {
        styleId: 1356100837,
        css: '.ui.message {box-shadow: none;left: 20px;position: absolute;right: 20px;top: 20px;z-index: 10000;}div[data-jsx="1356100837"] .ui.loader {left: 50%;position: absolute;top: 50%;margin: -.5em 0 0 -.5em;z-index: 0;}.videoCanvas[data-jsx="1356100837"] {left: -100000px;position: absolute;top: -100000px;}.overlayCanvas[data-jsx="1356100837"],video[data-jsx="1356100837"] {left: 0;position: absolute;top: 0;}.overlayCanvas[data-jsx="1356100837"] {z-index: 2;}.hidden[data-jsx="1356100837"] {display: none;}.buttons[data-jsx="1356100837"] {left: 50%;position: absolute;bottom: 40px;-webkit-transform: translateX(-50%);transform: translateX(-50%);z-index: 3;}.training-container[data-jsx="1356100837"] {}.training-container[data-jsx="1356100837"][data-jsx="1356100837"] div[data-jsx="1356100837"] {display: -webkit-box;display: -ms-flexbox;display: flex;-moz-flex-direction: column;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: end;-ms-flex-pack: end;justify-content: flex-end;padding-bottom: 40px;position: absolute;top: 0;left: 0;bottom: 0;right: 0;z-index: 4;}.training-container[data-jsx="1356100837"][data-jsx="1356100837"] div[data-jsx="1356100837"][data-jsx="1356100837"] .ui.header {color: #fff;margin: 8px 0 0 0;}.training-container[data-jsx="1356100837"][data-jsx="1356100837"] .ui.button {position: absolute;top: 60px;right: 60px;}\n/*@ sourceURL=pages/index.js?entry */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jbGF1ZGlhZmVycmVpcmEvR2l0SHViL1Byb2pldG9fbGFiX2ludF9JSS9pY2FyL3BhZ2VzL2luZGV4LmpzP2VudHJ5IiwicGFnZXMvaW5kZXguanM/ZW50cnkiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBZ1JvQixhQUVTLGlCQUNOLFdBQ1EsbUJBQ1AsWUFDRixVQUNLLGVBQ2hCLENBRXdCLHVDQUNiLFVBQ1MsbUJBQ1YsU0FDZSx3QkFDYixXQUNaLENBRWEscUNBQ0ksZ0JBQ0csbUJBQ0osZUFDaEIsQ0FHTSxvRUFDRyxRQUNXLG1CQUNaLE9BQ1IsQ0FFZSx1Q0FDSCxXQUNaLENBRVEsZ0NBQ08sY0FDZixDQUVTLGlDQUNFLFVBQ1MsbUJBQ04sYUFDZSxvQ0FBQSw0QkFDakIsV0FDWixDQUVvQiw2Q0F3QnBCLEFBdkJRLDhGQUNTLHFCQUNTLEFBRFQscUJBQ1MsQUFEVCxjQUNTLDRCQUFBLDZCQUNHLEFBREgsOEJBQ0csQUFESCwyQkFDRyxBQURILHVCQUNHLHNCQUNMLEFBREssbUJBQ0wsQUFESywwQkFDTCxxQkFDRixtQkFDWixPQUNDLFFBQ0UsVUFDRCxTQUNFLFdBRVksQ0FNRixBQU5FLGdJQUNULFlBQ00sa0JBQ25CLENBQ0YsQUFFc0IsOEVBQ0YsbUJBQ1QsVUFDRSxZQUNiLENBQ0Y7QUNyVlgscUNBQXFDIiwiZmlsZSI6InRvLmNzcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSb3V0ZXIgZnJvbSAnbmV4dC9yb3V0ZXInXG5pbXBvcnQgd2l0aFJlZHV4IGZyb20gJ25leHQtcmVkdXgtd3JhcHBlcidcbmltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgSGVhZGVyLCBCdXR0b24sIExvYWRlciwgTWVzc2FnZSB9IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0J1xuaW1wb3J0IFRyYWluaW5nT3ZlcmxheSBmcm9tICcuLi9jb21wb25lbnRzL3RyYWluaW5nLW92ZXJsYXknXG5pbXBvcnQgeyBpbml0U3RvcmUsIHNldEN1cnJlbnRVc2VyIH0gZnJvbSAnLi4vaGVscGVycy9zdG9yZSdcblxuY29uc3QgY2FudmFzU2l6ZSA9IHsgd2lkdGg6IDgwMCwgaGVpZ2h0OiA2MDAgfVxuY29uc3QgcmVjb2duaXppbmdJbnRlcnZhbFRpbWVvdXQgPSA3NTBcbmNvbnN0IHRyYWluaW5nUGhvdG9zQ291bnQgPSAzMFxuXG5sZXQgaGlkZU1lc3NhZ2VUaW1lb3V0XG5jb25zdCBsYXN0VXNlcklkID0gdXNlcnMgPT4gT2JqZWN0LmtleXModXNlcnMpLm1hcChpZCA9PiBwYXJzZUludChpZCkpLnNvcnQoKS5wb3AoKSB8fCAwXG5cbmNsYXNzIEhvbWVQYWdlIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IocHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcylcblxuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBzaG93QWRkVXNlckJ1dHRvbjogZmFsc2UsXG4gICAgICBpc1RyYWluaW5nOiBmYWxzZSxcbiAgICAgIHBlcmNlbnRhZ2U6IDAsXG4gICAgICBzYXZlZFVzZXJOYW1lOiBwcm9wcy51cmwucXVlcnkuc2F2ZWQsXG4gICAgfVxuICB9XG5cbiAgY29tcG9uZW50RGlkTW91bnQgKCkge1xuICAgIGNvbnN0IGlzVHJhaW5pbmcgPSB0aGlzLnByb3BzLnVybC5xdWVyeS50cmFpbmluZyAhPT0gdW5kZWZpbmVkXG4gICAgY29uc3QgeyBzYXZlZFVzZXJOYW1lIH0gPSB0aGlzLnN0YXRlXG5cbiAgICBpZiAoc2F2ZWRVc2VyTmFtZSkge1xuICAgICAgaGlkZU1lc3NhZ2VUaW1lb3V0ID0gc2V0VGltZW91dCh0aGlzLm9uRGlzbWlzc01lc3NhZ2UsIDUwMDApXG4gICAgfVxuXG4gICAgdGhpcy52aWRlb0NvbnRleHQgPSB0aGlzLnZpZGVvQ2FudmFzLmdldENvbnRleHQoJzJkJylcblxuICAgIHRoaXMub3ZlcmxheUNvbnRleHQgPSB0aGlzLm92ZXJsYXlDYW52YXMuZ2V0Q29udGV4dCgnMmQnKVxuICAgIHRoaXMub3ZlcmxheUNvbnRleHQuc3Ryb2tlU3R5bGUgPSAncmdiKDAsIDE4NCwgMTc0KSdcbiAgICB0aGlzLm92ZXJsYXlDb250ZXh0LmxpbmVXaWR0aCA9IDRcbiAgICB0aGlzLm92ZXJsYXlDb250ZXh0LmxpbmVDYXAgPSAncm91bmQnXG4gICAgdGhpcy5vdmVybGF5Q29udGV4dC5zZXRMaW5lRGFzaChbMiwgMTVdKVxuXG4gICAgd2luZG93LnNvY2tldC5vbignZmFjZURldGVjdGVkJywgdGhpcy5oYW5kbGVGYWNlRGV0ZWN0ZWQpXG4gICAgd2luZG93LnNvY2tldC5vbigndXNlclRyYWlubmVkJywgdGhpcy5oYW5kbGVVc2VyVHJhaW5uZWQpXG4gICAgd2luZG93LnNvY2tldC5vbignc3RhcnQtdHJhaW5pbmcnLCAoKSA9PiBSb3V0ZXIucHVzaCgnLz90cmFpbmluZz0xJykpXG5cbiAgICBpZiAodGhpcy52aWRlbyAmJiBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzICYmIG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKSB7XG4gICAgICBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7IHZpZGVvOiB0cnVlIH0pLnRoZW4oc3RyZWFtID0+IHtcbiAgICAgICAgdGhpcy5jYW1lcmFTdHJlYW0gPSBzdHJlYW1cbiAgICAgICAgdGhpcy52aWRlby5zcmMgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTCh0aGlzLmNhbWVyYVN0cmVhbSlcblxuICAgICAgICB0aGlzLnZpZGVvLnBsYXkoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICBpZiAoIWlzVHJhaW5pbmcpIHtcbiAgICAgICAgICAgIHRoaXMuc3RhcnREZXRlY3RpbmcoKVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluTmV3VXNlcigpXG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICBjb21wb25lbnRXaWxsUmVjZWl2ZVByb3BzKG5leHRQcm9wcykge1xuICAgIGlmICghdGhpcy5wcm9wcy51cmwucXVlcnkudHJhaW5pbmcgJiYgbmV4dFByb3BzLnVybC5xdWVyeS50cmFpbmluZykge1xuICAgICAgdGhpcy50cmFpbk5ld1VzZXIoKVxuICAgIH1cbiAgfVxuXG4gIGNvbXBvbmVudFdpbGxVbm1vdW50ICgpIHtcbiAgICBjbGVhckludGVydmFsKHRoaXMucmVjb2duaXppbmdJbnRlcnZhbClcbiAgICBjbGVhckludGVydmFsKHRoaXMudHJhaW5pbmdJbnRlcnZhbClcbiAgICBjbGVhclRpbWVvdXQoaGlkZU1lc3NhZ2VUaW1lb3V0KVxuXG4gICAgaWYgKHRoaXMudmlkZW8pIHtcbiAgICAgIHRoaXMudmlkZW8ucGF1c2UoKVxuICAgICAgdGhpcy5jYW1lcmFTdHJlYW0uZ2V0VHJhY2tzKClbMF0uc3RvcCgpXG4gICAgfVxuICB9XG5cbiAgb25EaXNtaXNzTWVzc2FnZSA9ICgpID0+IHtcbiAgICB0aGlzLnNldFN0YXRlKHsgc2F2ZWRVc2VyTmFtZTogbnVsbCB9KVxuICB9XG5cbiAgZHJhd0ZhY2VPdmVybGF5KHsgeCwgeSwgd2lkdGgsIGhlaWdodCB9KSB7XG4gICAgdGhpcy5vdmVybGF5Q29udGV4dC5iZWdpblBhdGgoKTtcbiAgICB0aGlzLm92ZXJsYXlDb250ZXh0LmFyYyh4ICsgd2lkdGggLyAyLCB5ICsgd2lkdGggLyAyLCB3aWR0aCAvIDEuNywgMCwgTWF0aC5QSSAqIDIsIHRydWUpO1xuICAgIHRoaXMub3ZlcmxheUNvbnRleHQuc3Ryb2tlKClcblxuICAgIHRoaXMubGFzdEZhY2VQb3NpdGlvbiA9IHsgeCwgeSwgd2lkdGgsIGhlaWdodCB9XG4gIH1cblxuICBjbGVhckZhY2VPdmVybGF5KCkge1xuICAgIGlmICh0aGlzLmxhc3RGYWNlUG9zaXRpb24pIHtcbiAgICAgIGNvbnN0IHsgeCwgeSwgd2lkdGggfSA9IHRoaXMubGFzdEZhY2VQb3NpdGlvblxuXG4gICAgICB0aGlzLm92ZXJsYXlDb250ZXh0LmNsZWFyUmVjdChcbiAgICAgICAgeCAtIHdpZHRoIC8gMixcbiAgICAgICAgeSAtIHdpZHRoIC8gMixcbiAgICAgICAgd2lkdGggKiAyLFxuICAgICAgICB3aWR0aCAqIDJcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICBoYW5kbGVGYWNlRGV0ZWN0ZWQgPSBkYXRhID0+IHtcbiAgICBjb25zdCB7IGRpc3BhdGNoLCB1c2VycywgY3VycmVudFVzZXIgfSA9IHRoaXMucHJvcHNcbiAgICBjb25zdCB7IGlzVHJhaW5pbmcgfSA9IHRoaXMuc3RhdGVcbiAgICBjb25zdCB7IGlkLCBwb3NpdGlvbiwgLi4udXNlckRhdGEgfSA9IGRhdGFcblxuICAgIHRoaXMuY2xlYXJGYWNlT3ZlcmxheSgpXG5cbiAgICBpZiAoaXNUcmFpbmluZykge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG5cbiAgICBpZiAoaWQpIHtcbiAgICAgIGlmIChjdXJyZW50VXNlciAmJiBjdXJyZW50VXNlci5pZCA9PT0gaWQpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBzaG93QWRkVXNlckJ1dHRvbjogZmFsc2UgfSlcblxuICAgICAgZGlzcGF0Y2goc2V0Q3VycmVudFVzZXIoeyBpZCwgLi4udXNlckRhdGEgfSkpXG5cbiAgICAgIHdpbmRvdy5zb2NrZXQuZW1pdCgndXBkYXRlLXNldHRpbmdzJywgdXNlckRhdGEuc2V0dGluZ3MpXG4gICAgfSBlbHNlIGlmIChwb3NpdGlvbikge1xuICAgICAgdGhpcy5kcmF3RmFjZU92ZXJsYXkocG9zaXRpb24pXG5cbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBzaG93QWRkVXNlckJ1dHRvbjogdHJ1ZSB9KVxuICAgIH1cbiAgfVxuXG4gIHN0YXJ0RGV0ZWN0aW5nID0gKCkgPT4ge1xuICAgIHRoaXMucmVjb2duaXppbmdJbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHRoaXMudmlkZW9Db250ZXh0LmRyYXdJbWFnZSh0aGlzLnZpZGVvLCAwLCAwLCBjYW52YXNTaXplLndpZHRoLCBjYW52YXNTaXplLmhlaWdodClcblxuICAgICAgd2luZG93LnNvY2tldC5lbWl0KCdyZWNvZ25pemVGYWNlJywgdGhpcy52aWRlb0NhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAxKSlcbiAgICB9LCByZWNvZ25pemluZ0ludGVydmFsVGltZW91dClcbiAgfVxuXG4gIHRyYWluTmV3VXNlciA9ICgpID0+IHtcbiAgICBjb25zdCB7IHVzZXJzIH0gPSB0aGlzLnByb3BzXG5cbiAgICBjbGVhckludGVydmFsKHRoaXMucmVjb2duaXppbmdJbnRlcnZhbClcbiAgICBjbGVhckludGVydmFsKHRoaXMudHJhaW5pbmdJbnRlcnZhbClcblxuICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgc2hvd0FkZFVzZXJCdXR0b246IGZhbHNlLFxuICAgICAgdHJhaW5pbmdQaG90b0luZGV4OiAwLFxuICAgICAgaXNUcmFpbmluZzogdHJ1ZSxcbiAgICB9KVxuXG4gICAgY29uc3QgbmV3VXNlcklkID0gbGFzdFVzZXJJZCh1c2VycykgKyAxXG5cbiAgICB3aW5kb3cuc29ja2V0LmVtaXQoYHJlbW92ZVVzZXJgLCBuZXdVc2VySWQpXG5cbiAgICB0aGlzLnRyYWluaW5nSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICB0aGlzLnNldFN0YXRlKHsgdHJhaW5pbmdQaG90b0luZGV4OiB0aGlzLnN0YXRlLnRyYWluaW5nUGhvdG9JbmRleCArIDEgfSwgKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZS50cmFpbmluZ1Bob3RvSW5kZXggPj0gdHJhaW5pbmdQaG90b3NDb3VudCkge1xuICAgICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy50cmFpbmluZ0ludGVydmFsKVxuXG4gICAgICAgICAgd2luZG93LnNvY2tldC5lbWl0KGB0cmFpblVzZXJgLCBuZXdVc2VySWQpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy52aWRlb0NvbnRleHQuZHJhd0ltYWdlKHRoaXMudmlkZW8sIDAsIDAsIGNhbnZhc1NpemUud2lkdGgsIGNhbnZhc1NpemUuaGVpZ2h0KVxuXG4gICAgICAgICAgd2luZG93LnNvY2tldC5lbWl0KFxuICAgICAgICAgICAgYHNhdmVVc2VyUGhvdG9gLFxuICAgICAgICAgICAgdGhpcy52aWRlb0NhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAxKSxcbiAgICAgICAgICAgIG5ld1VzZXJJZCxcbiAgICAgICAgICAgIHRoaXMuc3RhdGUudHJhaW5pbmdQaG90b0luZGV4XG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0sIDEwMClcbiAgfVxuXG4gIGNhbmNlbHRyYWluaW5nID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgdXNlcnMgfSA9IHRoaXMucHJvcHNcblxuICAgIGNsZWFySW50ZXJ2YWwodGhpcy50cmFpbmluZ0ludGVydmFsKVxuXG4gICAgY29uc3QgdXNlcklkID0gbGFzdFVzZXJJZCh1c2VycykgKyAxXG5cbiAgICB3aW5kb3cuc29ja2V0LmVtaXQoYHJlbW92ZVVzZXJgLCB1c2VySWQpXG5cbiAgICB0aGlzLnNldFN0YXRlKHsgaXNUcmFpbmluZzogZmFsc2UsIHRyYWluaW5nUGhvdG9JbmRleDogMCB9KVxuICAgIHRoaXMuc3RhcnREZXRlY3RpbmcoKVxuICB9XG5cbiAgaGFuZGxlVXNlclRyYWlubmVkID0gaWQgPT4ge1xuICAgIFJvdXRlci5wdXNoKGAvcHJvZmlsZT9pZD0ke2lkfSZpc05ldz0xYClcbiAgfVxuXG4gIHJlbmRlciAoKSB7XG4gICAgY29uc3QgeyBzYXZlZFVzZXJOYW1lLCBzaG93QWRkVXNlckJ1dHRvbiwgaXNUcmFpbmluZywgdHJhaW5pbmdQaG90b0luZGV4IH0gPSB0aGlzLnN0YXRlXG5cbiAgICByZXR1cm4gKFxuICAgICAgPExheW91dCBoaWRlSGVhZGVyPXsgaXNUcmFpbmluZyB9IGhpZGVGb290ZXI9eyBpc1RyYWluaW5nIH0+XG4gICAgICAgIHtzYXZlZFVzZXJOYW1lXG4gICAgICAgICAgPyA8TWVzc2FnZVxuICAgICAgICAgICAgb25EaXNtaXNzPXt0aGlzLm9uRGlzbWlzc01lc3NhZ2V9XG4gICAgICAgICAgICBoZWFkZXI9e2BQZXJmaWwgXCIke3NhdmVkVXNlck5hbWV9XCIgc2Fsdm8gY29tIHN1Y2Vzc28uYH1cbiAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMub25EaXNtaXNzTWVzc2FnZX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDogJydcbiAgICAgICAgfVxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPExvYWRlciBhY3RpdmUgaW52ZXJ0ZWQgc2l6ZT1cIm1hc3NpdmVcIiAvPlxuXG4gICAgICAgICAgPHZpZGVvXG4gICAgICAgICAgICByZWY9e2VsID0+IHRoaXMudmlkZW8gPSBlbH1cbiAgICAgICAgICAgIHdpZHRoPXtjYW52YXNTaXplLndpZHRofVxuICAgICAgICAgICAgaGVpZ2h0PXtjYW52YXNTaXplLmhlaWdodH1cbiAgICAgICAgICAgIGF1dG9QbGF5XG4gICAgICAgICAgLz5cblxuICAgICAgICAgIDxjYW52YXNcbiAgICAgICAgICAgIHJlZj17ZWwgPT4gdGhpcy52aWRlb0NhbnZhcyA9IGVsfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidmlkZW9DYW52YXNcIlxuICAgICAgICAgICAgd2lkdGg9e2NhbnZhc1NpemUud2lkdGh9XG4gICAgICAgICAgICBoZWlnaHQ9e2NhbnZhc1NpemUuaGVpZ2h0fVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8Y2FudmFzXG4gICAgICAgICAgICByZWY9e2VsID0+IHRoaXMub3ZlcmxheUNhbnZhcyA9IGVsfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgb3ZlcmxheUNhbnZhcyAke2lzVHJhaW5pbmcgPyAnaGlkZGVuJyA6ICcnfWB9XG4gICAgICAgICAgICB3aWR0aD17Y2FudmFzU2l6ZS53aWR0aH1cbiAgICAgICAgICAgIGhlaWdodD17Y2FudmFzU2l6ZS5oZWlnaHR9XG4gICAgICAgICAgLz5cblxuICAgICAgICAgIHsgaXNUcmFpbmluZ1xuICAgICAgICAgICAgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJhaW5pbmctY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgPFRyYWluaW5nT3ZlcmxheSBwZXJjZW50YWdlPXtNYXRoLnJvdW5kKHRyYWluaW5nUGhvdG9JbmRleCAvIHRyYWluaW5nUGhvdG9zQ291bnQgKiAxMDApfSAvPlxuXG4gICAgICAgICAgICAgICAge3RyYWluaW5nUGhvdG9JbmRleCA8IHRyYWluaW5nUGhvdG9zQ291bnRcbiAgICAgICAgICAgICAgICAgID8gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gYmFzaWMgaW52ZXJ0ZWQgb25DbGljaz17dGhpcy5jYW5jZWx0cmFpbmluZ30+Q2FuY2VsYXI8L0J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxIZWFkZXIgYXM9XCJoMVwiIHRleHRBbGlnbj1cImNlbnRlclwiPkNyaWHDp8OjbyBkZSBwZXJmaWwgZW0gcHJvZ3Jlc3NvLi4uPC9IZWFkZXI+XG4gICAgICAgICAgICAgICAgICAgICAgPEhlYWRlciBhcz1cImgzXCIgdGV4dEFsaWduPVwiY2VudGVyXCI+QWd1YXJkZSBlbnF1YW50byBtb3ZpbWVudGEgYSBjYWJlw6dhPC9IZWFkZXI+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgOiBudWxsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIDogbnVsbFxuICAgICAgICAgIH1cblxuICAgICAgICAgIHsgc2hvd0FkZFVzZXJCdXR0b25cbiAgICAgICAgICAgID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1dHRvbnNcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICBjb250ZW50PVwiQWRpY2lvbmFyIFBlcmZpbFwiXG4gICAgICAgICAgICAgICAgICBpY29uPVwiYWRkIHVzZXJcIlxuICAgICAgICAgICAgICAgICAgbGFiZWxQb3NpdGlvbj1cImxlZnRcIlxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJ0ZWFsXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJiaWdcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17dGhpcy50cmFpbk5ld1VzZXJ9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApXG4gICAgICAgICAgICA6IG51bGxcbiAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICA6Z2xvYmFsKC51aS5tZXNzYWdlKSB7XG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgICAgICAgbGVmdDogMjBweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHJpZ2h0OiAyMHB4O1xuICAgICAgICAgICAgdG9wOiAyMHB4O1xuICAgICAgICAgICAgei1pbmRleDogMTAwMDA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZGl2IDpnbG9iYWwoLnVpLmxvYWRlcikge1xuICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICBtYXJnaW46IC0uNWVtIDAgMCAtLjVlbTtcbiAgICAgICAgICAgIHotaW5kZXg6IDA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLnZpZGVvQ2FudmFzIHtcbiAgICAgICAgICAgIGxlZnQ6IC0xMDAwMDBweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHRvcDogLTEwMDAwMHB4O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5vdmVybGF5Q2FudmFzLFxuICAgICAgICAgIHZpZGVvIHtcbiAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLm92ZXJsYXlDYW52YXMge1xuICAgICAgICAgICAgei1pbmRleDogMjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAuaGlkZGVuIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLmJ1dHRvbnMge1xuICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgYm90dG9tOiA0MHB4O1xuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xuICAgICAgICAgICAgei1pbmRleDogMztcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAudHJhaW5pbmctY29udGFpbmVyIHtcbiAgICAgICAgICAgICYgZGl2IHtcbiAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDQwcHg7XG4gICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgICBsZWZ0OiAwO1xuICAgICAgICAgICAgICBib3R0b206IDA7XG4gICAgICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICAgICAgICB6LWluZGV4OiA0O1xuXG4gICAgICAgICAgICAgICYgOmdsb2JhbCgudWkuaGVhZGVyKSB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiA4cHggMCAwIDA7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJiA6Z2xvYmFsKC51aS5idXR0b24pIHtcbiAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICB0b3A6IDYwcHg7XG4gICAgICAgICAgICAgIHJpZ2h0OiA2MHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgPC9MYXlvdXQ+XG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IHdpdGhSZWR1eChpbml0U3RvcmUsIHN0YXRlID0+IHN0YXRlKShIb21lUGFnZSlcbiIsIi51aS5tZXNzYWdlIHtib3gtc2hhZG93OiBub25lO2xlZnQ6IDIwcHg7cG9zaXRpb246IGFic29sdXRlO3JpZ2h0OiAyMHB4O3RvcDogMjBweDt6LWluZGV4OiAxMDAwMDt9ZGl2W2RhdGEtanN4PVwiMTM1NjEwMDgzN1wiXSAudWkubG9hZGVyIHtsZWZ0OiA1MCU7cG9zaXRpb246IGFic29sdXRlO3RvcDogNTAlO21hcmdpbjogLS41ZW0gMCAwIC0uNWVtO3otaW5kZXg6IDA7fS52aWRlb0NhbnZhc1tkYXRhLWpzeD1cIjEzNTYxMDA4MzdcIl0ge2xlZnQ6IC0xMDAwMDBweDtwb3NpdGlvbjogYWJzb2x1dGU7dG9wOiAtMTAwMDAwcHg7fS5vdmVybGF5Q2FudmFzW2RhdGEtanN4PVwiMTM1NjEwMDgzN1wiXSx2aWRlb1tkYXRhLWpzeD1cIjEzNTYxMDA4MzdcIl0ge2xlZnQ6IDA7cG9zaXRpb246IGFic29sdXRlO3RvcDogMDt9Lm92ZXJsYXlDYW52YXNbZGF0YS1qc3g9XCIxMzU2MTAwODM3XCJdIHt6LWluZGV4OiAyO30uaGlkZGVuW2RhdGEtanN4PVwiMTM1NjEwMDgzN1wiXSB7ZGlzcGxheTogbm9uZTt9LmJ1dHRvbnNbZGF0YS1qc3g9XCIxMzU2MTAwODM3XCJdIHtsZWZ0OiA1MCU7cG9zaXRpb246IGFic29sdXRlO2JvdHRvbTogNDBweDstd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTstbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTstbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO3RyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTt6LWluZGV4OiAzO30udHJhaW5pbmctY29udGFpbmVyW2RhdGEtanN4PVwiMTM1NjEwMDgzN1wiXSB7JltkYXRhLWpzeD1cIjEzNTYxMDA4MzdcIl0gZGl2W2RhdGEtanN4PVwiMTM1NjEwMDgzN1wiXSB7ZGlzcGxheTotd2Via2l0LWZsZXg7IGRpc3BsYXk6ZmxleDstd2Via2l0LWZsZXgtZGlyZWN0aW9uOiBjb2x1bW47LW1vei1mbGV4LWRpcmVjdGlvbjogY29sdW1uO2ZsZXgtZGlyZWN0aW9uOiBjb2x1bW47anVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtwYWRkaW5nLWJvdHRvbTogNDBweDtwb3NpdGlvbjogYWJzb2x1dGU7dG9wOiAwO2xlZnQ6IDA7Ym90dG9tOiAwO3JpZ2h0OiAwO3otaW5kZXg6IDQ7JltkYXRhLWpzeD1cIjEzNTYxMDA4MzdcIl0gLnVpLmhlYWRlciB7Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMCAwIDA7fX0mW2RhdGEtanN4PVwiMTM1NjEwMDgzN1wiXSAudWkuYnV0dG9uIHtwb3NpdGlvbjogYWJzb2x1dGU7dG9wOiA2MHB4O3JpZ2h0OiA2MHB4O319XG4vKiMgc291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247YmFzZTY0LGV5SjJaWEp6YVc5dUlqb3pMQ0p6YjNWeVkyVnpJanBiSW5CaFoyVnpMMmx1WkdWNExtcHpQMlZ1ZEhKNUlsMHNJbTVoYldWeklqcGJYU3dpYldGd2NHbHVaM01pT2lKQlFXZFNiMElzUVVGRFdTeGhRVU5JTEdsQ1FVTk9MRmRCUTFFc2JVSkJRMUFzV1VGRFJpeFZRVU5MTEdWQlEyaENMRU5CUlhkQ0xIVkRRVU5pTEZWQlExTXNiVUpCUTFZc1UwRkRaU3gzUWtGRFlpeFhRVU5hTEVOQlJXRXNjVU5CUTBrc1owSkJRMGNzYlVKQlEwb3NaVUZEYUVJc1EwRkhUU3h2UlVGRFJ5eFJRVU5YTEcxQ1FVTmFMRTlCUTFJc1EwRkZaU3gxUTBGRFNDeFhRVU5hTEVOQlJWRXNaME5CUTA4c1kwRkRaaXhEUVVWVExHbERRVU5GTEZWQlExTXNiVUpCUTA0c1lVRkRaU3hwU1VGRGFrSXNWMEZEV2l4RFFVVnZRaXcwUTBGRFdpeHhSRUZEVXl4dFEwRkRVeXhyUmtGRFJ5d3dRa0ZEVEN4eFFrRkRSaXh0UWtGRFdpeFBRVU5ETEZGQlEwVXNWVUZEUkN4VFFVTkZMRmRCUlZrc2NVTkJRMVFzV1VGRFRTeHJRa0ZEYmtJc1EwRkRSaXhEUVVWelFpeHhRMEZEUml4dFFrRkRWQ3hWUVVORkxGbEJRMklzUTBGRFJpSXNJbVpwYkdVaU9pSndZV2RsY3k5cGJtUmxlQzVxY3o5bGJuUnllU0lzSW5OdmRYSmpaVkp2YjNRaU9pSXZWWE5sY25NdlkyeGhkV1JwWVdabGNuSmxhWEpoTDBkcGRFaDFZaTlRY205cVpYUnZYMnhoWWw5cGJuUmZTVWt2YVdOaGNpSXNJbk52ZFhKalpYTkRiMjUwWlc1MElqcGJJbWx0Y0c5eWRDQlNiM1YwWlhJZ1puSnZiU0FuYm1WNGRDOXliM1YwWlhJblhHNXBiWEJ2Y25RZ2QybDBhRkpsWkhWNElHWnliMjBnSjI1bGVIUXRjbVZrZFhndGQzSmhjSEJsY2lkY2JtbHRjRzl5ZENCN0lFTnZiWEJ2Ym1WdWRDQjlJR1p5YjIwZ0ozSmxZV04wSjF4dWFXMXdiM0owSUhzZ1NHVmhaR1Z5TENCQ2RYUjBiMjRzSUV4dllXUmxjaXdnVFdWemMyRm5aU0I5SUdaeWIyMGdKM05sYldGdWRHbGpMWFZwTFhKbFlXTjBKMXh1WEc1cGJYQnZjblFnVEdGNWIzVjBJR1p5YjIwZ0p5NHVMMk52YlhCdmJtVnVkSE12YkdGNWIzVjBKMXh1YVcxd2IzSjBJRlJ5WVdsdWFXNW5UM1psY214aGVTQm1jbTl0SUNjdUxpOWpiMjF3YjI1bGJuUnpMM1J5WVdsdWFXNW5MVzkyWlhKc1lYa25YRzVwYlhCdmNuUWdleUJwYm1sMFUzUnZjbVVzSUhObGRFTjFjbkpsYm5SVmMyVnlJSDBnWm5KdmJTQW5MaTR2YUdWc2NHVnljeTl6ZEc5eVpTZGNibHh1WTI5dWMzUWdZMkZ1ZG1GelUybDZaU0E5SUhzZ2QybGtkR2c2SURnd01Dd2dhR1ZwWjJoME9pQTJNREFnZlZ4dVkyOXVjM1FnY21WamIyZHVhWHBwYm1kSmJuUmxjblpoYkZScGJXVnZkWFFnUFNBM05UQmNibU52Ym5OMElIUnlZV2x1YVc1blVHaHZkRzl6UTI5MWJuUWdQU0F6TUZ4dVhHNXNaWFFnYUdsa1pVMWxjM05oWjJWVWFXMWxiM1YwWEc1amIyNXpkQ0JzWVhOMFZYTmxja2xrSUQwZ2RYTmxjbk1nUFQ0Z1QySnFaV04wTG10bGVYTW9kWE5sY25NcExtMWhjQ2hwWkNBOVBpQndZWEp6WlVsdWRDaHBaQ2twTG5OdmNuUW9LUzV3YjNBb0tTQjhmQ0F3WEc1Y2JtTnNZWE56SUVodmJXVlFZV2RsSUdWNGRHVnVaSE1nUTI5dGNHOXVaVzUwSUh0Y2JpQWdZMjl1YzNSeWRXTjBiM0lvY0hKdmNITXBJSHRjYmlBZ0lDQnpkWEJsY2lod2NtOXdjeWxjYmx4dUlDQWdJSFJvYVhNdWMzUmhkR1VnUFNCN1hHNGdJQ0FnSUNCemFHOTNRV1JrVlhObGNrSjFkSFJ2YmpvZ1ptRnNjMlVzWEc0Z0lDQWdJQ0JwYzFSeVlXbHVhVzVuT2lCbVlXeHpaU3hjYmlBZ0lDQWdJSEJsY21ObGJuUmhaMlU2SURBc1hHNGdJQ0FnSUNCellYWmxaRlZ6WlhKT1lXMWxPaUJ3Y205d2N5NTFjbXd1Y1hWbGNua3VjMkYyWldRc1hHNGdJQ0FnZlZ4dUlDQjlYRzVjYmlBZ1kyOXRjRzl1Wlc1MFJHbGtUVzkxYm5RZ0tDa2dlMXh1SUNBZ0lHTnZibk4wSUdselZISmhhVzVwYm1jZ1BTQjBhR2x6TG5CeWIzQnpMblZ5YkM1eGRXVnllUzUwY21GcGJtbHVaeUFoUFQwZ2RXNWtaV1pwYm1Wa1hHNGdJQ0FnWTI5dWMzUWdleUJ6WVhabFpGVnpaWEpPWVcxbElIMGdQU0IwYUdsekxuTjBZWFJsWEc1Y2JpQWdJQ0JwWmlBb2MyRjJaV1JWYzJWeVRtRnRaU2tnZTF4dUlDQWdJQ0FnYUdsa1pVMWxjM05oWjJWVWFXMWxiM1YwSUQwZ2MyVjBWR2x0Wlc5MWRDaDBhR2x6TG05dVJHbHpiV2x6YzAxbGMzTmhaMlVzSURVd01EQXBYRzRnSUNBZ2ZWeHVYRzRnSUNBZ2RHaHBjeTUyYVdSbGIwTnZiblJsZUhRZ1BTQjBhR2x6TG5acFpHVnZRMkZ1ZG1GekxtZGxkRU52Ym5SbGVIUW9KekprSnlsY2JseHVJQ0FnSUhSb2FYTXViM1psY214aGVVTnZiblJsZUhRZ1BTQjBhR2x6TG05MlpYSnNZWGxEWVc1MllYTXVaMlYwUTI5dWRHVjRkQ2duTW1RbktWeHVJQ0FnSUhSb2FYTXViM1psY214aGVVTnZiblJsZUhRdWMzUnliMnRsVTNSNWJHVWdQU0FuY21kaUtEQXNJREU0TkN3Z01UYzBLU2RjYmlBZ0lDQjBhR2x6TG05MlpYSnNZWGxEYjI1MFpYaDBMbXhwYm1WWGFXUjBhQ0E5SURSY2JpQWdJQ0IwYUdsekxtOTJaWEpzWVhsRGIyNTBaWGgwTG14cGJtVkRZWEFnUFNBbmNtOTFibVFuWEc0Z0lDQWdkR2hwY3k1dmRtVnliR0Y1UTI5dWRHVjRkQzV6WlhSTWFXNWxSR0Z6YUNoYk1pd2dNVFZkS1Z4dVhHNGdJQ0FnZDJsdVpHOTNMbk52WTJ0bGRDNXZiaWduWm1GalpVUmxkR1ZqZEdWa0p5d2dkR2hwY3k1b1lXNWtiR1ZHWVdObFJHVjBaV04wWldRcFhHNGdJQ0FnZDJsdVpHOTNMbk52WTJ0bGRDNXZiaWduZFhObGNsUnlZV2x1Ym1Wa0p5d2dkR2hwY3k1b1lXNWtiR1ZWYzJWeVZISmhhVzV1WldRcFhHNGdJQ0FnZDJsdVpHOTNMbk52WTJ0bGRDNXZiaWduYzNSaGNuUXRkSEpoYVc1cGJtY25MQ0FvS1NBOVBpQlNiM1YwWlhJdWNIVnphQ2duTHo5MGNtRnBibWx1WnoweEp5a3BYRzVjYmlBZ0lDQnBaaUFvZEdocGN5NTJhV1JsYnlBbUppQnVZWFpwWjJGMGIzSXViV1ZrYVdGRVpYWnBZMlZ6SUNZbUlHNWhkbWxuWVhSdmNpNXRaV1JwWVVSbGRtbGpaWE11WjJWMFZYTmxjazFsWkdsaEtTQjdYRzRnSUNBZ0lDQnVZWFpwWjJGMGIzSXViV1ZrYVdGRVpYWnBZMlZ6TG1kbGRGVnpaWEpOWldScFlTaDdJSFpwWkdWdk9pQjBjblZsSUgwcExuUm9aVzRvYzNSeVpXRnRJRDArSUh0Y2JpQWdJQ0FnSUNBZ2RHaHBjeTVqWVcxbGNtRlRkSEpsWVcwZ1BTQnpkSEpsWVcxY2JpQWdJQ0FnSUNBZ2RHaHBjeTUyYVdSbGJ5NXpjbU1nUFNCM2FXNWtiM2N1VlZKTUxtTnlaV0YwWlU5aWFtVmpkRlZTVENoMGFHbHpMbU5oYldWeVlWTjBjbVZoYlNsY2JseHVJQ0FnSUNBZ0lDQjBhR2x6TG5acFpHVnZMbkJzWVhrb0tTNTBhR1Z1S0NncElEMCtJSHRjYmlBZ0lDQWdJQ0FnSUNCcFppQW9JV2x6VkhKaGFXNXBibWNwSUh0Y2JpQWdJQ0FnSUNBZ0lDQWdJSFJvYVhNdWMzUmhjblJFWlhSbFkzUnBibWNvS1Z4dUlDQWdJQ0FnSUNBZ0lIMGdaV3h6WlNCN1hHNGdJQ0FnSUNBZ0lDQWdJQ0IwYUdsekxuUnlZV2x1VG1WM1ZYTmxjaWdwWEc0Z0lDQWdJQ0FnSUNBZ2ZWeHVJQ0FnSUNBZ0lDQjlLVnh1SUNBZ0lDQWdmU2xjYmlBZ0lDQjlYRzRnSUgxY2JseHVJQ0JqYjIxd2IyNWxiblJYYVd4c1VtVmpaV2wyWlZCeWIzQnpLRzVsZUhSUWNtOXdjeWtnZTF4dUlDQWdJR2xtSUNnaGRHaHBjeTV3Y205d2N5NTFjbXd1Y1hWbGNua3VkSEpoYVc1cGJtY2dKaVlnYm1WNGRGQnliM0J6TG5WeWJDNXhkV1Z5ZVM1MGNtRnBibWx1WnlrZ2UxeHVJQ0FnSUNBZ2RHaHBjeTUwY21GcGJrNWxkMVZ6WlhJb0tWeHVJQ0FnSUgxY2JpQWdmVnh1WEc0Z0lHTnZiWEJ2Ym1WdWRGZHBiR3hWYm0xdmRXNTBJQ2dwSUh0Y2JpQWdJQ0JqYkdWaGNrbHVkR1Z5ZG1Gc0tIUm9hWE11Y21WamIyZHVhWHBwYm1kSmJuUmxjblpoYkNsY2JpQWdJQ0JqYkdWaGNrbHVkR1Z5ZG1Gc0tIUm9hWE11ZEhKaGFXNXBibWRKYm5SbGNuWmhiQ2xjYmlBZ0lDQmpiR1ZoY2xScGJXVnZkWFFvYUdsa1pVMWxjM05oWjJWVWFXMWxiM1YwS1Z4dVhHNGdJQ0FnYVdZZ0tIUm9hWE11ZG1sa1pXOHBJSHRjYmlBZ0lDQWdJSFJvYVhNdWRtbGtaVzh1Y0dGMWMyVW9LVnh1SUNBZ0lDQWdkR2hwY3k1allXMWxjbUZUZEhKbFlXMHVaMlYwVkhKaFkydHpLQ2xiTUYwdWMzUnZjQ2dwWEc0Z0lDQWdmVnh1SUNCOVhHNWNiaUFnYjI1RWFYTnRhWE56VFdWemMyRm5aU0E5SUNncElEMCtJSHRjYmlBZ0lDQjBhR2x6TG5ObGRGTjBZWFJsS0hzZ2MyRjJaV1JWYzJWeVRtRnRaVG9nYm5Wc2JDQjlLVnh1SUNCOVhHNWNiaUFnWkhKaGQwWmhZMlZQZG1WeWJHRjVLSHNnZUN3Z2VTd2dkMmxrZEdnc0lHaGxhV2RvZENCOUtTQjdYRzRnSUNBZ2RHaHBjeTV2ZG1WeWJHRjVRMjl1ZEdWNGRDNWlaV2RwYmxCaGRHZ29LVHRjYmlBZ0lDQjBhR2x6TG05MlpYSnNZWGxEYjI1MFpYaDBMbUZ5WXloNElDc2dkMmxrZEdnZ0x5QXlMQ0I1SUNzZ2QybGtkR2dnTHlBeUxDQjNhV1IwYUNBdklERXVOeXdnTUN3Z1RXRjBhQzVRU1NBcUlESXNJSFJ5ZFdVcE8xeHVJQ0FnSUhSb2FYTXViM1psY214aGVVTnZiblJsZUhRdWMzUnliMnRsS0NsY2JseHVJQ0FnSUhSb2FYTXViR0Z6ZEVaaFkyVlFiM05wZEdsdmJpQTlJSHNnZUN3Z2VTd2dkMmxrZEdnc0lHaGxhV2RvZENCOVhHNGdJSDFjYmx4dUlDQmpiR1ZoY2taaFkyVlBkbVZ5YkdGNUtDa2dlMXh1SUNBZ0lHbG1JQ2gwYUdsekxteGhjM1JHWVdObFVHOXphWFJwYjI0cElIdGNiaUFnSUNBZ0lHTnZibk4wSUhzZ2VDd2dlU3dnZDJsa2RHZ2dmU0E5SUhSb2FYTXViR0Z6ZEVaaFkyVlFiM05wZEdsdmJseHVYRzRnSUNBZ0lDQjBhR2x6TG05MlpYSnNZWGxEYjI1MFpYaDBMbU5zWldGeVVtVmpkQ2hjYmlBZ0lDQWdJQ0FnZUNBdElIZHBaSFJvSUM4Z01peGNiaUFnSUNBZ0lDQWdlU0F0SUhkcFpIUm9JQzhnTWl4Y2JpQWdJQ0FnSUNBZ2QybGtkR2dnS2lBeUxGeHVJQ0FnSUNBZ0lDQjNhV1IwYUNBcUlESmNiaUFnSUNBZ0lDbGNiaUFnSUNCOVhHNGdJSDFjYmx4dUlDQm9ZVzVrYkdWR1lXTmxSR1YwWldOMFpXUWdQU0JrWVhSaElEMCtJSHRjYmlBZ0lDQmpiMjV6ZENCN0lHUnBjM0JoZEdOb0xDQjFjMlZ5Y3l3Z1kzVnljbVZ1ZEZWelpYSWdmU0E5SUhSb2FYTXVjSEp2Y0hOY2JpQWdJQ0JqYjI1emRDQjdJR2x6VkhKaGFXNXBibWNnZlNBOUlIUm9hWE11YzNSaGRHVmNiaUFnSUNCamIyNXpkQ0I3SUdsa0xDQndiM05wZEdsdmJpd2dMaTR1ZFhObGNrUmhkR0VnZlNBOUlHUmhkR0ZjYmx4dUlDQWdJSFJvYVhNdVkyeGxZWEpHWVdObFQzWmxjbXhoZVNncFhHNWNiaUFnSUNCcFppQW9hWE5VY21GcGJtbHVaeWtnZTF4dUlDQWdJQ0FnY21WMGRYSnVYRzRnSUNBZ2ZWeHVYRzVjYmlBZ0lDQnBaaUFvYVdRcElIdGNiaUFnSUNBZ0lHbG1JQ2hqZFhKeVpXNTBWWE5sY2lBbUppQmpkWEp5Wlc1MFZYTmxjaTVwWkNBOVBUMGdhV1FwSUh0Y2JpQWdJQ0FnSUNBZ2NtVjBkWEp1WEc0Z0lDQWdJQ0I5WEc1Y2JpQWdJQ0FnSUhSb2FYTXVjMlYwVTNSaGRHVW9leUJ6YUc5M1FXUmtWWE5sY2tKMWRIUnZiam9nWm1Gc2MyVWdmU2xjYmx4dUlDQWdJQ0FnWkdsemNHRjBZMmdvYzJWMFEzVnljbVZ1ZEZWelpYSW9leUJwWkN3Z0xpNHVkWE5sY2tSaGRHRWdmU2twWEc1Y2JpQWdJQ0FnSUhkcGJtUnZkeTV6YjJOclpYUXVaVzFwZENnbmRYQmtZWFJsTFhObGRIUnBibWR6Snl3Z2RYTmxja1JoZEdFdWMyVjBkR2x1WjNNcFhHNGdJQ0FnZlNCbGJITmxJR2xtSUNod2IzTnBkR2x2YmlrZ2UxeHVJQ0FnSUNBZ2RHaHBjeTVrY21GM1JtRmpaVTkyWlhKc1lYa29jRzl6YVhScGIyNHBYRzVjYmlBZ0lDQWdJSFJvYVhNdWMyVjBVM1JoZEdVb2V5QnphRzkzUVdSa1ZYTmxja0oxZEhSdmJqb2dkSEoxWlNCOUtWeHVJQ0FnSUgxY2JpQWdmVnh1WEc0Z0lITjBZWEowUkdWMFpXTjBhVzVuSUQwZ0tDa2dQVDRnZTF4dUlDQWdJSFJvYVhNdWNtVmpiMmR1YVhwcGJtZEpiblJsY25aaGJDQTlJSE5sZEVsdWRHVnlkbUZzS0NncElEMCtJSHRjYmlBZ0lDQWdJSFJvYVhNdWRtbGtaVzlEYjI1MFpYaDBMbVJ5WVhkSmJXRm5aU2gwYUdsekxuWnBaR1Z2TENBd0xDQXdMQ0JqWVc1MllYTlRhWHBsTG5kcFpIUm9MQ0JqWVc1MllYTlRhWHBsTG1obGFXZG9kQ2xjYmx4dUlDQWdJQ0FnZDJsdVpHOTNMbk52WTJ0bGRDNWxiV2wwS0NkeVpXTnZaMjVwZW1WR1lXTmxKeXdnZEdocGN5NTJhV1JsYjBOaGJuWmhjeTUwYjBSaGRHRlZVa3dvSjJsdFlXZGxMMnB3WldjbkxDQXhLU2xjYmlBZ0lDQjlMQ0J5WldOdloyNXBlbWx1WjBsdWRHVnlkbUZzVkdsdFpXOTFkQ2xjYmlBZ2ZWeHVYRzRnSUhSeVlXbHVUbVYzVlhObGNpQTlJQ2dwSUQwK0lIdGNiaUFnSUNCamIyNXpkQ0I3SUhWelpYSnpJSDBnUFNCMGFHbHpMbkJ5YjNCelhHNWNiaUFnSUNCamJHVmhja2x1ZEdWeWRtRnNLSFJvYVhNdWNtVmpiMmR1YVhwcGJtZEpiblJsY25aaGJDbGNiaUFnSUNCamJHVmhja2x1ZEdWeWRtRnNLSFJvYVhNdWRISmhhVzVwYm1kSmJuUmxjblpoYkNsY2JseHVJQ0FnSUhSb2FYTXVjMlYwVTNSaGRHVW9lMXh1SUNBZ0lDQWdjMmh2ZDBGa1pGVnpaWEpDZFhSMGIyNDZJR1poYkhObExGeHVJQ0FnSUNBZ2RISmhhVzVwYm1kUWFHOTBiMGx1WkdWNE9pQXdMRnh1SUNBZ0lDQWdhWE5VY21GcGJtbHVaem9nZEhKMVpTeGNiaUFnSUNCOUtWeHVYRzRnSUNBZ1kyOXVjM1FnYm1WM1ZYTmxja2xrSUQwZ2JHRnpkRlZ6WlhKSlpDaDFjMlZ5Y3lrZ0t5QXhYRzVjYmlBZ0lDQjNhVzVrYjNjdWMyOWphMlYwTG1WdGFYUW9ZSEpsYlc5MlpWVnpaWEpnTENCdVpYZFZjMlZ5U1dRcFhHNWNiaUFnSUNCMGFHbHpMblJ5WVdsdWFXNW5TVzUwWlhKMllXd2dQU0J6WlhSSmJuUmxjblpoYkNnb0tTQTlQaUI3WEc0Z0lDQWdJQ0IwYUdsekxuTmxkRk4wWVhSbEtIc2dkSEpoYVc1cGJtZFFhRzkwYjBsdVpHVjRPaUIwYUdsekxuTjBZWFJsTG5SeVlXbHVhVzVuVUdodmRHOUpibVJsZUNBcklERWdmU3dnS0NrZ1BUNGdlMXh1SUNBZ0lDQWdJQ0JwWmlBb2RHaHBjeTV6ZEdGMFpTNTBjbUZwYm1sdVoxQm9iM1J2U1c1a1pYZ2dQajBnZEhKaGFXNXBibWRRYUc5MGIzTkRiM1Z1ZENrZ2UxeHVJQ0FnSUNBZ0lDQWdJR05zWldGeVNXNTBaWEoyWVd3b2RHaHBjeTUwY21GcGJtbHVaMGx1ZEdWeWRtRnNLVnh1WEc0Z0lDQWdJQ0FnSUNBZ2QybHVaRzkzTG5OdlkydGxkQzVsYldsMEtHQjBjbUZwYmxWelpYSmdMQ0J1WlhkVmMyVnlTV1FwWEc0Z0lDQWdJQ0FnSUgwZ1pXeHpaU0I3WEc0Z0lDQWdJQ0FnSUNBZ2RHaHBjeTUyYVdSbGIwTnZiblJsZUhRdVpISmhkMGx0WVdkbEtIUm9hWE11ZG1sa1pXOHNJREFzSURBc0lHTmhiblpoYzFOcGVtVXVkMmxrZEdnc0lHTmhiblpoYzFOcGVtVXVhR1ZwWjJoMEtWeHVYRzRnSUNBZ0lDQWdJQ0FnZDJsdVpHOTNMbk52WTJ0bGRDNWxiV2wwS0Z4dUlDQWdJQ0FnSUNBZ0lDQWdZSE5oZG1WVmMyVnlVR2h2ZEc5Z0xGeHVJQ0FnSUNBZ0lDQWdJQ0FnZEdocGN5NTJhV1JsYjBOaGJuWmhjeTUwYjBSaGRHRlZVa3dvSjJsdFlXZGxMMnB3WldjbkxDQXhLU3hjYmlBZ0lDQWdJQ0FnSUNBZ0lHNWxkMVZ6WlhKSlpDeGNiaUFnSUNBZ0lDQWdJQ0FnSUhSb2FYTXVjM1JoZEdVdWRISmhhVzVwYm1kUWFHOTBiMGx1WkdWNFhHNGdJQ0FnSUNBZ0lDQWdLVnh1SUNBZ0lDQWdJQ0I5WEc0Z0lDQWdJQ0I5S1Z4dUlDQWdJSDBzSURFd01DbGNiaUFnZlZ4dVhHNGdJR05oYm1ObGJIUnlZV2x1YVc1bklEMGdLQ2tnUFQ0Z2UxeHVJQ0FnSUdOdmJuTjBJSHNnZFhObGNuTWdmU0E5SUhSb2FYTXVjSEp2Y0hOY2JseHVJQ0FnSUdOc1pXRnlTVzUwWlhKMllXd29kR2hwY3k1MGNtRnBibWx1WjBsdWRHVnlkbUZzS1Z4dVhHNGdJQ0FnWTI5dWMzUWdkWE5sY2tsa0lEMGdiR0Z6ZEZWelpYSkpaQ2gxYzJWeWN5a2dLeUF4WEc1Y2JpQWdJQ0IzYVc1a2IzY3VjMjlqYTJWMExtVnRhWFFvWUhKbGJXOTJaVlZ6WlhKZ0xDQjFjMlZ5U1dRcFhHNWNiaUFnSUNCMGFHbHpMbk5sZEZOMFlYUmxLSHNnYVhOVWNtRnBibWx1WnpvZ1ptRnNjMlVzSUhSeVlXbHVhVzVuVUdodmRHOUpibVJsZURvZ01DQjlLVnh1SUNBZ0lIUm9hWE11YzNSaGNuUkVaWFJsWTNScGJtY29LVnh1SUNCOVhHNWNiaUFnYUdGdVpHeGxWWE5sY2xSeVlXbHVibVZrSUQwZ2FXUWdQVDRnZTF4dUlDQWdJRkp2ZFhSbGNpNXdkWE5vS0dBdmNISnZabWxzWlQ5cFpEMGtlMmxrZlNacGMwNWxkejB4WUNsY2JpQWdmVnh1WEc0Z0lISmxibVJsY2lBb0tTQjdYRzRnSUNBZ1kyOXVjM1FnZXlCellYWmxaRlZ6WlhKT1lXMWxMQ0J6YUc5M1FXUmtWWE5sY2tKMWRIUnZiaXdnYVhOVWNtRnBibWx1Wnl3Z2RISmhhVzVwYm1kUWFHOTBiMGx1WkdWNElIMGdQU0IwYUdsekxuTjBZWFJsWEc1Y2JpQWdJQ0J5WlhSMWNtNGdLRnh1SUNBZ0lDQWdQRXhoZVc5MWRDQm9hV1JsU0dWaFpHVnlQWHNnYVhOVWNtRnBibWx1WnlCOUlHaHBaR1ZHYjI5MFpYSTlleUJwYzFSeVlXbHVhVzVuSUgwK1hHNGdJQ0FnSUNBZ0lIdHpZWFpsWkZWelpYSk9ZVzFsWEc0Z0lDQWdJQ0FnSUNBZ1B5QThUV1Z6YzJGblpWeHVJQ0FnSUNBZ0lDQWdJQ0FnYjI1RWFYTnRhWE56UFh0MGFHbHpMbTl1UkdsemJXbHpjMDFsYzNOaFoyVjlYRzRnSUNBZ0lDQWdJQ0FnSUNCb1pXRmtaWEk5ZTJCUVpYSm1hV3dnWENJa2UzTmhkbVZrVlhObGNrNWhiV1Y5WENJZ2MyRnNkbThnWTI5dElITjFZMlZ6YzI4dVlIMWNiaUFnSUNBZ0lDQWdJQ0FnSUc5dVEyeHBZMnM5ZTNSb2FYTXViMjVFYVhOdGFYTnpUV1Z6YzJGblpYMWNiaUFnSUNBZ0lDQWdJQ0F2UGx4dUlDQWdJQ0FnSUNBZ0lEb2dKeWRjYmlBZ0lDQWdJQ0FnZlZ4dVhHNGdJQ0FnSUNBZ0lEeGthWFkrWEc0Z0lDQWdJQ0FnSUNBZ1BFeHZZV1JsY2lCaFkzUnBkbVVnYVc1MlpYSjBaV1FnYzJsNlpUMWNJbTFoYzNOcGRtVmNJaUF2UGx4dVhHNGdJQ0FnSUNBZ0lDQWdQSFpwWkdWdlhHNGdJQ0FnSUNBZ0lDQWdJQ0J5WldZOWUyVnNJRDArSUhSb2FYTXVkbWxrWlc4Z1BTQmxiSDFjYmlBZ0lDQWdJQ0FnSUNBZ0lIZHBaSFJvUFh0allXNTJZWE5UYVhwbExuZHBaSFJvZlZ4dUlDQWdJQ0FnSUNBZ0lDQWdhR1ZwWjJoMFBYdGpZVzUyWVhOVGFYcGxMbWhsYVdkb2RIMWNiaUFnSUNBZ0lDQWdJQ0FnSUdGMWRHOVFiR0Y1WEc0Z0lDQWdJQ0FnSUNBZ0x6NWNibHh1SUNBZ0lDQWdJQ0FnSUR4allXNTJZWE5jYmlBZ0lDQWdJQ0FnSUNBZ0lISmxaajE3Wld3Z1BUNGdkR2hwY3k1MmFXUmxiME5oYm5aaGN5QTlJR1ZzZlZ4dUlDQWdJQ0FnSUNBZ0lDQWdZMnhoYzNOT1lXMWxQVndpZG1sa1pXOURZVzUyWVhOY0lseHVJQ0FnSUNBZ0lDQWdJQ0FnZDJsa2RHZzllMk5oYm5aaGMxTnBlbVV1ZDJsa2RHaDlYRzRnSUNBZ0lDQWdJQ0FnSUNCb1pXbG5hSFE5ZTJOaGJuWmhjMU5wZW1VdWFHVnBaMmgwZlZ4dUlDQWdJQ0FnSUNBZ0lDOCtYRzVjYmlBZ0lDQWdJQ0FnSUNBOFkyRnVkbUZ6WEc0Z0lDQWdJQ0FnSUNBZ0lDQnlaV1k5ZTJWc0lEMCtJSFJvYVhNdWIzWmxjbXhoZVVOaGJuWmhjeUE5SUdWc2ZWeHVJQ0FnSUNBZ0lDQWdJQ0FnWTJ4aGMzTk9ZVzFsUFh0Z2IzWmxjbXhoZVVOaGJuWmhjeUFrZTJselZISmhhVzVwYm1jZ1B5QW5hR2xrWkdWdUp5QTZJQ2NuZldCOVhHNGdJQ0FnSUNBZ0lDQWdJQ0IzYVdSMGFEMTdZMkZ1ZG1GelUybDZaUzUzYVdSMGFIMWNiaUFnSUNBZ0lDQWdJQ0FnSUdobGFXZG9kRDE3WTJGdWRtRnpVMmw2WlM1b1pXbG5hSFI5WEc0Z0lDQWdJQ0FnSUNBZ0x6NWNibHh1SUNBZ0lDQWdJQ0FnSUhzZ2FYTlVjbUZwYm1sdVoxeHVJQ0FnSUNBZ0lDQWdJQ0FnUHlBb1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUR4a2FYWWdZMnhoYzNOT1lXMWxQVndpZEhKaGFXNXBibWN0WTI5dWRHRnBibVZ5WENJK1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ1BGUnlZV2x1YVc1blQzWmxjbXhoZVNCd1pYSmpaVzUwWVdkbFBYdE5ZWFJvTG5KdmRXNWtLSFJ5WVdsdWFXNW5VR2h2ZEc5SmJtUmxlQ0F2SUhSeVlXbHVhVzVuVUdodmRHOXpRMjkxYm5RZ0tpQXhNREFwZlNBdlBseHVYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdlM1J5WVdsdWFXNW5VR2h2ZEc5SmJtUmxlQ0E4SUhSeVlXbHVhVzVuVUdodmRHOXpRMjkxYm5SY2JpQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lEOGdLRnh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBOFpHbDJQbHh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lEeENkWFIwYjI0Z1ltRnphV01nYVc1MlpYSjBaV1FnYjI1RGJHbGphejE3ZEdocGN5NWpZVzVqWld4MGNtRnBibWx1WjMwK1EyRnVZMlZzWVhJOEwwSjFkSFJ2Ymo1Y2JseHVJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4SVpXRmtaWElnWVhNOVhDSm9NVndpSUhSbGVIUkJiR2xuYmoxY0ltTmxiblJsY2x3aVBrTnlhV0hEcDhPamJ5QmtaU0J3WlhKbWFXd2daVzBnY0hKdlozSmxjM052TGk0dVBDOUlaV0ZrWlhJK1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnUEVobFlXUmxjaUJoY3oxY0ltZ3pYQ0lnZEdWNGRFRnNhV2R1UFZ3aVkyVnVkR1Z5WENJK1FXZDFZWEprWlNCbGJuRjFZVzUwYnlCdGIzWnBiV1Z1ZEdFZ1lTQmpZV0psdzZkaFBDOUlaV0ZrWlhJK1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJRHd2WkdsMlBseHVJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdLVnh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnT2lCdWRXeHNYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdmVnh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQThMMlJwZGo1Y2JpQWdJQ0FnSUNBZ0lDQWdJQ2xjYmlBZ0lDQWdJQ0FnSUNBZ0lEb2diblZzYkZ4dUlDQWdJQ0FnSUNBZ0lIMWNibHh1SUNBZ0lDQWdJQ0FnSUhzZ2MyaHZkMEZrWkZWelpYSkNkWFIwYjI1Y2JpQWdJQ0FnSUNBZ0lDQWdJRDhnS0Z4dUlDQWdJQ0FnSUNBZ0lDQWdJQ0E4WkdsMklHTnNZWE56VG1GdFpUMWNJbUoxZEhSdmJuTmNJajVjYmlBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0E4UW5WMGRHOXVYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0JqYjI1MFpXNTBQVndpUVdScFkybHZibUZ5SUZCbGNtWnBiRndpWEc0Z0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNCcFkyOXVQVndpWVdSa0lIVnpaWEpjSWx4dUlDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ2JHRmlaV3hRYjNOcGRHbHZiajFjSW14bFpuUmNJbHh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnWTI5c2IzSTlYQ0owWldGc1hDSmNiaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJSE5wZW1VOVhDSmlhV2RjSWx4dUlDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ2IyNURiR2xqYXoxN2RHaHBjeTUwY21GcGJrNWxkMVZ6WlhKOVhHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0x6NWNiaUFnSUNBZ0lDQWdJQ0FnSUNBZ1BDOWthWFkrWEc0Z0lDQWdJQ0FnSUNBZ0lDQXBYRzRnSUNBZ0lDQWdJQ0FnSUNBNklHNTFiR3hjYmlBZ0lDQWdJQ0FnSUNCOVhHNGdJQ0FnSUNBZ0lEd3ZaR2wyUGx4dVhHNGdJQ0FnSUNBZ0lEeHpkSGxzWlNCcWMzZytlMkJjYmlBZ0lDQWdJQ0FnSUNBNloyeHZZbUZzS0M1MWFTNXRaWE56WVdkbEtTQjdYRzRnSUNBZ0lDQWdJQ0FnSUNCaWIzZ3RjMmhoWkc5M09pQnViMjVsTzF4dUlDQWdJQ0FnSUNBZ0lDQWdiR1ZtZERvZ01qQndlRHRjYmlBZ0lDQWdJQ0FnSUNBZ0lIQnZjMmwwYVc5dU9pQmhZbk52YkhWMFpUdGNiaUFnSUNBZ0lDQWdJQ0FnSUhKcFoyaDBPaUF5TUhCNE8xeHVJQ0FnSUNBZ0lDQWdJQ0FnZEc5d09pQXlNSEI0TzF4dUlDQWdJQ0FnSUNBZ0lDQWdlaTFwYm1SbGVEb2dNVEF3TURBN1hHNGdJQ0FnSUNBZ0lDQWdmVnh1WEc0Z0lDQWdJQ0FnSUNBZ1pHbDJJRHBuYkc5aVlXd29MblZwTG14dllXUmxjaWtnZTF4dUlDQWdJQ0FnSUNBZ0lDQWdiR1ZtZERvZ05UQWxPMXh1SUNBZ0lDQWdJQ0FnSUNBZ2NHOXphWFJwYjI0NklHRmljMjlzZFhSbE8xeHVJQ0FnSUNBZ0lDQWdJQ0FnZEc5d09pQTFNQ1U3WEc0Z0lDQWdJQ0FnSUNBZ0lDQnRZWEpuYVc0NklDMHVOV1Z0SURBZ01DQXRMalZsYlR0Y2JpQWdJQ0FnSUNBZ0lDQWdJSG90YVc1a1pYZzZJREE3WEc0Z0lDQWdJQ0FnSUNBZ2ZWeHVYRzRnSUNBZ0lDQWdJQ0FnTG5acFpHVnZRMkZ1ZG1GeklIdGNiaUFnSUNBZ0lDQWdJQ0FnSUd4bFpuUTZJQzB4TURBd01EQndlRHRjYmlBZ0lDQWdJQ0FnSUNBZ0lIQnZjMmwwYVc5dU9pQmhZbk52YkhWMFpUdGNiaUFnSUNBZ0lDQWdJQ0FnSUhSdmNEb2dMVEV3TURBd01IQjRPMXh1SUNBZ0lDQWdJQ0FnSUgxY2JseHVJQ0FnSUNBZ0lDQWdJQzV2ZG1WeWJHRjVRMkZ1ZG1GekxGeHVJQ0FnSUNBZ0lDQWdJSFpwWkdWdklIdGNiaUFnSUNBZ0lDQWdJQ0FnSUd4bFpuUTZJREE3WEc0Z0lDQWdJQ0FnSUNBZ0lDQndiM05wZEdsdmJqb2dZV0p6YjJ4MWRHVTdYRzRnSUNBZ0lDQWdJQ0FnSUNCMGIzQTZJREE3WEc0Z0lDQWdJQ0FnSUNBZ2ZWeHVYRzRnSUNBZ0lDQWdJQ0FnTG05MlpYSnNZWGxEWVc1MllYTWdlMXh1SUNBZ0lDQWdJQ0FnSUNBZ2VpMXBibVJsZURvZ01qdGNiaUFnSUNBZ0lDQWdJQ0I5WEc1Y2JpQWdJQ0FnSUNBZ0lDQXVhR2xrWkdWdUlIdGNiaUFnSUNBZ0lDQWdJQ0FnSUdScGMzQnNZWGs2SUc1dmJtVTdYRzRnSUNBZ0lDQWdJQ0FnZlZ4dVhHNGdJQ0FnSUNBZ0lDQWdMbUoxZEhSdmJuTWdlMXh1SUNBZ0lDQWdJQ0FnSUNBZ2JHVm1kRG9nTlRBbE8xeHVJQ0FnSUNBZ0lDQWdJQ0FnY0c5emFYUnBiMjQ2SUdGaWMyOXNkWFJsTzF4dUlDQWdJQ0FnSUNBZ0lDQWdZbTkwZEc5dE9pQTBNSEI0TzF4dUlDQWdJQ0FnSUNBZ0lDQWdkSEpoYm5ObWIzSnRPaUIwY21GdWMyeGhkR1ZZS0MwMU1DVXBPMXh1SUNBZ0lDQWdJQ0FnSUNBZ2VpMXBibVJsZURvZ016dGNiaUFnSUNBZ0lDQWdJQ0I5WEc1Y2JpQWdJQ0FnSUNBZ0lDQXVkSEpoYVc1cGJtY3RZMjl1ZEdGcGJtVnlJSHRjYmlBZ0lDQWdJQ0FnSUNBZ0lDWWdaR2wySUh0Y2JpQWdJQ0FnSUNBZ0lDQWdJQ0FnWkdsemNHeGhlVG9nWm14bGVEdGNiaUFnSUNBZ0lDQWdJQ0FnSUNBZ1pteGxlQzFrYVhKbFkzUnBiMjQ2SUdOdmJIVnRianRjYmlBZ0lDQWdJQ0FnSUNBZ0lDQWdhblZ6ZEdsbWVTMWpiMjUwWlc1ME9pQm1iR1Y0TFdWdVpEdGNiaUFnSUNBZ0lDQWdJQ0FnSUNBZ2NHRmtaR2x1WnkxaWIzUjBiMjA2SURRd2NIZzdYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lIQnZjMmwwYVc5dU9pQmhZbk52YkhWMFpUdGNiaUFnSUNBZ0lDQWdJQ0FnSUNBZ2RHOXdPaUF3TzF4dUlDQWdJQ0FnSUNBZ0lDQWdJQ0JzWldaME9pQXdPMXh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQmliM1IwYjIwNklEQTdYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lISnBaMmgwT2lBd08xeHVJQ0FnSUNBZ0lDQWdJQ0FnSUNCNkxXbHVaR1Y0T2lBME8xeHVYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDWWdPbWRzYjJKaGJDZ3VkV2t1YUdWaFpHVnlLU0I3WEc0Z0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnWTI5c2IzSTZJQ05tWm1ZN1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ2JXRnlaMmx1T2lBNGNIZ2dNQ0F3SURBN1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUgxY2JpQWdJQ0FnSUNBZ0lDQWdJSDFjYmx4dUlDQWdJQ0FnSUNBZ0lDQWdKaUE2WjJ4dlltRnNLQzUxYVM1aWRYUjBiMjRwSUh0Y2JpQWdJQ0FnSUNBZ0lDQWdJQ0FnY0c5emFYUnBiMjQ2SUdGaWMyOXNkWFJsTzF4dUlDQWdJQ0FnSUNBZ0lDQWdJQ0IwYjNBNklEWXdjSGc3WEc0Z0lDQWdJQ0FnSUNBZ0lDQWdJSEpwWjJoME9pQTJNSEI0TzF4dUlDQWdJQ0FnSUNBZ0lDQWdmVnh1SUNBZ0lDQWdJQ0FnSUgxY2JpQWdJQ0FnSUNBZ1lIMDhMM04wZVd4bFBseHVJQ0FnSUNBZ1BDOU1ZWGx2ZFhRK1hHNGdJQ0FnS1Z4dUlDQjlYRzU5WEc1Y2JtVjRjRzl5ZENCa1pXWmhkV3gwSUhkcGRHaFNaV1IxZUNocGJtbDBVM1J2Y21Vc0lITjBZWFJsSUQwK0lITjBZWFJsS1NoSWIyMWxVR0ZuWlNsY2JpSmRmUT09ICovXG4vKkAgc291cmNlVVJMPXBhZ2VzL2luZGV4LmpzP2VudHJ5ICovIl19 */'
      }));
    }
  }]);

  return HomePage;
}(_react.Component);

exports.default = (0, _nextReduxWrapper2.default)(_store.initStore, function (state) {
  return state;
})(HomePage);

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/pages/index.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/pages/index.js"); } } })();
    (function (Component, route) {
      if (false) return
      if (false) return

      var qs = __webpack_require__(83)
      var params = qs.parse(__resourceQuery.slice(1))
      if (params.entry == null) return

      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(module.exports.default || module.exports, "/")
  
/* WEBPACK VAR INJECTION */}.call(exports, "?entry"))

/***/ }),

/***/ 955:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__(36);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(39);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(38);

var _inherits3 = _interopRequireDefault(_inherits2);

var _style = __webpack_require__(578);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(10);

var _react2 = _interopRequireDefault(_react);

var _nextReduxWrapper = __webpack_require__(697);

var _nextReduxWrapper2 = _interopRequireDefault(_nextReduxWrapper);

var _reactRedux = __webpack_require__(594);

var _semanticUiReact = __webpack_require__(602);

var _store = __webpack_require__(623);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Footer = function (_Component) {
  (0, _inherits3.default)(Footer, _Component);

  function Footer() {
    (0, _classCallCheck3.default)(this, Footer);

    return (0, _possibleConstructorReturn3.default)(this, (Footer.__proto__ || (0, _getPrototypeOf2.default)(Footer)).apply(this, arguments));
  }

  (0, _createClass3.default)(Footer, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var dispatch = this.props.dispatch;

      window.socket.on('connection-status', function (data) {
        dispatch((0, _store.setConnectionStatus)(data.type, data.status));
      });
    }
  }, {
    key: 'render',
    value: function render() {
      var _props$connection = this.props.connection,
          connection = _props$connection === undefined ? {} : _props$connection;

      return _react2.default.createElement('div', {
        'data-jsx': 3220516513
      }, _react2.default.createElement('footer', {
        'data-jsx': 3220516513
      }, _react2.default.createElement('span', {
        'data-jsx': 3220516513
      }, _react2.default.createElement(_semanticUiReact.Icon, { name: 'circle', size: 'small', color: connection.master ? 'green' : 'red' }), ' Master'), _react2.default.createElement('span', {
        'data-jsx': 3220516513
      }, _react2.default.createElement(_semanticUiReact.Icon, { name: 'circle', size: 'small', color: connection.slave ? 'green' : 'red' }), ' Slave')), _react2.default.createElement(_style2.default, {
        styleId: 3220516513,
        css: 'footer[data-jsx="3220516513"] {-webkit-box-align: center;-ms-flex-align: center;align-items: center;background: rgba(0, 0, 0, .6);color: #fff; display:-webkit-box; display:-ms-flexbox; display:flex;height: 30px;left: 0;padding: 0 10px;position: absolute;right: 0;bottom: 0;z-index: 1;}span[data-jsx="3220516513"] + span[data-jsx="3220516513"] {margin-left: 10px;}\n/*@ sourceURL=components/footer.js */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jbGF1ZGlhZmVycmVpcmEvR2l0SHViL1Byb2pldG9fbGFiX2ludF9JSS9pY2FyL2NvbXBvbmVudHMvZm9vdGVyLmpzIiwiY29tcG9uZW50cy9mb290ZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBMEJvQiwrQkFFWSwwQkFDVSxBQURWLHVCQUNVLEFBRFYsb0JBQ1UsOEJBQ2xCLFlBQ0UsQ0FBQSxvQkFDRCxDQURDLG9CQUNELENBREMsYUFDRCxhQUNMLFFBQ1EsZ0JBQ0csbUJBQ1YsU0FDQyxVQUNDLFdBQ1osQ0FFWSwyREFDTyxrQkFDbkIsQ0FBQTtBQ3pDWCxxQ0FBcUMiLCJmaWxlIjoidG8uY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHdpdGhSZWR1eCBmcm9tICduZXh0LXJlZHV4LXdyYXBwZXInXG5pbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCB7IEljb24gfSBmcm9tICdzZW1hbnRpYy11aS1yZWFjdCdcblxuaW1wb3J0IHsgaW5pdFN0b3JlLCBzZXRDb25uZWN0aW9uU3RhdHVzIH0gZnJvbSAnLi4vaGVscGVycy9zdG9yZSdcblxuY2xhc3MgRm9vdGVyIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgY29uc3QgeyBkaXNwYXRjaCB9ID0gdGhpcy5wcm9wc1xuXG4gICAgd2luZG93LnNvY2tldC5vbignY29ubmVjdGlvbi1zdGF0dXMnLCAoZGF0YSkgPT4ge1xuICAgICAgZGlzcGF0Y2goc2V0Q29ubmVjdGlvblN0YXR1cyhkYXRhLnR5cGUsIGRhdGEuc3RhdHVzKSlcbiAgICB9KVxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHsgY29ubmVjdGlvbiA9IHt9IH0gPSB0aGlzLnByb3BzO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXY+XG4gICAgICAgIDxmb290ZXI+XG4gICAgICAgICAgPHNwYW4+PEljb24gbmFtZT1cImNpcmNsZVwiIHNpemU9XCJzbWFsbFwiIGNvbG9yPXsgY29ubmVjdGlvbi5tYXN0ZXIgPyAnZ3JlZW4nIDogJ3JlZCcgfSAvPiBNYXN0ZXI8L3NwYW4+XG4gICAgICAgICAgPHNwYW4+PEljb24gbmFtZT1cImNpcmNsZVwiIHNpemU9XCJzbWFsbFwiIGNvbG9yPXsgY29ubmVjdGlvbi5zbGF2ZSA/ICdncmVlbicgOiAncmVkJyB9IC8+IFNsYXZlPC9zcGFuPlxuICAgICAgICA8L2Zvb3Rlcj5cblxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgZm9vdGVyIHtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIC42KTtcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICBwYWRkaW5nOiAwIDEwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIGJvdHRvbTogMDtcbiAgICAgICAgICAgIHotaW5kZXg6IDE7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgc3BhbiArIHNwYW4ge1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgd2l0aFJlZHV4KGluaXRTdG9yZSwgc3RhdGUgPT4gc3RhdGUsIGRpc3BhdGNoID0+ICh7IGRpc3BhdGNoIH0pKShGb290ZXIpXG4iLCJmb290ZXJbZGF0YS1qc3g9XCIzMjIwNTE2NTEzXCJdIHthbGlnbi1pdGVtczogY2VudGVyO2JhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgLjYpO2NvbG9yOiAjZmZmO2Rpc3BsYXk6LXdlYmtpdC1mbGV4OyBkaXNwbGF5OmZsZXg7aGVpZ2h0OiAzMHB4O2xlZnQ6IDA7cGFkZGluZzogMCAxMHB4O3Bvc2l0aW9uOiBhYnNvbHV0ZTtyaWdodDogMDtib3R0b206IDA7ei1pbmRleDogMTt9c3BhbltkYXRhLWpzeD1cIjMyMjA1MTY1MTNcIl0gKyBzcGFuW2RhdGEtanN4PVwiMzIyMDUxNjUxM1wiXSB7bWFyZ2luLWxlZnQ6IDEwcHg7fVxuLyojIHNvdXJjZU1hcHBpbmdVUkw9ZGF0YTphcHBsaWNhdGlvbi9qc29uO2Jhc2U2NCxleUoyWlhKemFXOXVJam96TENKemIzVnlZMlZ6SWpwYkltTnZiWEJ2Ym1WdWRITXZabTl2ZEdWeUxtcHpJbDBzSW01aGJXVnpJanBiWFN3aWJXRndjR2x1WjNNaU9pSkJRVEJDYjBJc1FVRkRSaXdyUWtGRFl5eHZRa0ZEVlN3NFFrRkRiRUlzV1VGRFJTeHRRMEZEUkN4aFFVTk1MRkZCUTFFc1owSkJRMGNzYlVKQlExWXNVMEZEUXl4VlFVTkRMRmRCUTFvc1EwRkZXU3d5UkVGRFR5eHJRa0ZEYmtJaUxDSm1hV3hsSWpvaVkyOXRjRzl1Wlc1MGN5OW1iMjkwWlhJdWFuTWlMQ0p6YjNWeVkyVlNiMjkwSWpvaUwxVnpaWEp6TDJOc1lYVmthV0ZtWlhKeVpXbHlZUzlIYVhSSWRXSXZVSEp2YW1WMGIxOXNZV0pmYVc1MFgwbEpMMmxqWVhJaUxDSnpiM1Z5WTJWelEyOXVkR1Z1ZENJNld5SnBiWEJ2Y25RZ2QybDBhRkpsWkhWNElHWnliMjBnSjI1bGVIUXRjbVZrZFhndGQzSmhjSEJsY2lkY2JtbHRjRzl5ZENCN0lFTnZiWEJ2Ym1WdWRDQjlJR1p5YjIwZ0ozSmxZV04wSjF4dWFXMXdiM0owSUhzZ1kyOXVibVZqZENCOUlHWnliMjBnSjNKbFlXTjBMWEpsWkhWNEoxeHVhVzF3YjNKMElIc2dTV052YmlCOUlHWnliMjBnSjNObGJXRnVkR2xqTFhWcExYSmxZV04wSjF4dVhHNXBiWEJ2Y25RZ2V5QnBibWwwVTNSdmNtVXNJSE5sZEVOdmJtNWxZM1JwYjI1VGRHRjBkWE1nZlNCbWNtOXRJQ2N1TGk5b1pXeHdaWEp6TDNOMGIzSmxKMXh1WEc1amJHRnpjeUJHYjI5MFpYSWdaWGgwWlc1a2N5QkRiMjF3YjI1bGJuUWdlMXh1SUNCamIyMXdiMjVsYm5SRWFXUk5iM1Z1ZENncElIdGNiaUFnSUNCamIyNXpkQ0I3SUdScGMzQmhkR05vSUgwZ1BTQjBhR2x6TG5CeWIzQnpYRzVjYmlBZ0lDQjNhVzVrYjNjdWMyOWphMlYwTG05dUtDZGpiMjV1WldOMGFXOXVMWE4wWVhSMWN5Y3NJQ2hrWVhSaEtTQTlQaUI3WEc0Z0lDQWdJQ0JrYVhOd1lYUmphQ2h6WlhSRGIyNXVaV04wYVc5dVUzUmhkSFZ6S0dSaGRHRXVkSGx3WlN3Z1pHRjBZUzV6ZEdGMGRYTXBLVnh1SUNBZ0lIMHBYRzRnSUgxY2JseHVJQ0J5Wlc1a1pYSW9LU0I3WEc0Z0lDQWdZMjl1YzNRZ2V5QmpiMjV1WldOMGFXOXVJRDBnZTMwZ2ZTQTlJSFJvYVhNdWNISnZjSE03WEc1Y2JpQWdJQ0J5WlhSMWNtNGdLRnh1SUNBZ0lDQWdQR1JwZGo1Y2JpQWdJQ0FnSUNBZ1BHWnZiM1JsY2o1Y2JpQWdJQ0FnSUNBZ0lDQThjM0JoYmo0OFNXTnZiaUJ1WVcxbFBWd2lZMmx5WTJ4bFhDSWdjMmw2WlQxY0luTnRZV3hzWENJZ1kyOXNiM0k5ZXlCamIyNXVaV04wYVc5dUxtMWhjM1JsY2lBL0lDZG5jbVZsYmljZ09pQW5jbVZrSnlCOUlDOCtJRTFoYzNSbGNqd3ZjM0JoYmo1Y2JpQWdJQ0FnSUNBZ0lDQThjM0JoYmo0OFNXTnZiaUJ1WVcxbFBWd2lZMmx5WTJ4bFhDSWdjMmw2WlQxY0luTnRZV3hzWENJZ1kyOXNiM0k5ZXlCamIyNXVaV04wYVc5dUxuTnNZWFpsSUQ4Z0oyZHlaV1Z1SnlBNklDZHlaV1FuSUgwZ0x6NGdVMnhoZG1VOEwzTndZVzQrWEc0Z0lDQWdJQ0FnSUR3dlptOXZkR1Z5UGx4dVhHNGdJQ0FnSUNBZ0lEeHpkSGxzWlNCcWMzZytlMkJjYmlBZ0lDQWdJQ0FnSUNCbWIyOTBaWElnZTF4dUlDQWdJQ0FnSUNBZ0lDQWdZV3hwWjI0dGFYUmxiWE02SUdObGJuUmxjanRjYmlBZ0lDQWdJQ0FnSUNBZ0lHSmhZMnRuY205MWJtUTZJSEpuWW1Fb01Dd2dNQ3dnTUN3Z0xqWXBPMXh1SUNBZ0lDQWdJQ0FnSUNBZ1kyOXNiM0k2SUNObVptWTdYRzRnSUNBZ0lDQWdJQ0FnSUNCa2FYTndiR0Y1T2lCbWJHVjRPMXh1SUNBZ0lDQWdJQ0FnSUNBZ2FHVnBaMmgwT2lBek1IQjRPMXh1SUNBZ0lDQWdJQ0FnSUNBZ2JHVm1kRG9nTUR0Y2JpQWdJQ0FnSUNBZ0lDQWdJSEJoWkdScGJtYzZJREFnTVRCd2VEdGNiaUFnSUNBZ0lDQWdJQ0FnSUhCdmMybDBhVzl1T2lCaFluTnZiSFYwWlR0Y2JpQWdJQ0FnSUNBZ0lDQWdJSEpwWjJoME9pQXdPMXh1SUNBZ0lDQWdJQ0FnSUNBZ1ltOTBkRzl0T2lBd08xeHVJQ0FnSUNBZ0lDQWdJQ0FnZWkxcGJtUmxlRG9nTVR0Y2JpQWdJQ0FnSUNBZ0lDQjlYRzVjYmlBZ0lDQWdJQ0FnSUNCemNHRnVJQ3NnYzNCaGJpQjdYRzRnSUNBZ0lDQWdJQ0FnSUNCdFlYSm5hVzR0YkdWbWREb2dNVEJ3ZUR0Y2JpQWdJQ0FnSUNBZ0lDQjlYRzRnSUNBZ0lDQWdJR0I5UEM5emRIbHNaVDVjYmlBZ0lDQWdJRHd2WkdsMlBseHVJQ0FnSUNsY2JpQWdmVnh1ZlZ4dVhHNWxlSEJ2Y25RZ1pHVm1ZWFZzZENCM2FYUm9VbVZrZFhnb2FXNXBkRk4wYjNKbExDQnpkR0YwWlNBOVBpQnpkR0YwWlN3Z1pHbHpjR0YwWTJnZ1BUNGdLSHNnWkdsemNHRjBZMmdnZlNrcEtFWnZiM1JsY2lsY2JpSmRmUT09ICovXG4vKkAgc291cmNlVVJMPWNvbXBvbmVudHMvZm9vdGVyLmpzICovIl19 */'
      }));
    }
  }]);

  return Footer;
}(_react.Component);

exports.default = (0, _nextReduxWrapper2.default)(_store.initStore, function (state) {
  return state;
}, function (dispatch) {
  return { dispatch: dispatch };
})(Footer);

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/footer.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/footer.js"); } } })();

/***/ }),

/***/ 956:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__(36);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(39);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(38);

var _inherits3 = _interopRequireDefault(_inherits2);

var _style = __webpack_require__(578);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(10);

var _react2 = _interopRequireDefault(_react);

var _reactRedux = __webpack_require__(594);

var _semanticUiReact = __webpack_require__(602);

var _link = __webpack_require__(698);

var _link2 = _interopRequireDefault(_link);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var getTime = function getTime() {
  var options = {
    hour: 'numeric',
    minute: 'numeric'
  };

  return new Intl.DateTimeFormat('pt-PT', options).format(new Date());
};

var Header = function (_Component) {
  (0, _inherits3.default)(Header, _Component);

  function Header() {
    var _ref;

    var _temp, _this, _ret;

    (0, _classCallCheck3.default)(this, Header);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = (0, _possibleConstructorReturn3.default)(this, (_ref = Header.__proto__ || (0, _getPrototypeOf2.default)(Header)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
      time: getTime()
    }, _temp), (0, _possibleConstructorReturn3.default)(_this, _ret);
  }

  (0, _createClass3.default)(Header, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      var _this2 = this;

      this.interval = setInterval(function () {
        return _this2.setState({ time: getTime() });
      }, 1000);
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      clearInterval(this.interval);
    }
  }, {
    key: 'render',
    value: function render() {
      var _props = this.props,
          currentUser = _props.currentUser,
          classes = _props.classes;
      var time = this.state.time;

      if (!currentUser) {
        return null;
      }

      return _react2.default.createElement('div', {
        'data-jsx': 2718529026
      }, _react2.default.createElement('header', { className: 'container', 'data-jsx': 2718529026
      }, _react2.default.createElement('div', {
        'data-jsx': 2718529026
      }, _react2.default.createElement(_semanticUiReact.Icon, { name: 'signal' }), _react2.default.createElement(_semanticUiReact.Icon, { name: 'bluetooth alternative' }), _react2.default.createElement(_semanticUiReact.Icon, { name: 'clock' }), _react2.default.createElement(_semanticUiReact.Header, { as: 'h4' }, time)), _react2.default.createElement('div', {
        'data-jsx': 2718529026
      }, currentUser ? _react2.default.createElement(_semanticUiReact.Header, { as: 'h4' }, currentUser.name) : null), _react2.default.createElement('div', {
        'data-jsx': 2718529026
      }, _react2.default.createElement(_link2.default, { href: '/select-profile' }, _react2.default.createElement('a', { className: 'ui button icon basic inverted profiles-button', 'data-jsx': 2718529026
      }, 'Perfis ', _react2.default.createElement(_semanticUiReact.Icon, { name: 'right arrow' }))))), _react2.default.createElement(_style2.default, {
        styleId: 2718529026,
        css: 'header[data-jsx="2718529026"] {-webkit-box-align: center;-ms-flex-align: center;align-items: center;background: rgba(34, 39, 53, .6);color: rgba(255, 255, 255, .6); display:-webkit-box; display:-ms-flexbox; display:flex;height: 30px;-webkit-box-pack: justify;-ms-flex-pack: justify;justify-content: space-between;left: 0;padding: 0 0 0 10px;position: absolute;right: 0;top: 0;z-index: 1000;}.container[data-jsx="2718529026"] .ui.basic.button.profiles-button {box-shadow: none !important;font-size: 16px;}.container[data-jsx="2718529026"] .ui.basic.button.profiles-button .icon {font-size: 15px;}div[data-jsx="2718529026"] {-webkit-box-align: center;-ms-flex-align: center;align-items: center; display:-webkit-box; display:-ms-flexbox; display:flex}div[data-jsx="2718529026"][data-jsx="2718529026"] [data-jsx="2718529026"]:nth-child(2) {position: absolute;left: 50%;-webkit-transform: translateX(-50%);transform: translateX(-50%);}header[data-jsx="2718529026"] .icon {line-height: 1;}header[data-jsx="2718529026"] .ui.header {color: rgba(255, 255, 255, .6);margin: 0;}\n/*@ sourceURL=components/header.js */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jbGF1ZGlhZmVycmVpcmEvR2l0SHViL1Byb2pldG9fbGFiX2ludF9JSS9pY2FyL2NvbXBvbmVudHMvaGVhZGVyLmpzIiwiY29tcG9uZW50cy9oZWFkZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBNkRvQiwrQkFFWSwwQkFDYSxBQURiLHVCQUNhLEFBRGIsb0JBQ2EsaUNBQ0YsK0JBQ2pCLENBQUEsb0JBQ0QsQ0FEQyxvQkFDRCxDQURDLGFBQ0QsYUFDa0IsMEJBQ3ZCLEFBRHVCLHVCQUN2QixBQUR1QiwrQkFDdkIsUUFDWSxvQkFDRCxtQkFDVixTQUNGLE9BQ08sY0FDZixDQUVxRCxvRUFDeEIsNEJBQ1osZ0JBQ2pCLENBRW9FLDBFQUNuRCxnQkFDakIsQ0FFSSw0QkFDaUIsMEJBQ04sQUFETSx1QkFDTixBQURNLG9CQUNOLENBQUEsb0JBRUcsQ0FGSCxvQkFFRyxDQUZILFlBRUcsQ0FPSSxBQVBKLHdGQUNJLG1CQUNULFVBQ2tCLG9DQUFBLDRCQUM3QixDQUNGLEFBRXNCLHFDQUNOLGVBQ2hCLENBRTJCLDBDQUNLLCtCQUNyQixVQUNYLENBQUE7QUN0R1gscUNBQXFDIiwiZmlsZSI6InRvLmNzcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHsgSWNvbiwgSGVhZGVyIGFzIEggfSBmcm9tICdzZW1hbnRpYy11aS1yZWFjdCdcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcblxuY29uc3QgZ2V0VGltZSA9ICgpID0+IHtcbiAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICBob3VyOiAnbnVtZXJpYycsXG4gICAgbWludXRlOiAnbnVtZXJpYycsXG4gIH1cblxuICByZXR1cm4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoJ3B0LVBUJywgb3B0aW9ucykuZm9ybWF0KG5ldyBEYXRlKCkpXG59XG5cbmNsYXNzIEhlYWRlciBleHRlbmRzIENvbXBvbmVudCB7XG4gIHN0YXRlID0ge1xuICAgIHRpbWU6IGdldFRpbWUoKSxcbiAgfVxuXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIHRoaXMuaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB0aGlzLnNldFN0YXRlKHsgdGltZTogZ2V0VGltZSgpIH0pLCAxMDAwKVxuICB9XG5cbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgY2xlYXJJbnRlcnZhbCh0aGlzLmludGVydmFsKVxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHsgY3VycmVudFVzZXIsIGNsYXNzZXMgfSA9IHRoaXMucHJvcHNcbiAgICBjb25zdCB7IHRpbWUgfSA9IHRoaXMuc3RhdGVcblxuICAgIGlmICghY3VycmVudFVzZXIpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInNpZ25hbFwiIC8+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwiYmx1ZXRvb3RoIGFsdGVybmF0aXZlXCIgLz5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjbG9ja1wiIC8+XG4gICAgICAgICAgICA8SCBhcz1cImg0XCI+e3RpbWV9PC9IPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHsgY3VycmVudFVzZXJcbiAgICAgICAgICAgICAgPyA8SCBhcz1cImg0XCI+e2N1cnJlbnRVc2VyLm5hbWV9PC9IPlxuICAgICAgICAgICAgICA6IG51bGxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8TGluayBocmVmPVwiL3NlbGVjdC1wcm9maWxlXCI+XG4gICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInVpIGJ1dHRvbiBpY29uIGJhc2ljIGludmVydGVkIHByb2ZpbGVzLWJ1dHRvblwiPlxuICAgICAgICAgICAgICAgIFBlcmZpcyA8SWNvbiBuYW1lPVwicmlnaHQgYXJyb3dcIiAvPlxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICBoZWFkZXIge1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMzQsIDM5LCA1MywgLjYpO1xuICAgICAgICAgICAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgLjYpO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICBwYWRkaW5nOiAwIDAgMCAxMHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICB6LWluZGV4OiAxMDAwO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5jb250YWluZXIgOmdsb2JhbCgudWkuYmFzaWMuYnV0dG9uLnByb2ZpbGVzLWJ1dHRvbikge1xuICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5jb250YWluZXIgOmdsb2JhbCgudWkuYmFzaWMuYnV0dG9uLnByb2ZpbGVzLWJ1dHRvbikgOmdsb2JhbCguaWNvbikge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGRpdiB7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcblxuICAgICAgICAgICAgJiA6bnRoLWNoaWxkKDIpIHtcbiAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBoZWFkZXIgOmdsb2JhbCguaWNvbikge1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaGVhZGVyIDpnbG9iYWwoLnVpLmhlYWRlcikge1xuICAgICAgICAgICAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgLjYpO1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3Qoc3RhdGUgPT4gc3RhdGUpKEhlYWRlcilcbiIsImhlYWRlcltkYXRhLWpzeD1cIjI3MTg1MjkwMjZcIl0ge2FsaWduLWl0ZW1zOiBjZW50ZXI7YmFja2dyb3VuZDogcmdiYSgzNCwgMzksIDUzLCAuNik7Y29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgLjYpO2Rpc3BsYXk6LXdlYmtpdC1mbGV4OyBkaXNwbGF5OmZsZXg7aGVpZ2h0OiAzMHB4O2p1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtsZWZ0OiAwO3BhZGRpbmc6IDAgMCAwIDEwcHg7cG9zaXRpb246IGFic29sdXRlO3JpZ2h0OiAwO3RvcDogMDt6LWluZGV4OiAxMDAwO30uY29udGFpbmVyW2RhdGEtanN4PVwiMjcxODUyOTAyNlwiXSAudWkuYmFzaWMuYnV0dG9uLnByb2ZpbGVzLWJ1dHRvbiB7Ym94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMTZweDt9LmNvbnRhaW5lcltkYXRhLWpzeD1cIjI3MTg1MjkwMjZcIl0gLnVpLmJhc2ljLmJ1dHRvbi5wcm9maWxlcy1idXR0b24gLmljb24ge2ZvbnQtc2l6ZTogMTVweDt9ZGl2W2RhdGEtanN4PVwiMjcxODUyOTAyNlwiXSB7YWxpZ24taXRlbXM6IGNlbnRlcjtkaXNwbGF5Oi13ZWJraXQtZmxleDsgZGlzcGxheTpmbGV4OyZbZGF0YS1qc3g9XCIyNzE4NTI5MDI2XCJdIFtkYXRhLWpzeD1cIjI3MTg1MjkwMjZcIl06bnRoLWNoaWxkKDIpIHtwb3NpdGlvbjogYWJzb2x1dGU7bGVmdDogNTAlOy13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpOy1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpOy1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7dHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO319aGVhZGVyW2RhdGEtanN4PVwiMjcxODUyOTAyNlwiXSAuaWNvbiB7bGluZS1oZWlnaHQ6IDE7fWhlYWRlcltkYXRhLWpzeD1cIjI3MTg1MjkwMjZcIl0gLnVpLmhlYWRlciB7Y29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgLjYpO21hcmdpbjogMDt9XG4vKiMgc291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247YmFzZTY0LGV5SjJaWEp6YVc5dUlqb3pMQ0p6YjNWeVkyVnpJanBiSW1OdmJYQnZibVZ1ZEhNdmFHVmhaR1Z5TG1weklsMHNJbTVoYldWeklqcGJYU3dpYldGd2NHbHVaM01pT2lKQlFUWkViMElzUVVGRFJpd3JRa0ZEWXl4dlFrRkRZU3hwUTBGRFJpd3JRa0ZEYWtJc2JVTkJRMFFzWVVGRGEwSXNLMEpCUTNaQ0xGRkJRMWtzYjBKQlEwUXNiVUpCUTFZc1UwRkRSaXhQUVVOUExHTkJRMllzUTBGRmNVUXNiMFZCUTNoQ0xEUkNRVU5hTEdkQ1FVTnFRaXhEUVVWdlJTd3dSVUZEYmtRc1owSkJRMnBDTEVOQlJVa3NORUpCUTJsQ0xHOUNRVU5PTEcxRFFVVkhMQ3RFUVVOSkxHMUNRVU5VTEZWQlEydENMR2xKUVVNM1FpeERRVU5HTEVOQlJYTkNMSEZEUVVOT0xHVkJRMmhDTEVOQlJUSkNMREJEUVVOTExDdENRVU55UWl4VlFVTllJaXdpWm1sc1pTSTZJbU52YlhCdmJtVnVkSE12YUdWaFpHVnlMbXB6SWl3aWMyOTFjbU5sVW05dmRDSTZJaTlWYzJWeWN5OWpiR0YxWkdsaFptVnljbVZwY21FdlIybDBTSFZpTDFCeWIycGxkRzlmYkdGaVgybHVkRjlKU1M5cFkyRnlJaXdpYzI5MWNtTmxjME52Ym5SbGJuUWlPbHNpYVcxd2IzSjBJSHNnUTI5dGNHOXVaVzUwSUgwZ1puSnZiU0FuY21WaFkzUW5YRzVwYlhCdmNuUWdleUJqYjI1dVpXTjBJSDBnWm5KdmJTQW5jbVZoWTNRdGNtVmtkWGduWEc1cGJYQnZjblFnZXlCSlkyOXVMQ0JJWldGa1pYSWdZWE1nU0NCOUlHWnliMjBnSjNObGJXRnVkR2xqTFhWcExYSmxZV04wSjF4dWFXMXdiM0owSUV4cGJtc2dabkp2YlNBbmJtVjRkQzlzYVc1ckoxeHVYRzVqYjI1emRDQm5aWFJVYVcxbElEMGdLQ2tnUFQ0Z2UxeHVJQ0JqYjI1emRDQnZjSFJwYjI1eklEMGdlMXh1SUNBZ0lHaHZkWEk2SUNkdWRXMWxjbWxqSnl4Y2JpQWdJQ0J0YVc1MWRHVTZJQ2R1ZFcxbGNtbGpKeXhjYmlBZ2ZWeHVYRzRnSUhKbGRIVnliaUJ1WlhjZ1NXNTBiQzVFWVhSbFZHbHRaVVp2Y20xaGRDZ25jSFF0VUZRbkxDQnZjSFJwYjI1ektTNW1iM0p0WVhRb2JtVjNJRVJoZEdVb0tTbGNibjFjYmx4dVkyeGhjM01nU0dWaFpHVnlJR1Y0ZEdWdVpITWdRMjl0Y0c5dVpXNTBJSHRjYmlBZ2MzUmhkR1VnUFNCN1hHNGdJQ0FnZEdsdFpUb2daMlYwVkdsdFpTZ3BMRnh1SUNCOVhHNWNiaUFnWTI5dGNHOXVaVzUwUkdsa1RXOTFiblFvS1NCN1hHNGdJQ0FnZEdocGN5NXBiblJsY25aaGJDQTlJSE5sZEVsdWRHVnlkbUZzS0NncElEMCtJSFJvYVhNdWMyVjBVM1JoZEdVb2V5QjBhVzFsT2lCblpYUlVhVzFsS0NrZ2ZTa3NJREV3TURBcFhHNGdJSDFjYmx4dUlDQmpiMjF3YjI1bGJuUlhhV3hzVlc1dGIzVnVkQ2dwSUh0Y2JpQWdJQ0JqYkdWaGNrbHVkR1Z5ZG1Gc0tIUm9hWE11YVc1MFpYSjJZV3dwWEc0Z0lIMWNibHh1SUNCeVpXNWtaWElvS1NCN1hHNGdJQ0FnWTI5dWMzUWdleUJqZFhKeVpXNTBWWE5sY2l3Z1kyeGhjM05sY3lCOUlEMGdkR2hwY3k1d2NtOXdjMXh1SUNBZ0lHTnZibk4wSUhzZ2RHbHRaU0I5SUQwZ2RHaHBjeTV6ZEdGMFpWeHVYRzRnSUNBZ2FXWWdLQ0ZqZFhKeVpXNTBWWE5sY2lrZ2UxeHVJQ0FnSUNBZ0lDQnlaWFIxY200Z2JuVnNiRnh1SUNBZ0lIMWNibHh1SUNBZ0lISmxkSFZ5YmlBb1hHNGdJQ0FnSUNBOFpHbDJQbHh1SUNBZ0lDQWdJQ0E4YUdWaFpHVnlJR05zWVhOelRtRnRaVDFjSW1OdmJuUmhhVzVsY2x3aVBseHVJQ0FnSUNBZ0lDQWdJRHhrYVhZK1hHNGdJQ0FnSUNBZ0lDQWdJQ0E4U1dOdmJpQnVZVzFsUFZ3aWMybG5ibUZzWENJZ0x6NWNiaUFnSUNBZ0lDQWdJQ0FnSUR4SlkyOXVJRzVoYldVOVhDSmliSFZsZEc5dmRHZ2dZV3gwWlhKdVlYUnBkbVZjSWlBdlBseHVJQ0FnSUNBZ0lDQWdJQ0FnUEVsamIyNGdibUZ0WlQxY0ltTnNiMk5yWENJZ0x6NWNiaUFnSUNBZ0lDQWdJQ0FnSUR4SUlHRnpQVndpYURSY0lqNTdkR2x0WlgwOEwwZytYRzRnSUNBZ0lDQWdJQ0FnUEM5a2FYWStYRzVjYmlBZ0lDQWdJQ0FnSUNBOFpHbDJQbHh1SUNBZ0lDQWdJQ0FnSUNBZ2V5QmpkWEp5Wlc1MFZYTmxjbHh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQS9JRHhJSUdGelBWd2lhRFJjSWo1N1kzVnljbVZ1ZEZWelpYSXVibUZ0WlgwOEwwZytYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lEb2diblZzYkZ4dUlDQWdJQ0FnSUNBZ0lDQWdmVnh1SUNBZ0lDQWdJQ0FnSUR3dlpHbDJQbHh1WEc0Z0lDQWdJQ0FnSUNBZ1BHUnBkajVjYmlBZ0lDQWdJQ0FnSUNBZ0lEeE1hVzVySUdoeVpXWTlYQ0l2YzJWc1pXTjBMWEJ5YjJacGJHVmNJajVjYmlBZ0lDQWdJQ0FnSUNBZ0lDQWdQR0VnWTJ4aGMzTk9ZVzFsUFZ3aWRXa2dZblYwZEc5dUlHbGpiMjRnWW1GemFXTWdhVzUyWlhKMFpXUWdjSEp2Wm1sc1pYTXRZblYwZEc5dVhDSStYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdVR1Z5Wm1seklEeEpZMjl1SUc1aGJXVTlYQ0p5YVdkb2RDQmhjbkp2ZDF3aUlDOCtYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lEd3ZZVDVjYmlBZ0lDQWdJQ0FnSUNBZ0lEd3ZUR2x1YXo1Y2JpQWdJQ0FnSUNBZ0lDQThMMlJwZGo1Y2JpQWdJQ0FnSUNBZ1BDOW9aV0ZrWlhJK1hHNWNiaUFnSUNBZ0lDQWdQSE4wZVd4bElHcHplRDU3WUZ4dUlDQWdJQ0FnSUNBZ0lHaGxZV1JsY2lCN1hHNGdJQ0FnSUNBZ0lDQWdJQ0JoYkdsbmJpMXBkR1Z0Y3pvZ1kyVnVkR1Z5TzF4dUlDQWdJQ0FnSUNBZ0lDQWdZbUZqYTJkeWIzVnVaRG9nY21kaVlTZ3pOQ3dnTXprc0lEVXpMQ0F1TmlrN1hHNGdJQ0FnSUNBZ0lDQWdJQ0JqYjJ4dmNqb2djbWRpWVNneU5UVXNJREkxTlN3Z01qVTFMQ0F1TmlrN1hHNGdJQ0FnSUNBZ0lDQWdJQ0JrYVhOd2JHRjVPaUJtYkdWNE8xeHVJQ0FnSUNBZ0lDQWdJQ0FnYUdWcFoyaDBPaUF6TUhCNE8xeHVJQ0FnSUNBZ0lDQWdJQ0FnYW5WemRHbG1lUzFqYjI1MFpXNTBPaUJ6Y0dGalpTMWlaWFIzWldWdU8xeHVJQ0FnSUNBZ0lDQWdJQ0FnYkdWbWREb2dNRHRjYmlBZ0lDQWdJQ0FnSUNBZ0lIQmhaR1JwYm1jNklEQWdNQ0F3SURFd2NIZzdYRzRnSUNBZ0lDQWdJQ0FnSUNCd2IzTnBkR2x2YmpvZ1lXSnpiMngxZEdVN1hHNGdJQ0FnSUNBZ0lDQWdJQ0J5YVdkb2REb2dNRHRjYmlBZ0lDQWdJQ0FnSUNBZ0lIUnZjRG9nTUR0Y2JpQWdJQ0FnSUNBZ0lDQWdJSG90YVc1a1pYZzZJREV3TURBN1hHNGdJQ0FnSUNBZ0lDQWdmVnh1WEc0Z0lDQWdJQ0FnSUNBZ0xtTnZiblJoYVc1bGNpQTZaMnh2WW1Gc0tDNTFhUzVpWVhOcFl5NWlkWFIwYjI0dWNISnZabWxzWlhNdFluVjBkRzl1S1NCN1hHNGdJQ0FnSUNBZ0lDQWdJQ0JpYjNndGMyaGhaRzkzT2lCdWIyNWxJQ0ZwYlhCdmNuUmhiblE3WEc0Z0lDQWdJQ0FnSUNBZ0lDQm1iMjUwTFhOcGVtVTZJREUyY0hnN1hHNGdJQ0FnSUNBZ0lDQWdmVnh1WEc0Z0lDQWdJQ0FnSUNBZ0xtTnZiblJoYVc1bGNpQTZaMnh2WW1Gc0tDNTFhUzVpWVhOcFl5NWlkWFIwYjI0dWNISnZabWxzWlhNdFluVjBkRzl1S1NBNloyeHZZbUZzS0M1cFkyOXVLU0I3WEc0Z0lDQWdJQ0FnSUNBZ0lDQm1iMjUwTFhOcGVtVTZJREUxY0hnN1hHNGdJQ0FnSUNBZ0lDQWdmVnh1WEc0Z0lDQWdJQ0FnSUNBZ1pHbDJJSHRjYmlBZ0lDQWdJQ0FnSUNBZ0lHRnNhV2R1TFdsMFpXMXpPaUJqWlc1MFpYSTdYRzRnSUNBZ0lDQWdJQ0FnSUNCa2FYTndiR0Y1T2lCbWJHVjRPMXh1WEc0Z0lDQWdJQ0FnSUNBZ0lDQW1JRHB1ZEdndFkyaHBiR1FvTWlrZ2UxeHVJQ0FnSUNBZ0lDQWdJQ0FnSUNCd2IzTnBkR2x2YmpvZ1lXSnpiMngxZEdVN1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUd4bFpuUTZJRFV3SlR0Y2JpQWdJQ0FnSUNBZ0lDQWdJQ0FnZEhKaGJuTm1iM0p0T2lCMGNtRnVjMnhoZEdWWUtDMDFNQ1VwTzF4dUlDQWdJQ0FnSUNBZ0lDQWdmVnh1SUNBZ0lDQWdJQ0FnSUgxY2JseHVJQ0FnSUNBZ0lDQWdJR2hsWVdSbGNpQTZaMnh2WW1Gc0tDNXBZMjl1S1NCN1hHNGdJQ0FnSUNBZ0lDQWdJQ0JzYVc1bExXaGxhV2RvZERvZ01UdGNiaUFnSUNBZ0lDQWdJQ0I5WEc1Y2JpQWdJQ0FnSUNBZ0lDQm9aV0ZrWlhJZ09tZHNiMkpoYkNndWRXa3VhR1ZoWkdWeUtTQjdYRzRnSUNBZ0lDQWdJQ0FnSUNCamIyeHZjam9nY21kaVlTZ3lOVFVzSURJMU5Td2dNalUxTENBdU5pazdYRzRnSUNBZ0lDQWdJQ0FnSUNCdFlYSm5hVzQ2SURBN1hHNGdJQ0FnSUNBZ0lDQWdmVnh1SUNBZ0lDQWdJQ0JnZlR3dmMzUjViR1UrWEc0Z0lDQWdJQ0E4TDJScGRqNWNiaUFnSUNBcFhHNGdJSDFjYm4xY2JseHVaWGh3YjNKMElHUmxabUYxYkhRZ1kyOXVibVZqZENoemRHRjBaU0E5UGlCemRHRjBaU2tvU0dWaFpHVnlLVnh1SWwxOSAqL1xuLypAIHNvdXJjZVVSTD1jb21wb25lbnRzL2hlYWRlci5qcyAqLyJdfQ== */'
      }));
    }
  }]);

  return Header;
}(_react.Component);

exports.default = (0, _reactRedux.connect)(function (state) {
  return state;
})(Header);

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/header.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/header.js"); } } })();

/***/ }),

/***/ 957:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__(36);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(39);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(38);

var _inherits3 = _interopRequireDefault(_inherits2);

var _style = __webpack_require__(578);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(10);

var _react2 = _interopRequireDefault(_react);

var _socket = __webpack_require__(1047);

var _socket2 = _interopRequireDefault(_socket);

var _reactRedux = __webpack_require__(594);

var _link = __webpack_require__(698);

var _link2 = _interopRequireDefault(_link);

var _isomorphicFetch = __webpack_require__(823);

var _isomorphicFetch2 = _interopRequireDefault(_isomorphicFetch);

var _header = __webpack_require__(956);

var _header2 = _interopRequireDefault(_header);

var _footer = __webpack_require__(955);

var _footer2 = _interopRequireDefault(_footer);

var _store = __webpack_require__(623);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Layout = function (_Component) {
  (0, _inherits3.default)(Layout, _Component);

  function Layout() {
    (0, _classCallCheck3.default)(this, Layout);

    return (0, _possibleConstructorReturn3.default)(this, (Layout.__proto__ || (0, _getPrototypeOf2.default)(Layout)).apply(this, arguments));
  }

  (0, _createClass3.default)(Layout, [{
    key: 'componentWillMount',
    value: function componentWillMount() {
      if (typeof window !== 'undefined' && !window.socket) {
        window.socket = (0, _socket2.default)(window.location.origin);
      }

      var _props = this.props,
          dispatch = _props.dispatch,
          users = _props.users;

      if (!users && typeof window !== 'undefined') {
        (0, _isomorphicFetch2.default)(window.location.origin + '/users').then(function (res) {
          return res.json();
        }).then(function (users) {
          return dispatch((0, _store.setUsers)(users));
        });
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return _react2.default.createElement('main', {
        'data-jsx': 1726856966
      }, _react2.default.createElement('div', { className: 'container', 'data-jsx': 1726856966
      }, this.props.children, !this.props.hideHeader && _react2.default.createElement(_header2.default, null), !this.props.hideFooter && _react2.default.createElement(_footer2.default, null)), _react2.default.createElement(_style2.default, {
        styleId: 1726856966,
        css: '.container[data-jsx="1726856966"] {background: #2e3445;height: 600px;position: relative;width: 800px;}\n/*@ sourceURL=components/layout.js */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jbGF1ZGlhZmVycmVpcmEvR2l0SHViL1Byb2pldG9fbGFiX2ludF9JSS9pY2FyL2NvbXBvbmVudHMvbGF5b3V0LmpzIiwiY29tcG9uZW50cy9sYXlvdXQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBb0NvQixtQ0FFWSxvQkFDTixjQUNLLG1CQUNOLGFBQ2QsQ0FBQTtBQ3hDWCxxQ0FBcUMiLCJmaWxlIjoidG8uY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGlvIGZyb20gJ3NvY2tldC5pby1jbGllbnQnXG5cbmltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xuaW1wb3J0IGZldGNoIGZyb20gJ2lzb21vcnBoaWMtZmV0Y2gnXG5cbmltcG9ydCBIZWFkZXIgZnJvbSAnLi4vY29tcG9uZW50cy9oZWFkZXInXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4uL2NvbXBvbmVudHMvZm9vdGVyJ1xuaW1wb3J0IHsgc2V0VXNlcnMgfSBmcm9tICcuLi9oZWxwZXJzL3N0b3JlJ1xuXG5jbGFzcyBMYXlvdXQgZXh0ZW5kcyBDb21wb25lbnQge1xuICBjb21wb25lbnRXaWxsTW91bnQoKSB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmICF3aW5kb3cuc29ja2V0KSB7XG4gICAgICB3aW5kb3cuc29ja2V0ID0gaW8od2luZG93LmxvY2F0aW9uLm9yaWdpbilcbiAgICB9XG5cbiAgICBjb25zdCB7IGRpc3BhdGNoLCB1c2VycyB9ID0gdGhpcy5wcm9wc1xuXG4gICAgaWYgKCF1c2VycyAmJiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgZmV0Y2goYCR7d2luZG93LmxvY2F0aW9uLm9yaWdpbn0vdXNlcnNgKVxuICAgICAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAgICAgLnRoZW4odXNlcnMgPT4gZGlzcGF0Y2goc2V0VXNlcnModXNlcnMpKSlcbiAgICB9XG4gIH1cblxuICByZW5kZXIgKCkge1xuICAgIHJldHVybiAoXG4gICAgICA8bWFpbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICB7dGhpcy5wcm9wcy5jaGlsZHJlbn1cblxuICAgICAgICAgIHsgIXRoaXMucHJvcHMuaGlkZUhlYWRlciAmJiA8SGVhZGVyIC8+IH1cbiAgICAgICAgICB7ICF0aGlzLnByb3BzLmhpZGVGb290ZXIgJiYgPEZvb3RlciAvPiB9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICAuY29udGFpbmVyIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICMyZTM0NDU7XG4gICAgICAgICAgICBoZWlnaHQ6IDYwMHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgd2lkdGg6IDgwMHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgPC9tYWluPlxuICAgIClcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KHN0YXRlID0+IHN0YXRlLCBkaXNwYXRjaCA9PiAoeyBkaXNwYXRjaCB9KSkoTGF5b3V0KVxuIiwiLmNvbnRhaW5lcltkYXRhLWpzeD1cIjE3MjY4NTY5NjZcIl0ge2JhY2tncm91bmQ6ICMyZTM0NDU7aGVpZ2h0OiA2MDBweDtwb3NpdGlvbjogcmVsYXRpdmU7d2lkdGg6IDgwMHB4O31cbi8qIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtiYXNlNjQsZXlKMlpYSnphVzl1SWpvekxDSnpiM1Z5WTJWeklqcGJJbU52YlhCdmJtVnVkSE12YkdGNWIzVjBMbXB6SWwwc0ltNWhiV1Z6SWpwYlhTd2liV0Z3Y0dsdVozTWlPaUpCUVc5RGIwSXNRVUZEUlN4dFEwRkRWU3h2UWtGRFRpeGpRVU5MTEcxQ1FVTk9MR0ZCUTJRaUxDSm1hV3hsSWpvaVkyOXRjRzl1Wlc1MGN5OXNZWGx2ZFhRdWFuTWlMQ0p6YjNWeVkyVlNiMjkwSWpvaUwxVnpaWEp6TDJOc1lYVmthV0ZtWlhKeVpXbHlZUzlIYVhSSWRXSXZVSEp2YW1WMGIxOXNZV0pmYVc1MFgwbEpMMmxqWVhJaUxDSnpiM1Z5WTJWelEyOXVkR1Z1ZENJNld5SnBiWEJ2Y25RZ2FXOGdabkp2YlNBbmMyOWphMlYwTG1sdkxXTnNhV1Z1ZENkY2JseHVhVzF3YjNKMElIc2dRMjl0Y0c5dVpXNTBJSDBnWm5KdmJTQW5jbVZoWTNRblhHNXBiWEJ2Y25RZ2V5QmpiMjV1WldOMElIMGdabkp2YlNBbmNtVmhZM1F0Y21Wa2RYZ25YRzVwYlhCdmNuUWdUR2x1YXlCbWNtOXRJQ2R1WlhoMEwyeHBibXNuWEc1cGJYQnZjblFnWm1WMFkyZ2dabkp2YlNBbmFYTnZiVzl5Y0docFl5MW1aWFJqYUNkY2JseHVhVzF3YjNKMElFaGxZV1JsY2lCbWNtOXRJQ2N1TGk5amIyMXdiMjVsYm5SekwyaGxZV1JsY2lkY2JtbHRjRzl5ZENCR2IyOTBaWElnWm5KdmJTQW5MaTR2WTI5dGNHOXVaVzUwY3k5bWIyOTBaWEluWEc1cGJYQnZjblFnZXlCelpYUlZjMlZ5Y3lCOUlHWnliMjBnSnk0dUwyaGxiSEJsY25NdmMzUnZjbVVuWEc1Y2JtTnNZWE56SUV4aGVXOTFkQ0JsZUhSbGJtUnpJRU52YlhCdmJtVnVkQ0I3WEc0Z0lHTnZiWEJ2Ym1WdWRGZHBiR3hOYjNWdWRDZ3BJSHRjYmlBZ0lDQnBaaUFvZEhsd1pXOW1JSGRwYm1SdmR5QWhQVDBnSjNWdVpHVm1hVzVsWkNjZ0ppWWdJWGRwYm1SdmR5NXpiMk5yWlhRcElIdGNiaUFnSUNBZ0lIZHBibVJ2ZHk1emIyTnJaWFFnUFNCcGJ5aDNhVzVrYjNjdWJHOWpZWFJwYjI0dWIzSnBaMmx1S1Z4dUlDQWdJSDFjYmx4dUlDQWdJR052Ym5OMElIc2daR2x6Y0dGMFkyZ3NJSFZ6WlhKeklIMGdQU0IwYUdsekxuQnliM0J6WEc1Y2JpQWdJQ0JwWmlBb0lYVnpaWEp6SUNZbUlIUjVjR1Z2WmlCM2FXNWtiM2NnSVQwOUlDZDFibVJsWm1sdVpXUW5LU0I3WEc0Z0lDQWdJQ0JtWlhSamFDaGdKSHQzYVc1a2IzY3ViRzlqWVhScGIyNHViM0pwWjJsdWZTOTFjMlZ5YzJBcFhHNGdJQ0FnSUNBZ0lDNTBhR1Z1S0hKbGN5QTlQaUJ5WlhNdWFuTnZiaWdwS1Z4dUlDQWdJQ0FnSUNBdWRHaGxiaWgxYzJWeWN5QTlQaUJrYVhOd1lYUmphQ2h6WlhSVmMyVnljeWgxYzJWeWN5a3BLVnh1SUNBZ0lIMWNiaUFnZlZ4dVhHNGdJSEpsYm1SbGNpQW9LU0I3WEc0Z0lDQWdjbVYwZFhKdUlDaGNiaUFnSUNBZ0lEeHRZV2x1UGx4dUlDQWdJQ0FnSUNBOFpHbDJJR05zWVhOelRtRnRaVDFjSW1OdmJuUmhhVzVsY2x3aVBseHVJQ0FnSUNBZ0lDQWdJSHQwYUdsekxuQnliM0J6TG1Ob2FXeGtjbVZ1ZlZ4dVhHNGdJQ0FnSUNBZ0lDQWdleUFoZEdocGN5NXdjbTl3Y3k1b2FXUmxTR1ZoWkdWeUlDWW1JRHhJWldGa1pYSWdMejRnZlZ4dUlDQWdJQ0FnSUNBZ0lIc2dJWFJvYVhNdWNISnZjSE11YUdsa1pVWnZiM1JsY2lBbUppQThSbTl2ZEdWeUlDOCtJSDFjYmlBZ0lDQWdJQ0FnUEM5a2FYWStYRzVjYmlBZ0lDQWdJQ0FnUEhOMGVXeGxJR3B6ZUQ1N1lGeHVJQ0FnSUNBZ0lDQWdJQzVqYjI1MFlXbHVaWElnZTF4dUlDQWdJQ0FnSUNBZ0lDQWdZbUZqYTJkeWIzVnVaRG9nSXpKbE16UTBOVHRjYmlBZ0lDQWdJQ0FnSUNBZ0lHaGxhV2RvZERvZ05qQXdjSGc3WEc0Z0lDQWdJQ0FnSUNBZ0lDQndiM05wZEdsdmJqb2djbVZzWVhScGRtVTdYRzRnSUNBZ0lDQWdJQ0FnSUNCM2FXUjBhRG9nT0RBd2NIZzdYRzRnSUNBZ0lDQWdJQ0FnZlZ4dUlDQWdJQ0FnSUNCZ2ZUd3ZjM1I1YkdVK1hHNGdJQ0FnSUNBOEwyMWhhVzQrWEc0Z0lDQWdLVnh1SUNCOVhHNTlYRzVjYm1WNGNHOXlkQ0JrWldaaGRXeDBJR052Ym01bFkzUW9jM1JoZEdVZ1BUNGdjM1JoZEdVc0lHUnBjM0JoZEdOb0lEMCtJQ2g3SUdScGMzQmhkR05vSUgwcEtTaE1ZWGx2ZFhRcFhHNGlYWDA9ICovXG4vKkAgc291cmNlVVJMPWNvbXBvbmVudHMvbGF5b3V0LmpzICovIl19 */'
      }));
    }
  }]);

  return Layout;
}(_react.Component);

exports.default = (0, _reactRedux.connect)(function (state) {
  return state;
}, function (dispatch) {
  return { dispatch: dispatch };
})(Layout);

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/layout.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/layout.js"); } } })();

/***/ }),

/***/ 958:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _defineProperty2 = __webpack_require__(651);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getPrototypeOf = __webpack_require__(36);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(39);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(38);

var _inherits3 = _interopRequireDefault(_inherits2);

var _style = __webpack_require__(578);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(10);

var _react2 = _interopRequireDefault(_react);

var _semanticUiReact = __webpack_require__(602);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TrainingOverlay = function (_Component) {
  (0, _inherits3.default)(TrainingOverlay, _Component);

  function TrainingOverlay() {
    (0, _classCallCheck3.default)(this, TrainingOverlay);

    return (0, _possibleConstructorReturn3.default)(this, (TrainingOverlay.__proto__ || (0, _getPrototypeOf2.default)(TrainingOverlay)).apply(this, arguments));
  }

  (0, _createClass3.default)(TrainingOverlay, [{
    key: 'render',
    value: function render() {
      var _React$createElement;

      var percentage = this.props.percentage;

      var dashOffset = Math.max(0, 1260 - percentage * 1260 / 100);

      return _react2.default.createElement('div', { className: 'container', 'data-jsx': 308679731
      }, _react2.default.createElement(_semanticUiReact.Icon, { name: 'checkmark', size: 'huge', className: percentage >= 100 ? 'visible' : '' }), _react2.default.createElement('svg', { width: '800', height: '600', 'data-jsx': 308679731
      }, _react2.default.createElement('defs', {
        'data-jsx': 308679731
      }, _react2.default.createElement('mask', { id: 'mask', 'data-jsx': 308679731
      }, _react2.default.createElement('rect', { y: '0', width: '800', height: '600', fill: 'white', 'data-jsx': 308679731
      }), _react2.default.createElement('circle', { cx: '400', cy: '300', r: '175', fill: 'black', 'data-jsx': 308679731
      }))), _react2.default.createElement('rect', (_React$createElement = { fill: 'black', width: '800', height: '600', mask: percentage >= 100 ? null : 'url(#mask)' }, (0, _defineProperty3.default)(_React$createElement, 'fill', 'rgb(46, 52, 69)'), (0, _defineProperty3.default)(_React$createElement, 'fillOpacity', '.9'), (0, _defineProperty3.default)(_React$createElement, 'data-jsx', 308679731), _React$createElement)), _react2.default.createElement('circle', {
        cx: '400',
        cy: '300',
        r: '175',
        fill: 'transparent',
        strokeDashoffset: dashOffset,
        transform: 'rotate(-90 400 300)',
        'data-jsx': 308679731
      })), _react2.default.createElement(_style2.default, {
        styleId: 308679731,
        css: '.container[data-jsx="308679731"] {left: 0;position: absolute;top: 0;}.container[data-jsx="308679731"] .icon {left: 50%;opacity: 0;position: absolute;top: 50%;-webkit-transform: translate(-50%, -50%) scale(0);transform: translate(-50%, -50%) scale(0);color: #1cb5ac;transition: all .15s cubic-bezier(.175, .885, .320, 1.275);}.container[data-jsx="308679731"] .icon.visible {opacity: 1;-webkit-transform: translate(-50%, -50%) scale(1);transform: translate(-50%, -50%) scale(1);}svg[data-jsx="308679731"] > circle[data-jsx="308679731"] {transition: all .1s ease-in-out;stroke: #1cb5ac;stroke-width: 5;stroke-dasharray: 1260;stroke-linecap: round;}\n/*@ sourceURL=components/training-overlay.js */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jbGF1ZGlhZmVycmVpcmEvR2l0SHViL1Byb2pldG9fbGFiX2ludF9JSS9pY2FyL2NvbXBvbmVudHMvdHJhaW5pbmctb3ZlcmxheS5qcyIsImNvbXBvbmVudHMvdHJhaW5pbmctb3ZlcmxheS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFpQ29CLGtDQUVBLFFBQ1csbUJBQ1osT0FDUixDQUUwQix3Q0FDZixVQUNDLFdBQ1EsbUJBQ1YsU0FDaUMsa0RBQUEsMENBQzNCLGVBQzRDLDJEQUM1RCxDQUVrQyxnREFDdEIsV0FDK0Isa0RBQUEsMENBQzNDLENBRWEsMERBQ29CLGdDQUNoQixnQkFDQSxnQkFDTyx1QkFDRCxzQkFDdkIsQ0FBQTtBQzNEWCwrQ0FBK0MiLCJmaWxlIjoidG8uY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFRyYWluaW5nT3ZlcmxheSBleHRlbmRzIENvbXBvbmVudCB7XG4gIHJlbmRlciAoKSB7XG4gICAgY29uc3QgeyBwZXJjZW50YWdlIH0gPSB0aGlzLnByb3BzXG5cbiAgICBjb25zdCBkYXNoT2Zmc2V0ID0gTWF0aC5tYXgoMCwgMTI2MCAtIChwZXJjZW50YWdlICogMTI2MCAvIDEwMCkpXG5cbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgPEljb24gbmFtZT1cImNoZWNrbWFya1wiIHNpemU9XCJodWdlXCIgY2xhc3NOYW1lPXtwZXJjZW50YWdlID49IDEwMCA/ICd2aXNpYmxlJyA6ICcnfSAvPlxuXG4gICAgICAgIDxzdmcgd2lkdGg9XCI4MDBcIiBoZWlnaHQ9XCI2MDBcIj5cbiAgICAgICAgICA8ZGVmcz5cbiAgICAgICAgICAgIDxtYXNrIGlkPVwibWFza1wiPlxuICAgICAgICAgICAgICA8cmVjdCB5PVwiMFwiIHdpZHRoPVwiODAwXCIgaGVpZ2h0PVwiNjAwXCIgZmlsbD1cIndoaXRlXCIgLz5cbiAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjQwMFwiIGN5PVwiMzAwXCIgcj1cIjE3NVwiIGZpbGw9XCJibGFja1wiIC8+XG4gICAgICAgICAgICA8L21hc2s+XG4gICAgICAgICAgPC9kZWZzPlxuXG4gICAgICAgICAgPHJlY3QgZmlsbD1cImJsYWNrXCIgd2lkdGg9XCI4MDBcIiBoZWlnaHQ9XCI2MDBcIiBtYXNrPXtwZXJjZW50YWdlID49IDEwMCA/IG51bGwgOiAndXJsKCNtYXNrKSd9IGZpbGw9XCJyZ2IoNDYsIDUyLCA2OSlcIiBmaWxsT3BhY2l0eT1cIi45XCIgLz5cblxuICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgIGN4PVwiNDAwXCJcbiAgICAgICAgICAgIGN5PVwiMzAwXCJcbiAgICAgICAgICAgIHI9XCIxNzVcIlxuICAgICAgICAgICAgZmlsbD1cInRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgIHN0cm9rZURhc2hvZmZzZXQ9e2Rhc2hPZmZzZXR9XG4gICAgICAgICAgICB0cmFuc2Zvcm09XCJyb3RhdGUoLTkwIDQwMCAzMDApXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L3N2Zz5cblxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLmNvbnRhaW5lciB7XG4gICAgICAgICAgICBsZWZ0OiAwO1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5jb250YWluZXIgOmdsb2JhbCguaWNvbikge1xuICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgb3BhY2l0eTogMDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgc2NhbGUoMCk7XG4gICAgICAgICAgICBjb2xvcjogIzFjYjVhYztcbiAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAuMTVzIGN1YmljLWJlemllciguMTc1LCAuODg1LCAuMzIwLCAxLjI3NSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLmNvbnRhaW5lciA6Z2xvYmFsKC5pY29uLnZpc2libGUpIHtcbiAgICAgICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKSBzY2FsZSgxKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBzdmcgPiBjaXJjbGUge1xuICAgICAgICAgICAgdHJhbnNpdGlvbjogYWxsIC4xcyBlYXNlLWluLW91dDtcbiAgICAgICAgICAgIHN0cm9rZTogIzFjYjVhYztcbiAgICAgICAgICAgIHN0cm9rZS13aWR0aDogNTtcbiAgICAgICAgICAgIHN0cm9rZS1kYXNoYXJyYXk6IDEyNjA7XG4gICAgICAgICAgICBzdHJva2UtbGluZWNhcDogcm91bmQ7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbn1cbiIsIi5jb250YWluZXJbZGF0YS1qc3g9XCIzMDg2Nzk3MzFcIl0ge2xlZnQ6IDA7cG9zaXRpb246IGFic29sdXRlO3RvcDogMDt9LmNvbnRhaW5lcltkYXRhLWpzeD1cIjMwODY3OTczMVwiXSAuaWNvbiB7bGVmdDogNTAlO29wYWNpdHk6IDA7cG9zaXRpb246IGFic29sdXRlO3RvcDogNTAlOy13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgc2NhbGUoMCk7LW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKSBzY2FsZSgwKTstbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgc2NhbGUoMCk7dHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgc2NhbGUoMCk7Y29sb3I6ICMxY2I1YWM7LXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjE1cyBjdWJpYy1iZXppZXIoLjE3NSwgLjg4NSwgLjMyMCwgMS4yNzUpOy1tb3otdHJhbnNpdGlvbjogYWxsIC4xNXMgY3ViaWMtYmV6aWVyKC4xNzUsIC44ODUsIC4zMjAsIDEuMjc1KTstbXMtdHJhbnNpdGlvbjogYWxsIC4xNXMgY3ViaWMtYmV6aWVyKC4xNzUsIC44ODUsIC4zMjAsIDEuMjc1KTt0cmFuc2l0aW9uOiBhbGwgLjE1cyBjdWJpYy1iZXppZXIoLjE3NSwgLjg4NSwgLjMyMCwgMS4yNzUpO30uY29udGFpbmVyW2RhdGEtanN4PVwiMzA4Njc5NzMxXCJdIC5pY29uLnZpc2libGUge29wYWNpdHk6IDE7LXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKSBzY2FsZSgxKTstbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpIHNjYWxlKDEpOy1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKSBzY2FsZSgxKTt0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKSBzY2FsZSgxKTt9c3ZnW2RhdGEtanN4PVwiMzA4Njc5NzMxXCJdID4gY2lyY2xlW2RhdGEtanN4PVwiMzA4Njc5NzMxXCJdIHstd2Via2l0LXRyYW5zaXRpb246IGFsbCAuMXMgZWFzZS1pbi1vdXQ7LW1vei10cmFuc2l0aW9uOiBhbGwgLjFzIGVhc2UtaW4tb3V0Oy1tcy10cmFuc2l0aW9uOiBhbGwgLjFzIGVhc2UtaW4tb3V0O3RyYW5zaXRpb246IGFsbCAuMXMgZWFzZS1pbi1vdXQ7c3Ryb2tlOiAjMWNiNWFjO3N0cm9rZS13aWR0aDogNTtzdHJva2UtZGFzaGFycmF5OiAxMjYwO3N0cm9rZS1saW5lY2FwOiByb3VuZDt9XG4vKiMgc291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247YmFzZTY0LGV5SjJaWEp6YVc5dUlqb3pMQ0p6YjNWeVkyVnpJanBiSW1OdmJYQnZibVZ1ZEhNdmRISmhhVzVwYm1jdGIzWmxjbXhoZVM1cWN5SmRMQ0p1WVcxbGN5STZXMTBzSW0xaGNIQnBibWR6SWpvaVFVRnBRMjlDTEVGQlEwVXNhME5CUTBZc1VVRkRWeXh0UWtGRFdpeFBRVU5TTEVOQlJUQkNMSGREUVVObUxGVkJRME1zVjBGRFVTeHRRa0ZEVml4VFFVTnBReXg1VEVGRE0wSXNaVUZETkVNc05sQkJRelZFTEVOQlJXdERMR2RFUVVOMFFpeFhRVU1yUWl4NVRFRkRNME1zUTBGRllTd3dSRUZEYjBJc2FVcEJRMmhDTEdkQ1FVTkJMR2RDUVVOUExIVkNRVU5FTEhOQ1FVTjJRaUlzSW1acGJHVWlPaUpqYjIxd2IyNWxiblJ6TDNSeVlXbHVhVzVuTFc5MlpYSnNZWGt1YW5NaUxDSnpiM1Z5WTJWU2IyOTBJam9pTDFWelpYSnpMMk5zWVhWa2FXRm1aWEp5WldseVlTOUhhWFJJZFdJdlVISnZhbVYwYjE5c1lXSmZhVzUwWDBsSkwybGpZWElpTENKemIzVnlZMlZ6UTI5dWRHVnVkQ0k2V3lKcGJYQnZjblFnZXlCRGIyMXdiMjVsYm5RZ2ZTQm1jbTl0SUNkeVpXRmpkQ2RjYm1sdGNHOXlkQ0I3SUVsamIyNGdmU0JtY205dElDZHpaVzFoYm5ScFl5MTFhUzF5WldGamRDZGNibHh1Wlhod2IzSjBJR1JsWm1GMWJIUWdZMnhoYzNNZ1ZISmhhVzVwYm1kUGRtVnliR0Y1SUdWNGRHVnVaSE1nUTI5dGNHOXVaVzUwSUh0Y2JpQWdjbVZ1WkdWeUlDZ3BJSHRjYmlBZ0lDQmpiMjV6ZENCN0lIQmxjbU5sYm5SaFoyVWdmU0E5SUhSb2FYTXVjSEp2Y0hOY2JseHVJQ0FnSUdOdmJuTjBJR1JoYzJoUFptWnpaWFFnUFNCTllYUm9MbTFoZUNnd0xDQXhNall3SUMwZ0tIQmxjbU5sYm5SaFoyVWdLaUF4TWpZd0lDOGdNVEF3S1NsY2JseHVJQ0FnSUhKbGRIVnliaUFvWEc0Z0lDQWdJQ0E4WkdsMklHTnNZWE56VG1GdFpUMWNJbU52Ym5SaGFXNWxjbHdpUGx4dUlDQWdJQ0FnSUNBOFNXTnZiaUJ1WVcxbFBWd2lZMmhsWTJ0dFlYSnJYQ0lnYzJsNlpUMWNJbWgxWjJWY0lpQmpiR0Z6YzA1aGJXVTllM0JsY21ObGJuUmhaMlVnUGowZ01UQXdJRDhnSjNacGMybGliR1VuSURvZ0p5ZDlJQzgrWEc1Y2JpQWdJQ0FnSUNBZ1BITjJaeUIzYVdSMGFEMWNJamd3TUZ3aUlHaGxhV2RvZEQxY0lqWXdNRndpUGx4dUlDQWdJQ0FnSUNBZ0lEeGtaV1p6UGx4dUlDQWdJQ0FnSUNBZ0lDQWdQRzFoYzJzZ2FXUTlYQ0p0WVhOclhDSStYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lEeHlaV04wSUhrOVhDSXdYQ0lnZDJsa2RHZzlYQ0k0TURCY0lpQm9aV2xuYUhROVhDSTJNREJjSWlCbWFXeHNQVndpZDJocGRHVmNJaUF2UGx4dUlDQWdJQ0FnSUNBZ0lDQWdJQ0E4WTJseVkyeGxJR040UFZ3aU5EQXdYQ0lnWTNrOVhDSXpNREJjSWlCeVBWd2lNVGMxWENJZ1ptbHNiRDFjSW1Kc1lXTnJYQ0lnTHo1Y2JpQWdJQ0FnSUNBZ0lDQWdJRHd2YldGemF6NWNiaUFnSUNBZ0lDQWdJQ0E4TDJSbFpuTStYRzVjYmlBZ0lDQWdJQ0FnSUNBOGNtVmpkQ0JtYVd4c1BWd2lZbXhoWTJ0Y0lpQjNhV1IwYUQxY0lqZ3dNRndpSUdobGFXZG9kRDFjSWpZd01Gd2lJRzFoYzJzOWUzQmxjbU5sYm5SaFoyVWdQajBnTVRBd0lEOGdiblZzYkNBNklDZDFjbXdvSTIxaGMyc3BKMzBnWm1sc2JEMWNJbkpuWWlnME5pd2dOVElzSURZNUtWd2lJR1pwYkd4UGNHRmphWFI1UFZ3aUxqbGNJaUF2UGx4dVhHNGdJQ0FnSUNBZ0lDQWdQR05wY21Oc1pWeHVJQ0FnSUNBZ0lDQWdJQ0FnWTNnOVhDSTBNREJjSWx4dUlDQWdJQ0FnSUNBZ0lDQWdZM2s5WENJek1EQmNJbHh1SUNBZ0lDQWdJQ0FnSUNBZ2NqMWNJakUzTlZ3aVhHNGdJQ0FnSUNBZ0lDQWdJQ0JtYVd4c1BWd2lkSEpoYm5Od1lYSmxiblJjSWx4dUlDQWdJQ0FnSUNBZ0lDQWdjM1J5YjJ0bFJHRnphRzltWm5ObGREMTdaR0Z6YUU5bVpuTmxkSDFjYmlBZ0lDQWdJQ0FnSUNBZ0lIUnlZVzV6Wm05eWJUMWNJbkp2ZEdGMFpTZ3RPVEFnTkRBd0lETXdNQ2xjSWx4dUlDQWdJQ0FnSUNBZ0lDOCtYRzRnSUNBZ0lDQWdJRHd2YzNablBseHVYRzRnSUNBZ0lDQWdJRHh6ZEhsc1pTQnFjM2crZTJCY2JpQWdJQ0FnSUNBZ0lDQXVZMjl1ZEdGcGJtVnlJSHRjYmlBZ0lDQWdJQ0FnSUNBZ0lHeGxablE2SURBN1hHNGdJQ0FnSUNBZ0lDQWdJQ0J3YjNOcGRHbHZiam9nWVdKemIyeDFkR1U3WEc0Z0lDQWdJQ0FnSUNBZ0lDQjBiM0E2SURBN1hHNGdJQ0FnSUNBZ0lDQWdmVnh1WEc0Z0lDQWdJQ0FnSUNBZ0xtTnZiblJoYVc1bGNpQTZaMnh2WW1Gc0tDNXBZMjl1S1NCN1hHNGdJQ0FnSUNBZ0lDQWdJQ0JzWldaME9pQTFNQ1U3WEc0Z0lDQWdJQ0FnSUNBZ0lDQnZjR0ZqYVhSNU9pQXdPMXh1SUNBZ0lDQWdJQ0FnSUNBZ2NHOXphWFJwYjI0NklHRmljMjlzZFhSbE8xeHVJQ0FnSUNBZ0lDQWdJQ0FnZEc5d09pQTFNQ1U3WEc0Z0lDQWdJQ0FnSUNBZ0lDQjBjbUZ1YzJadmNtMDZJSFJ5WVc1emJHRjBaU2d0TlRBbExDQXROVEFsS1NCelkyRnNaU2d3S1R0Y2JpQWdJQ0FnSUNBZ0lDQWdJR052Ykc5eU9pQWpNV05pTldGak8xeHVJQ0FnSUNBZ0lDQWdJQ0FnZEhKaGJuTnBkR2x2YmpvZ1lXeHNJQzR4TlhNZ1kzVmlhV010WW1WNmFXVnlLQzR4TnpVc0lDNDRPRFVzSUM0ek1qQXNJREV1TWpjMUtUdGNiaUFnSUNBZ0lDQWdJQ0I5WEc1Y2JpQWdJQ0FnSUNBZ0lDQXVZMjl1ZEdGcGJtVnlJRHBuYkc5aVlXd29MbWxqYjI0dWRtbHphV0pzWlNrZ2UxeHVJQ0FnSUNBZ0lDQWdJQ0FnYjNCaFkybDBlVG9nTVR0Y2JpQWdJQ0FnSUNBZ0lDQWdJSFJ5WVc1elptOXliVG9nZEhKaGJuTnNZWFJsS0MwMU1DVXNJQzAxTUNVcElITmpZV3hsS0RFcE8xeHVJQ0FnSUNBZ0lDQWdJSDFjYmx4dUlDQWdJQ0FnSUNBZ0lITjJaeUErSUdOcGNtTnNaU0I3WEc0Z0lDQWdJQ0FnSUNBZ0lDQjBjbUZ1YzJsMGFXOXVPaUJoYkd3Z0xqRnpJR1ZoYzJVdGFXNHRiM1YwTzF4dUlDQWdJQ0FnSUNBZ0lDQWdjM1J5YjJ0bE9pQWpNV05pTldGak8xeHVJQ0FnSUNBZ0lDQWdJQ0FnYzNSeWIydGxMWGRwWkhSb09pQTFPMXh1SUNBZ0lDQWdJQ0FnSUNBZ2MzUnliMnRsTFdSaGMyaGhjbkpoZVRvZ01USTJNRHRjYmlBZ0lDQWdJQ0FnSUNBZ0lITjBjbTlyWlMxc2FXNWxZMkZ3T2lCeWIzVnVaRHRjYmlBZ0lDQWdJQ0FnSUNCOVhHNGdJQ0FnSUNBZ0lHQjlQQzl6ZEhsc1pUNWNiaUFnSUNBZ0lEd3ZaR2wyUGx4dUlDQWdJQ2xjYmlBZ2ZWeHVmVnh1SWwxOSAqL1xuLypAIHNvdXJjZVVSTD1jb21wb25lbnRzL3RyYWluaW5nLW92ZXJsYXkuanMgKi8iXX0= */'
      }));
    }
  }]);

  return TrainingOverlay;
}(_react.Component);

exports.default = TrainingOverlay;

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/training-overlay.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/claudiaferreira/GitHub/Projeto_lab_int_II/icar/components/training-overlay.js"); } } })();

/***/ })

},[1062]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd3MgKGlnbm9yZWQpPzQ5YmFjMDYiLCJ3ZWJwYWNrOi8vLy4vaGVscGVycy9zdG9yZS5qcz80OWJhYzA2Iiwid2VicGFjazovLy8uL3BhZ2VzPzQ5YmFjMDYiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9mb290ZXIuanM/NDliYWMwNiIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL2hlYWRlci5qcz80OWJhYzA2Iiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvbGF5b3V0LmpzPzQ5YmFjMDYiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy90cmFpbmluZy1vdmVybGF5LmpzPzQ5YmFjMDYiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsZTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBc0I7O0FBQ2Y7Ozs7QUFDQTs7Ozs7O0FBRVAsSUFBTTtTQUVKO2VBQ0E7O1lBRUU7V0FJSjtBQUxJO0FBSEY7O0FBUUssSUFBTTthQUVYO29CQUNBO2VBRUE7O3lCQUF1QjtBQUp2Qjs7QUFRRjtBQUFPLElBQU0sNEJBQVUsbUJBQWtDO01BQUE7TUFBQSxtQkFDdkQ7O1VBQVEsT0FDTjtTQUFLLFlBQ0g7YUFBTyxzQkFBYyxJQUFJLE9BQU8sRUFBRSxPQUFPLE9BQzNDO1NBQUssWUFDSDthQUFPLHNCQUFjLElBQUksT0FBTyxFQUFFLGFBQWEsT0FDakQ7U0FBSyxZQUNIO2FBQU8sc0JBQWMsSUFBSSxPQUFPLEVBQUUsT0FBTyxvQkFBSyxNQUFNLE9BQU8sQ0FBQyxPQUU5RDs7U0FBSyxZQUNIO2FBQU8sc0JBQWMsSUFBSSxPQUFPLEVBQUUsdUNBQWlCLE1BQU0sOENBQWEsT0FBTyxRQUFRLE1BQU8sT0FBTyxRQUVyRzs7QUFBUzthQUVaOztBQWRNOztBQWlCUDtBQUFPLElBQU0sOEJBQVc7U0FBVztXQUFZLFNBQVMsRUFBRSxNQUFNLFlBQVksV0FBVyxTQUEvQjtBQUFoQztBQUN4QjtBQUFPLElBQU0sMENBQWlCO1NBQVc7V0FBWSxTQUFTLEVBQUUsTUFBTSxZQUFZLGtCQUFrQixTQUF0QztBQUFoQztBQUM5QjtBQUFPLElBQU0sa0NBQWE7U0FBTTtXQUFZLFNBQVMsRUFBRSxNQUFNLFlBQVksYUFBYSxJQUFqQztBQUEzQjtBQUUxQjs7QUFBTyxJQUFNLG9EQUFzQiw2QkFBQyxNQUFNLFFBQVA7U0FBa0I7O1lBQzdDLFlBQ047ZUFBUyxFQUFFLE1BQUYsTUFBUSxRQUFSO0FBRFQsS0FEK0Q7QUFBOUI7QUFLbkM7O0FBQU8sSUFBTSxnQ0FBWSxxQkFBaUM7TUFBQSxtRkFDeEQ7O1NBQU8sd0JBQVksU0FBUyxjQUM3QjtBQUZNLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaERBOzs7O0FBRUU7Ozs7QUFDd0I7O0FBRTFCOzs7O0FBQ0E7Ozs7QUFDYTs7OztBQUVwQixJQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUssUUFBUTtBQUN6QyxJQUFNLDZCQUE2QjtBQUNuQyxJQUFNLHNCQUFzQjs7QUFFNUIsSUFBSSwwQkFBSjtBQUNBLElBQU0sYUFBYTs2QkFBcUIsT0FBTyxJQUFJO1dBQU0sU0FBUztBQUF0QyxLQUEyQyxPQUFPLFNBQVM7QUFBdkY7O0lBRU07b0NBQ0o7O29CQUFZLE9BQU87d0NBQUE7OzBJQUNYOztVQStEUixtQkFBbUIsWUFDakI7WUFBSyxTQUFTLEVBQUUsZUFDakI7QUFsRWtCOztVQXlGbkIscUJBQXFCLGdCQUFRO3dCQUNjLE1BQUs7VUFBdEM7VUFBVTtVQUFPO1VBQ2pCLGFBQWUsTUFBSyxNQUFwQjs7VUFDQSxLQUE4QixLQUE5QjtVQUFJLFdBQTBCLEtBQTFCO1VBQWEsa0RBQWEsYUFFdEM7O1lBRUE7O1VBQUksWUFDRjtBQUNEO0FBR0Q7O1VBQUksSUFDRjtZQUFJLGVBQWUsWUFBWSxPQUFPLElBQ3BDO0FBQ0Q7QUFFRDs7Y0FBSyxTQUFTLEVBQUUsbUJBRWhCOztpQkFBUyxvREFBaUIsSUFBakIsTUFFVDs7ZUFBTyxPQUFPLEtBQUssbUJBQW1CLFNBQ3ZDO0FBVkQsYUFVTyxJQUFJLFVBQ1Q7Y0FBSyxnQkFFTDs7Y0FBSyxTQUFTLEVBQUUsbUJBQ2pCO0FBQ0Y7QUFwSGtCOztVQXNIbkIsaUJBQWlCLFlBQ2Y7WUFBSyxrQ0FBa0MsWUFDckM7Y0FBSyxhQUFhLFVBQVUsTUFBSyxPQUFPLEdBQUcsR0FBRyxXQUFXLE9BQU8sV0FFaEU7O2VBQU8sT0FBTyxLQUFLLGlCQUFpQixNQUFLLFlBQVksVUFBVSxjQUNoRTtBQUowQixTQUs1QjtBQTVIa0I7O1VBOEhuQixlQUFlLFlBQU07VUFDWCxRQUFVLE1BQUssTUFFdkI7O29CQUFjLE1BQ2Q7b0JBQWMsTUFFZDs7WUFBSzsyQkFFSDs0QkFDQTtvQkFHRjtBQUxFOztVQUtJLFlBQVksV0FBVyxTQUU3Qjs7YUFBTyxPQUFPLG1CQUVkOztZQUFLLCtCQUErQixZQUNsQztjQUFLLFNBQVMsRUFBRSxvQkFBb0IsTUFBSyxNQUFNLHFCQUFxQixLQUFLLFlBQ3ZFO2NBQUksTUFBSyxNQUFNLHNCQUFzQixxQkFDbkM7MEJBQWMsTUFFZDs7bUJBQU8sT0FBTyxrQkFDZjtBQUpELGlCQUtFO2tCQUFLLGFBQWEsVUFBVSxNQUFLLE9BQU8sR0FBRyxHQUFHLFdBQVcsT0FBTyxXQUVoRTs7bUJBQU8sT0FBTyxzQkFFWixNQUFLLFlBQVksVUFBVSxjQUFjLElBQ3pDLFdBQ0EsTUFBSyxNQUVSO0FBQ0Y7QUFDRjtBQWpCdUIsU0FrQnpCO0FBaEtrQjs7VUFrS25CLGlCQUFpQixZQUFNO1VBQ2IsUUFBVSxNQUFLLE1BRXZCOztvQkFBYyxNQUVkOztVQUFNLFNBQVMsV0FBVyxTQUUxQjs7YUFBTyxPQUFPLG1CQUVkOztZQUFLLFNBQVMsRUFBRSxZQUFZLE9BQU8sb0JBQ25DO1lBQ0Q7QUE3S2tCOztVQStLbkIscUJBQXFCLGNBQ25CO3NCQUFPLHNCQUFvQixLQUM1QjtBQTlLQzs7VUFBSzt5QkFFSDtrQkFDQTtrQkFDQTtxQkFBZSxNQUFNLElBQUksTUFBTTtBQUgvQjtXQUtIOzs7Ozt3Q0FFb0I7bUJBQ25COztVQUFNLGFBQWEsS0FBSyxNQUFNLElBQUksTUFBTSxhQUFhO1VBQzdDLGdCQUFrQixLQUFLLE1BRS9COztVQUFJLGVBQ0Y7NkJBQXFCLFdBQVcsS0FBSyxrQkFDdEM7QUFFRDs7V0FBSyxlQUFlLEtBQUssWUFBWSxXQUVyQzs7V0FBSyxpQkFBaUIsS0FBSyxjQUFjLFdBQ3pDO1dBQUssZUFBZSxjQUNwQjtXQUFLLGVBQWUsWUFDcEI7V0FBSyxlQUFlLFVBQ3BCO1dBQUssZUFBZSxZQUFZLENBQUMsR0FFakM7O2FBQU8sT0FBTyxHQUFHLGdCQUFnQixLQUNqQzthQUFPLE9BQU8sR0FBRyxnQkFBZ0IsS0FDakM7YUFBTyxPQUFPLEdBQUcsa0JBQWtCO2VBQU0sZ0JBQU8sS0FBSztBQUVyRDs7VUFBSSxLQUFLLFNBQVMsVUFBVSxnQkFBZ0IsVUFBVSxhQUFhLGNBQ2pFO2tCQUFVLGFBQWEsYUFBYSxFQUFFLE9BQU8sUUFBUSxLQUFLLGtCQUN4RDtpQkFBSyxlQUNMO2lCQUFLLE1BQU0sTUFBTSxPQUFPLElBQUksZ0JBQWdCLE9BRTVDOztpQkFBSyxNQUFNLE9BQU8sS0FBSyxZQUNyQjtnQkFBSSxDQUFDLFlBQ0g7cUJBQ0Q7QUFGRCxtQkFHRTtxQkFDRDtBQUNGO0FBQ0Y7QUFDRjtBQUNGOzs7OzhDQUV5QixXQUN4QjtVQUFJLENBQUMsS0FBSyxNQUFNLElBQUksTUFBTSxZQUFZLFVBQVUsSUFBSSxNQUFNLFVBQ3hEO2FBQ0Q7QUFDRjs7OzsyQ0FHQztvQkFBYyxLQUNkO29CQUFjLEtBQ2Q7bUJBRUE7O1VBQUksS0FBSyxPQUNQO2FBQUssTUFDTDthQUFLLGFBQWEsWUFBWSxHQUMvQjtBQUNGOzs7OzBDQU13QztVQUFBO1VBQUE7VUFBQTtVQUFBLGNBQ3ZDOztXQUFLLGVBQ0w7V0FBSyxlQUFlLElBQUksSUFBSSxRQUFRLEdBQUcsSUFBSSxRQUFRLEdBQUcsUUFBUSxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQ2hGO1dBQUssZUFFTDs7V0FBSyxtQkFBbUIsRUFBRSxHQUFGLEdBQUssR0FBTCxHQUFRLE9BQVIsT0FBZSxRQUN4Qzs7Ozt1Q0FHQztVQUFJLEtBQUssa0JBQWtCO2dDQUNELEtBQUs7WUFBckI7WUFBRztZQUFHLDBCQUVkOzthQUFLLGVBQWUsVUFDbEIsSUFBSSxRQUFRLEdBQ1osSUFBSSxRQUFRLEdBQ1osUUFBUSxHQUNSLFFBRUg7QUFDRjs7Ozs2QkE0RlM7bUJBQUE7O21CQUNxRSxLQUFLO1VBQTFFO1VBQWU7VUFBbUI7VUFBWSw0QkFFdEQ7OzZCQUNHLGtDQUFPLFlBQWEsWUFBYSxZQUMvQiw4Q0FDSTttQkFDVSxLQUNYOzZCQUFtQixnQkFDbkI7aUJBQVMsS0FBSztBQUZkLE9BREEsSUFRSjtvQkFDRTtBQURGLHlCQUNHLHlDQUFPLFFBQVIsTUFBZSxVQUFmLE1BQXdCLE1BRXhCO2FBQ087aUJBQU0sT0FBSyxRQUFRO0FBQ3hCO2VBQU8sV0FDUDtnQkFBUSxXQUNSO2tCQUpGO29CQU9BO0FBTkU7YUFPSztpQkFBTSxPQUFLLGNBQWM7QUFDOUI7bUJBQ0E7ZUFBTyxXQUNQO2dCQUFRLFdBQVc7b0JBR3JCO0FBTkU7YUFPSztpQkFBTSxPQUFLLGdCQUFnQjtBQUNoQzt1Q0FBNEIsYUFBYSxXQUN6QztlQUFPLFdBQ1A7Z0JBQVEsV0FBVztvQkFHbkI7QUFOQSx1Q0FRRSx1QkFBSyxXQUFVLGtDQUNiO09BREYsa0JBQ0csMkNBQWdCLFlBQVksS0FBSyxNQUFNLHFCQUFxQixzQkFFNUQsOEJBQXFCLHNDQUVsQjtvQkFDRTtBQURGLHlCQUNHLHlDQUFPLE9BQVIsTUFBYyxVQUFkLE1BQXVCLFNBQVMsS0FBSyxrQkFFckMsNkJBQUMseUNBQU8sSUFBRyxNQUFLLFdBQVUsWUFDMUIsNERBQUMseUNBQU8sSUFBRyxNQUFLLFdBQVUsWUFBMUIsNkNBR0YsUUFPUiwwQ0FFRSx1QkFBSyxXQUFVLHVCQUNiO09BREYsa0JBQ0c7aUJBRUM7Y0FDQTt1QkFDQTtlQUNBO2NBQ0E7aUJBQVMsS0FBSztBQUxkLFlBU0o7aUJBcEVSO2FBbUpIO0FBbkpHOzs7OztBQXNKTjs7b0VBQW9DO1NBQVM7QUFBOUIsQ0FBVSxFQUEyQixVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdWM0M7Ozs7QUFDQTs7QUFDQTs7QUFFVzs7OztJQUVkOzs7Ozs7Ozs7Ozt3Q0FDZ0I7VUFDVixXQUFhLEtBQUssTUFFMUI7O2FBQU8sT0FBTyxHQUFHLHFCQUFxQixVQUFDLE1BQ3JDO2lCQUFTLGdDQUFvQixLQUFLLE1BQU0sS0FDekM7QUFDRjs7Ozs2QkFFUTs4QkFDcUIsS0FBSyxNQUF6QjtVQUFBLCtDQUFhLEtBRXJCOzs2QkFDRTtvQkFDRTtBQURGLHlCQUNFO29CQUNFO0FBREYseUJBQ0U7b0JBQU07QUFBTix5QkFBTyx1Q0FBSyxNQUFLLFVBQVMsTUFBSyxTQUFRLE9BQVEsV0FBVyxTQUFTLFVBQVUsVUFDN0U7b0JBQU07QUFBTix5QkFBTyx1Q0FBSyxNQUFLLFVBQVMsTUFBSyxTQUFRLE9BQVEsV0FBVyxRQUFRLFVBQVUsVUFBNUU7aUJBSEo7YUEyQkg7QUEzQkc7Ozs7O0FBOEJOOztvRUFBb0M7U0FBUztBQUE5QixDQUFVLEVBQTJCO1NBQWEsRUFBRSxVQUFGO0FBQWxELEdBQWlFLFE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRHZFOzs7O0FBQ0E7O0FBQ2dCOztBQUNsQjs7Ozs7O0FBRVAsSUFBTSxVQUFVLG1CQUNkO01BQU07VUFFSjtZQUdGO0FBSkU7O1NBSUssSUFBSSxLQUFLLGVBQWUsU0FBUyxTQUFTLE9BQU8sSUFDekQ7QUFQRDs7SUFTTTs7Ozs7Ozs7Ozs7Ozs7NE1BQ0o7WUFDUTtBQUFOOzs7Ozt3Q0FHa0I7bUJBQ2xCOztXQUFLLHVCQUF1QjtlQUFNLE9BQUssU0FBUyxFQUFFLE1BQU07QUFBeEMsU0FDakI7Ozs7MkNBR0M7b0JBQWMsS0FDZjs7Ozs2QkFFUTttQkFDMEIsS0FBSztVQUE5QjtVQUFhO1VBQ2IsT0FBUyxLQUFLLE1BRXRCOztVQUFJLENBQUMsYUFDRDtlQUNIO0FBRUQ7OzZCQUNFO29CQUNFO0FBREYseUJBQ0UsMEJBQVEsV0FBVSx5QkFDaEI7eUJBQUE7b0JBQ0U7QUFERix5QkFDRyx1Q0FBSyxNQUNOLDZCQUFDLHVDQUFLLE1BQ04sNENBQUMsdUNBQUssTUFDTiw0QkFBQyx5Q0FBRSxJQUFTLFFBR2Q7b0JBQ0k7QUFESix1QkFFTSxnQkFBQyx5Q0FBRSxJQUFTLG9CQUFZLFFBSzlCO29CQUNFO0FBREYseUJBQ0csZ0NBQUssTUFDSiwwREFBRyxXQUFVLDZEQUFiO1NBQ1MsMkJBQUMsdUNBQUssTUFBSztpQkFuQjVCO2FBd0VIO0FBeEVHOzs7OztBQTJFTjs7MkNBQXVCO1NBQVM7QUFBakIsR0FBd0IsUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3RzlCOzs7O0FBQ0E7O0FBQ0Y7Ozs7QUFDQTs7OztBQUVBOzs7O0FBQ0E7Ozs7QUFDRTs7OztJQUVIOzs7Ozs7Ozs7Ozt5Q0FFRjtVQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsT0FBTyxRQUMzQztlQUFPLFNBQVMsc0JBQUcsT0FBTyxTQUMzQjtBQUhrQjs7bUJBS1MsS0FBSztVQUF6QjtVQUFVLGVBRWxCOztVQUFJLENBQUMsU0FBUyxPQUFPLFdBQVcsYUFDOUI7dUNBQVMsT0FBTyxTQUFTLG1CQUN0QixLQUFLO2lCQUFPLElBQUk7QUFEbkIsV0FFRyxLQUFLO2lCQUFTLFNBQVMscUJBQVM7QUFDcEM7QUFDRjs7Ozs2QkFHQzs2QkFDRTtvQkFDRTtBQURGLHlCQUNFLHVCQUFLLFdBQVUseUJBQ1o7Y0FBSyxNQUVKLFdBQUMsS0FBSyxNQUFNLGNBQWMsZ0JBQUMsZ0NBQzNCLFFBQUMsS0FBSyxNQUFNLGNBQWMsZ0JBQUMsZ0NBSi9CO2lCQURGO2FBa0JIO0FBbEJHOzs7OztBQXFCTjs7MkNBQXVCO1NBQVM7QUFBakIsR0FBd0I7U0FBYSxFQUFFLFVBQUY7QUFBckMsR0FBb0QsUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakQxRDs7OztBQUNBOzs7O0lBRVk7Ozs7Ozs7Ozs7OzZCQUNUO1VBQUE7O1VBQ0EsYUFBZSxLQUFLLE1BRTVCOztVQUFNLGFBQWEsS0FBSyxJQUFJLEdBQUcsT0FBUSxhQUFhLE9BRXBEOzs2QkFDRSx1QkFBSyxXQUFVLHlCQUNiO09BREYsa0JBQ0csdUNBQUssTUFBSyxhQUFZLE1BQUssUUFBTyxXQUFXLGNBQWMsTUFBTSxZQUVsRSw4Q0FBSyxPQUFNLE9BQU0sUUFBTyxtQkFDdEI7eUJBQUE7b0JBQ0U7QUFERix5QkFDRSx3QkFBTSxJQUFHLG9CQUNQO2lEQUFNLEdBQUUsS0FBSSxPQUFNLE9BQU0sUUFBTyxPQUFNLE1BQUsscUJBQzFDO29EQUFRLElBQUcsT0FBTSxJQUFHLE9BQU0sR0FBRSxPQUFNLE1BQUsscUJBSTNDOzRFQUFNLE1BQUssU0FBUSxPQUFNLE9BQU0sUUFBTyxPQUFNLE1BQU0sY0FBYyxNQUFNLE9BQU8sNEVBQW1CLHVGQUE4QixtRkFFOUg7WUFFRTtZQUNBO1dBQ0E7Y0FDQTswQkFDQTttQkFBVTtvQkFOWjtBQUNFO2lCQWROO2FBdURIO0FBdkRHOzs7OztBQVB1Qzs7a0JBQXhCLGdCIiwiZmlsZSI6ImJ1bmRsZXMvcGFnZXMvaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiAoaWdub3JlZCkgKi9cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyB3cyAoaWdub3JlZClcbi8vIG1vZHVsZSBpZCA9IDEwNjFcbi8vIG1vZHVsZSBjaHVua3MgPSA1IiwiaW1wb3J0IHsgY3JlYXRlU3RvcmUsIGFwcGx5TWlkZGxld2FyZSB9IGZyb20gJ3JlZHV4J1xuaW1wb3J0IHRodW5rTWlkZGxld2FyZSBmcm9tICdyZWR1eC10aHVuaydcbmltcG9ydCBvbWl0IGZyb20gJ2xvZGFzaC9vbWl0J1xuXG5jb25zdCBpbml0aWFsU3RhdGUgPSB7XG4gIHVzZXJzOiBudWxsLFxuICBjdXJyZW50VXNlcjogbnVsbCxcbiAgY29ubmVjdGlvbjoge1xuICAgIG1hc3RlcjogdHJ1ZSxcbiAgICBzbGF2ZTogdHJ1ZSxcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgYWN0aW9uVHlwZXMgPSB7XG4gIFNFVF9VU0VSUzogJ1NFVF9VU0VSUycsXG4gIFNFVF9DVVJSRU5UX1VTRVI6ICdTRVRfQ1VSUkVOVF9VU0VSJyxcbiAgREVMRVRFX1VTRVI6ICdERUxFVEVfVVNFUicsXG5cbiAgU0VUX0NPTk5FQ1RJT05fU1RBVFVTOiAnU0VUX0NPTk5FQ1RJT05fU1RBVFVTJyxcbn1cblxuLy8gUkVEVUNFUlNcbmV4cG9ydCBjb25zdCByZWR1Y2VyID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xuICAgIGNhc2UgYWN0aW9uVHlwZXMuU0VUX1VTRVJTOlxuICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIHN0YXRlLCB7IHVzZXJzOiBhY3Rpb24ucGF5bG9hZCB9KVxuICAgIGNhc2UgYWN0aW9uVHlwZXMuU0VUX0NVUlJFTlRfVVNFUjpcbiAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBzdGF0ZSwgeyBjdXJyZW50VXNlcjogYWN0aW9uLnBheWxvYWQgfSlcbiAgICBjYXNlIGFjdGlvblR5cGVzLkRFTEVURV9VU0VSOlxuICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIHN0YXRlLCB7IHVzZXJzOiBvbWl0KHN0YXRlLnVzZXJzLCBbYWN0aW9uLmlkXSkgfSlcblxuICAgIGNhc2UgYWN0aW9uVHlwZXMuU0VUX0NPTk5FQ1RJT05fU1RBVFVTOlxuICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIHN0YXRlLCB7IGNvbm5lY3Rpb246IHsgLi4uc3RhdGUuY29ubmVjdGlvbiwgW2FjdGlvbi5wYXlsb2FkLnR5cGVdOiBhY3Rpb24ucGF5bG9hZC5zdGF0dXMgfSB9KVxuXG4gICAgZGVmYXVsdDogcmV0dXJuIHN0YXRlXG4gIH1cbn1cblxuLy8gQUNUSU9OU1xuZXhwb3J0IGNvbnN0IHNldFVzZXJzID0gcGF5bG9hZCA9PiBkaXNwYXRjaCA9PiBkaXNwYXRjaCh7IHR5cGU6IGFjdGlvblR5cGVzLlNFVF9VU0VSUywgcGF5bG9hZCB9KVxuZXhwb3J0IGNvbnN0IHNldEN1cnJlbnRVc2VyID0gcGF5bG9hZCA9PiBkaXNwYXRjaCA9PiBkaXNwYXRjaCh7IHR5cGU6IGFjdGlvblR5cGVzLlNFVF9DVVJSRU5UX1VTRVIsIHBheWxvYWQgfSlcbmV4cG9ydCBjb25zdCBkZWxldGVVc2VyID0gaWQgPT4gZGlzcGF0Y2ggPT4gZGlzcGF0Y2goeyB0eXBlOiBhY3Rpb25UeXBlcy5ERUxFVEVfVVNFUiwgaWQgfSlcblxuZXhwb3J0IGNvbnN0IHNldENvbm5lY3Rpb25TdGF0dXMgPSAodHlwZSwgc3RhdHVzKSA9PiBkaXNwYXRjaCA9PiBkaXNwYXRjaCh7XG4gIHR5cGU6IGFjdGlvblR5cGVzLlNFVF9DT05ORUNUSU9OX1NUQVRVUyxcbiAgcGF5bG9hZDogeyB0eXBlLCBzdGF0dXMgfVxufSlcblxuZXhwb3J0IGNvbnN0IGluaXRTdG9yZSA9IChpbml0aWFsU3RhdGUgPSBpbml0aWFsU3RhdGUpID0+IHtcbiAgcmV0dXJuIGNyZWF0ZVN0b3JlKHJlZHVjZXIsIGluaXRpYWxTdGF0ZSwgYXBwbHlNaWRkbGV3YXJlKHRodW5rTWlkZGxld2FyZSkpXG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9oZWxwZXJzL3N0b3JlLmpzIiwiaW1wb3J0IFJvdXRlciBmcm9tICduZXh0L3JvdXRlcidcbmltcG9ydCB3aXRoUmVkdXggZnJvbSAnbmV4dC1yZWR1eC13cmFwcGVyJ1xuaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBIZWFkZXIsIEJ1dHRvbiwgTG9hZGVyLCBNZXNzYWdlIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnXG5cbmltcG9ydCBMYXlvdXQgZnJvbSAnLi4vY29tcG9uZW50cy9sYXlvdXQnXG5pbXBvcnQgVHJhaW5pbmdPdmVybGF5IGZyb20gJy4uL2NvbXBvbmVudHMvdHJhaW5pbmctb3ZlcmxheSdcbmltcG9ydCB7IGluaXRTdG9yZSwgc2V0Q3VycmVudFVzZXIgfSBmcm9tICcuLi9oZWxwZXJzL3N0b3JlJ1xuXG5jb25zdCBjYW52YXNTaXplID0geyB3aWR0aDogODAwLCBoZWlnaHQ6IDYwMCB9XG5jb25zdCByZWNvZ25pemluZ0ludGVydmFsVGltZW91dCA9IDc1MFxuY29uc3QgdHJhaW5pbmdQaG90b3NDb3VudCA9IDMwXG5cbmxldCBoaWRlTWVzc2FnZVRpbWVvdXRcbmNvbnN0IGxhc3RVc2VySWQgPSB1c2VycyA9PiBPYmplY3Qua2V5cyh1c2VycykubWFwKGlkID0+IHBhcnNlSW50KGlkKSkuc29ydCgpLnBvcCgpIHx8IDBcblxuY2xhc3MgSG9tZVBhZ2UgZXh0ZW5kcyBDb21wb25lbnQge1xuICBjb25zdHJ1Y3Rvcihwcm9wcykge1xuICAgIHN1cGVyKHByb3BzKVxuXG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIHNob3dBZGRVc2VyQnV0dG9uOiBmYWxzZSxcbiAgICAgIGlzVHJhaW5pbmc6IGZhbHNlLFxuICAgICAgcGVyY2VudGFnZTogMCxcbiAgICAgIHNhdmVkVXNlck5hbWU6IHByb3BzLnVybC5xdWVyeS5zYXZlZCxcbiAgICB9XG4gIH1cblxuICBjb21wb25lbnREaWRNb3VudCAoKSB7XG4gICAgY29uc3QgaXNUcmFpbmluZyA9IHRoaXMucHJvcHMudXJsLnF1ZXJ5LnRyYWluaW5nICE9PSB1bmRlZmluZWRcbiAgICBjb25zdCB7IHNhdmVkVXNlck5hbWUgfSA9IHRoaXMuc3RhdGVcblxuICAgIGlmIChzYXZlZFVzZXJOYW1lKSB7XG4gICAgICBoaWRlTWVzc2FnZVRpbWVvdXQgPSBzZXRUaW1lb3V0KHRoaXMub25EaXNtaXNzTWVzc2FnZSwgNTAwMClcbiAgICB9XG5cbiAgICB0aGlzLnZpZGVvQ29udGV4dCA9IHRoaXMudmlkZW9DYW52YXMuZ2V0Q29udGV4dCgnMmQnKVxuXG4gICAgdGhpcy5vdmVybGF5Q29udGV4dCA9IHRoaXMub3ZlcmxheUNhbnZhcy5nZXRDb250ZXh0KCcyZCcpXG4gICAgdGhpcy5vdmVybGF5Q29udGV4dC5zdHJva2VTdHlsZSA9ICdyZ2IoMCwgMTg0LCAxNzQpJ1xuICAgIHRoaXMub3ZlcmxheUNvbnRleHQubGluZVdpZHRoID0gNFxuICAgIHRoaXMub3ZlcmxheUNvbnRleHQubGluZUNhcCA9ICdyb3VuZCdcbiAgICB0aGlzLm92ZXJsYXlDb250ZXh0LnNldExpbmVEYXNoKFsyLCAxNV0pXG5cbiAgICB3aW5kb3cuc29ja2V0Lm9uKCdmYWNlRGV0ZWN0ZWQnLCB0aGlzLmhhbmRsZUZhY2VEZXRlY3RlZClcbiAgICB3aW5kb3cuc29ja2V0Lm9uKCd1c2VyVHJhaW5uZWQnLCB0aGlzLmhhbmRsZVVzZXJUcmFpbm5lZClcbiAgICB3aW5kb3cuc29ja2V0Lm9uKCdzdGFydC10cmFpbmluZycsICgpID0+IFJvdXRlci5wdXNoKCcvP3RyYWluaW5nPTEnKSlcblxuICAgIGlmICh0aGlzLnZpZGVvICYmIG5hdmlnYXRvci5tZWRpYURldmljZXMgJiYgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXRVc2VyTWVkaWEpIHtcbiAgICAgIG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKHsgdmlkZW86IHRydWUgfSkudGhlbihzdHJlYW0gPT4ge1xuICAgICAgICB0aGlzLmNhbWVyYVN0cmVhbSA9IHN0cmVhbVxuICAgICAgICB0aGlzLnZpZGVvLnNyYyA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKHRoaXMuY2FtZXJhU3RyZWFtKVxuXG4gICAgICAgIHRoaXMudmlkZW8ucGxheSgpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgIGlmICghaXNUcmFpbmluZykge1xuICAgICAgICAgICAgdGhpcy5zdGFydERldGVjdGluZygpXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5OZXdVc2VyKClcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGNvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMobmV4dFByb3BzKSB7XG4gICAgaWYgKCF0aGlzLnByb3BzLnVybC5xdWVyeS50cmFpbmluZyAmJiBuZXh0UHJvcHMudXJsLnF1ZXJ5LnRyYWluaW5nKSB7XG4gICAgICB0aGlzLnRyYWluTmV3VXNlcigpXG4gICAgfVxuICB9XG5cbiAgY29tcG9uZW50V2lsbFVubW91bnQgKCkge1xuICAgIGNsZWFySW50ZXJ2YWwodGhpcy5yZWNvZ25pemluZ0ludGVydmFsKVxuICAgIGNsZWFySW50ZXJ2YWwodGhpcy50cmFpbmluZ0ludGVydmFsKVxuICAgIGNsZWFyVGltZW91dChoaWRlTWVzc2FnZVRpbWVvdXQpXG5cbiAgICBpZiAodGhpcy52aWRlbykge1xuICAgICAgdGhpcy52aWRlby5wYXVzZSgpXG4gICAgICB0aGlzLmNhbWVyYVN0cmVhbS5nZXRUcmFja3MoKVswXS5zdG9wKClcbiAgICB9XG4gIH1cblxuICBvbkRpc21pc3NNZXNzYWdlID0gKCkgPT4ge1xuICAgIHRoaXMuc2V0U3RhdGUoeyBzYXZlZFVzZXJOYW1lOiBudWxsIH0pXG4gIH1cblxuICBkcmF3RmFjZU92ZXJsYXkoeyB4LCB5LCB3aWR0aCwgaGVpZ2h0IH0pIHtcbiAgICB0aGlzLm92ZXJsYXlDb250ZXh0LmJlZ2luUGF0aCgpO1xuICAgIHRoaXMub3ZlcmxheUNvbnRleHQuYXJjKHggKyB3aWR0aCAvIDIsIHkgKyB3aWR0aCAvIDIsIHdpZHRoIC8gMS43LCAwLCBNYXRoLlBJICogMiwgdHJ1ZSk7XG4gICAgdGhpcy5vdmVybGF5Q29udGV4dC5zdHJva2UoKVxuXG4gICAgdGhpcy5sYXN0RmFjZVBvc2l0aW9uID0geyB4LCB5LCB3aWR0aCwgaGVpZ2h0IH1cbiAgfVxuXG4gIGNsZWFyRmFjZU92ZXJsYXkoKSB7XG4gICAgaWYgKHRoaXMubGFzdEZhY2VQb3NpdGlvbikge1xuICAgICAgY29uc3QgeyB4LCB5LCB3aWR0aCB9ID0gdGhpcy5sYXN0RmFjZVBvc2l0aW9uXG5cbiAgICAgIHRoaXMub3ZlcmxheUNvbnRleHQuY2xlYXJSZWN0KFxuICAgICAgICB4IC0gd2lkdGggLyAyLFxuICAgICAgICB5IC0gd2lkdGggLyAyLFxuICAgICAgICB3aWR0aCAqIDIsXG4gICAgICAgIHdpZHRoICogMlxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGhhbmRsZUZhY2VEZXRlY3RlZCA9IGRhdGEgPT4ge1xuICAgIGNvbnN0IHsgZGlzcGF0Y2gsIHVzZXJzLCBjdXJyZW50VXNlciB9ID0gdGhpcy5wcm9wc1xuICAgIGNvbnN0IHsgaXNUcmFpbmluZyB9ID0gdGhpcy5zdGF0ZVxuICAgIGNvbnN0IHsgaWQsIHBvc2l0aW9uLCAuLi51c2VyRGF0YSB9ID0gZGF0YVxuXG4gICAgdGhpcy5jbGVhckZhY2VPdmVybGF5KClcblxuICAgIGlmIChpc1RyYWluaW5nKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cblxuICAgIGlmIChpZCkge1xuICAgICAgaWYgKGN1cnJlbnRVc2VyICYmIGN1cnJlbnRVc2VyLmlkID09PSBpZCkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgdGhpcy5zZXRTdGF0ZSh7IHNob3dBZGRVc2VyQnV0dG9uOiBmYWxzZSB9KVxuXG4gICAgICBkaXNwYXRjaChzZXRDdXJyZW50VXNlcih7IGlkLCAuLi51c2VyRGF0YSB9KSlcblxuICAgICAgd2luZG93LnNvY2tldC5lbWl0KCd1cGRhdGUtc2V0dGluZ3MnLCB1c2VyRGF0YS5zZXR0aW5ncylcbiAgICB9IGVsc2UgaWYgKHBvc2l0aW9uKSB7XG4gICAgICB0aGlzLmRyYXdGYWNlT3ZlcmxheShwb3NpdGlvbilcblxuICAgICAgdGhpcy5zZXRTdGF0ZSh7IHNob3dBZGRVc2VyQnV0dG9uOiB0cnVlIH0pXG4gICAgfVxuICB9XG5cbiAgc3RhcnREZXRlY3RpbmcgPSAoKSA9PiB7XG4gICAgdGhpcy5yZWNvZ25pemluZ0ludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgdGhpcy52aWRlb0NvbnRleHQuZHJhd0ltYWdlKHRoaXMudmlkZW8sIDAsIDAsIGNhbnZhc1NpemUud2lkdGgsIGNhbnZhc1NpemUuaGVpZ2h0KVxuXG4gICAgICB3aW5kb3cuc29ja2V0LmVtaXQoJ3JlY29nbml6ZUZhY2UnLCB0aGlzLnZpZGVvQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDEpKVxuICAgIH0sIHJlY29nbml6aW5nSW50ZXJ2YWxUaW1lb3V0KVxuICB9XG5cbiAgdHJhaW5OZXdVc2VyID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgdXNlcnMgfSA9IHRoaXMucHJvcHNcblxuICAgIGNsZWFySW50ZXJ2YWwodGhpcy5yZWNvZ25pemluZ0ludGVydmFsKVxuICAgIGNsZWFySW50ZXJ2YWwodGhpcy50cmFpbmluZ0ludGVydmFsKVxuXG4gICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICBzaG93QWRkVXNlckJ1dHRvbjogZmFsc2UsXG4gICAgICB0cmFpbmluZ1Bob3RvSW5kZXg6IDAsXG4gICAgICBpc1RyYWluaW5nOiB0cnVlLFxuICAgIH0pXG5cbiAgICBjb25zdCBuZXdVc2VySWQgPSBsYXN0VXNlcklkKHVzZXJzKSArIDFcblxuICAgIHdpbmRvdy5zb2NrZXQuZW1pdChgcmVtb3ZlVXNlcmAsIG5ld1VzZXJJZClcblxuICAgIHRoaXMudHJhaW5pbmdJbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyB0cmFpbmluZ1Bob3RvSW5kZXg6IHRoaXMuc3RhdGUudHJhaW5pbmdQaG90b0luZGV4ICsgMSB9LCAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLnRyYWluaW5nUGhvdG9JbmRleCA+PSB0cmFpbmluZ1Bob3Rvc0NvdW50KSB7XG4gICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLnRyYWluaW5nSW50ZXJ2YWwpXG5cbiAgICAgICAgICB3aW5kb3cuc29ja2V0LmVtaXQoYHRyYWluVXNlcmAsIG5ld1VzZXJJZClcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnZpZGVvQ29udGV4dC5kcmF3SW1hZ2UodGhpcy52aWRlbywgMCwgMCwgY2FudmFzU2l6ZS53aWR0aCwgY2FudmFzU2l6ZS5oZWlnaHQpXG5cbiAgICAgICAgICB3aW5kb3cuc29ja2V0LmVtaXQoXG4gICAgICAgICAgICBgc2F2ZVVzZXJQaG90b2AsXG4gICAgICAgICAgICB0aGlzLnZpZGVvQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDEpLFxuICAgICAgICAgICAgbmV3VXNlcklkLFxuICAgICAgICAgICAgdGhpcy5zdGF0ZS50cmFpbmluZ1Bob3RvSW5kZXhcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSwgMTAwKVxuICB9XG5cbiAgY2FuY2VsdHJhaW5pbmcgPSAoKSA9PiB7XG4gICAgY29uc3QgeyB1c2VycyB9ID0gdGhpcy5wcm9wc1xuXG4gICAgY2xlYXJJbnRlcnZhbCh0aGlzLnRyYWluaW5nSW50ZXJ2YWwpXG5cbiAgICBjb25zdCB1c2VySWQgPSBsYXN0VXNlcklkKHVzZXJzKSArIDFcblxuICAgIHdpbmRvdy5zb2NrZXQuZW1pdChgcmVtb3ZlVXNlcmAsIHVzZXJJZClcblxuICAgIHRoaXMuc2V0U3RhdGUoeyBpc1RyYWluaW5nOiBmYWxzZSwgdHJhaW5pbmdQaG90b0luZGV4OiAwIH0pXG4gICAgdGhpcy5zdGFydERldGVjdGluZygpXG4gIH1cblxuICBoYW5kbGVVc2VyVHJhaW5uZWQgPSBpZCA9PiB7XG4gICAgUm91dGVyLnB1c2goYC9wcm9maWxlP2lkPSR7aWR9JmlzTmV3PTFgKVxuICB9XG5cbiAgcmVuZGVyICgpIHtcbiAgICBjb25zdCB7IHNhdmVkVXNlck5hbWUsIHNob3dBZGRVc2VyQnV0dG9uLCBpc1RyYWluaW5nLCB0cmFpbmluZ1Bob3RvSW5kZXggfSA9IHRoaXMuc3RhdGVcblxuICAgIHJldHVybiAoXG4gICAgICA8TGF5b3V0IGhpZGVIZWFkZXI9eyBpc1RyYWluaW5nIH0gaGlkZUZvb3Rlcj17IGlzVHJhaW5pbmcgfT5cbiAgICAgICAge3NhdmVkVXNlck5hbWVcbiAgICAgICAgICA/IDxNZXNzYWdlXG4gICAgICAgICAgICBvbkRpc21pc3M9e3RoaXMub25EaXNtaXNzTWVzc2FnZX1cbiAgICAgICAgICAgIGhlYWRlcj17YFBlcmZpbCBcIiR7c2F2ZWRVc2VyTmFtZX1cIiBzYWx2byBjb20gc3VjZXNzby5gfVxuICAgICAgICAgICAgb25DbGljaz17dGhpcy5vbkRpc21pc3NNZXNzYWdlfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgOiAnJ1xuICAgICAgICB9XG5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8TG9hZGVyIGFjdGl2ZSBpbnZlcnRlZCBzaXplPVwibWFzc2l2ZVwiIC8+XG5cbiAgICAgICAgICA8dmlkZW9cbiAgICAgICAgICAgIHJlZj17ZWwgPT4gdGhpcy52aWRlbyA9IGVsfVxuICAgICAgICAgICAgd2lkdGg9e2NhbnZhc1NpemUud2lkdGh9XG4gICAgICAgICAgICBoZWlnaHQ9e2NhbnZhc1NpemUuaGVpZ2h0fVxuICAgICAgICAgICAgYXV0b1BsYXlcbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgPGNhbnZhc1xuICAgICAgICAgICAgcmVmPXtlbCA9PiB0aGlzLnZpZGVvQ2FudmFzID0gZWx9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ2aWRlb0NhbnZhc1wiXG4gICAgICAgICAgICB3aWR0aD17Y2FudmFzU2l6ZS53aWR0aH1cbiAgICAgICAgICAgIGhlaWdodD17Y2FudmFzU2l6ZS5oZWlnaHR9XG4gICAgICAgICAgLz5cblxuICAgICAgICAgIDxjYW52YXNcbiAgICAgICAgICAgIHJlZj17ZWwgPT4gdGhpcy5vdmVybGF5Q2FudmFzID0gZWx9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BvdmVybGF5Q2FudmFzICR7aXNUcmFpbmluZyA/ICdoaWRkZW4nIDogJyd9YH1cbiAgICAgICAgICAgIHdpZHRoPXtjYW52YXNTaXplLndpZHRofVxuICAgICAgICAgICAgaGVpZ2h0PXtjYW52YXNTaXplLmhlaWdodH1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgeyBpc1RyYWluaW5nXG4gICAgICAgICAgICA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0cmFpbmluZy1jb250YWluZXJcIj5cbiAgICAgICAgICAgICAgICA8VHJhaW5pbmdPdmVybGF5IHBlcmNlbnRhZ2U9e01hdGgucm91bmQodHJhaW5pbmdQaG90b0luZGV4IC8gdHJhaW5pbmdQaG90b3NDb3VudCAqIDEwMCl9IC8+XG5cbiAgICAgICAgICAgICAgICB7dHJhaW5pbmdQaG90b0luZGV4IDwgdHJhaW5pbmdQaG90b3NDb3VudFxuICAgICAgICAgICAgICAgICAgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBiYXNpYyBpbnZlcnRlZCBvbkNsaWNrPXt0aGlzLmNhbmNlbHRyYWluaW5nfT5DYW5jZWxhcjwvQnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgPEhlYWRlciBhcz1cImgxXCIgdGV4dEFsaWduPVwiY2VudGVyXCI+Q3JpYcOnw6NvIGRlIHBlcmZpbCBlbSBwcm9ncmVzc28uLi48L0hlYWRlcj5cbiAgICAgICAgICAgICAgICAgICAgICA8SGVhZGVyIGFzPVwiaDNcIiB0ZXh0QWxpZ249XCJjZW50ZXJcIj5BZ3VhcmRlIGVucXVhbnRvIG1vdmltZW50YSBhIGNhYmXDp2E8L0hlYWRlcj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICA6IG51bGxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgOiBudWxsXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgeyBzaG93QWRkVXNlckJ1dHRvblxuICAgICAgICAgICAgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnV0dG9uc1wiPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIGNvbnRlbnQ9XCJBZGljaW9uYXIgUGVyZmlsXCJcbiAgICAgICAgICAgICAgICAgIGljb249XCJhZGQgdXNlclwiXG4gICAgICAgICAgICAgICAgICBsYWJlbFBvc2l0aW9uPVwibGVmdFwiXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cInRlYWxcIlxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImJpZ1wiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLnRyYWluTmV3VXNlcn1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIDogbnVsbFxuICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIDpnbG9iYWwoLnVpLm1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgICAgICAgICBsZWZ0OiAyMHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgcmlnaHQ6IDIwcHg7XG4gICAgICAgICAgICB0b3A6IDIwcHg7XG4gICAgICAgICAgICB6LWluZGV4OiAxMDAwMDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBkaXYgOmdsb2JhbCgudWkubG9hZGVyKSB7XG4gICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgIG1hcmdpbjogLS41ZW0gMCAwIC0uNWVtO1xuICAgICAgICAgICAgei1pbmRleDogMDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAudmlkZW9DYW52YXMge1xuICAgICAgICAgICAgbGVmdDogLTEwMDAwMHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAtMTAwMDAwcHg7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLm92ZXJsYXlDYW52YXMsXG4gICAgICAgICAgdmlkZW8ge1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHRvcDogMDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAub3ZlcmxheUNhbnZhcyB7XG4gICAgICAgICAgICB6LWluZGV4OiAyO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5oaWRkZW4ge1xuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAuYnV0dG9ucyB7XG4gICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICBib3R0b206IDQwcHg7XG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XG4gICAgICAgICAgICB6LWluZGV4OiAzO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC50cmFpbmluZy1jb250YWluZXIge1xuICAgICAgICAgICAgJiBkaXYge1xuICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogNDBweDtcbiAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICAgIGJvdHRvbTogMDtcbiAgICAgICAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgICAgICAgIHotaW5kZXg6IDQ7XG5cbiAgICAgICAgICAgICAgJiA6Z2xvYmFsKC51aS5oZWFkZXIpIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDhweCAwIDAgMDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmIDpnbG9iYWwoLnVpLmJ1dHRvbikge1xuICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgIHRvcDogNjBweDtcbiAgICAgICAgICAgICAgcmlnaHQ6IDYwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICA8L0xheW91dD5cbiAgICApXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgd2l0aFJlZHV4KGluaXRTdG9yZSwgc3RhdGUgPT4gc3RhdGUpKEhvbWVQYWdlKVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vcGFnZXM/ZW50cnkiLCJpbXBvcnQgd2l0aFJlZHV4IGZyb20gJ25leHQtcmVkdXgtd3JhcHBlcidcbmltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHsgSWNvbiB9IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuXG5pbXBvcnQgeyBpbml0U3RvcmUsIHNldENvbm5lY3Rpb25TdGF0dXMgfSBmcm9tICcuLi9oZWxwZXJzL3N0b3JlJ1xuXG5jbGFzcyBGb290ZXIgZXh0ZW5kcyBDb21wb25lbnQge1xuICBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICBjb25zdCB7IGRpc3BhdGNoIH0gPSB0aGlzLnByb3BzXG5cbiAgICB3aW5kb3cuc29ja2V0Lm9uKCdjb25uZWN0aW9uLXN0YXR1cycsIChkYXRhKSA9PiB7XG4gICAgICBkaXNwYXRjaChzZXRDb25uZWN0aW9uU3RhdHVzKGRhdGEudHlwZSwgZGF0YS5zdGF0dXMpKVxuICAgIH0pXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBjb25uZWN0aW9uID0ge30gfSA9IHRoaXMucHJvcHM7XG5cbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPGZvb3Rlcj5cbiAgICAgICAgICA8c3Bhbj48SWNvbiBuYW1lPVwiY2lyY2xlXCIgc2l6ZT1cInNtYWxsXCIgY29sb3I9eyBjb25uZWN0aW9uLm1hc3RlciA/ICdncmVlbicgOiAncmVkJyB9IC8+IE1hc3Rlcjwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj48SWNvbiBuYW1lPVwiY2lyY2xlXCIgc2l6ZT1cInNtYWxsXCIgY29sb3I9eyBjb25uZWN0aW9uLnNsYXZlID8gJ2dyZWVuJyA6ICdyZWQnIH0gLz4gU2xhdmU8L3NwYW4+XG4gICAgICAgIDwvZm9vdGVyPlxuXG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICBmb290ZXIge1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgLjYpO1xuICAgICAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICAgICAgYm90dG9tOiAwO1xuICAgICAgICAgICAgei1pbmRleDogMTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBzcGFuICsgc3BhbiB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICB9XG4gICAgICAgIGB9PC9zdHlsZT5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCB3aXRoUmVkdXgoaW5pdFN0b3JlLCBzdGF0ZSA9PiBzdGF0ZSwgZGlzcGF0Y2ggPT4gKHsgZGlzcGF0Y2ggfSkpKEZvb3RlcilcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL2NvbXBvbmVudHMvZm9vdGVyLmpzIiwiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgeyBJY29uLCBIZWFkZXIgYXMgSCB9IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xuXG5jb25zdCBnZXRUaW1lID0gKCkgPT4ge1xuICBjb25zdCBvcHRpb25zID0ge1xuICAgIGhvdXI6ICdudW1lcmljJyxcbiAgICBtaW51dGU6ICdudW1lcmljJyxcbiAgfVxuXG4gIHJldHVybiBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCgncHQtUFQnLCBvcHRpb25zKS5mb3JtYXQobmV3IERhdGUoKSlcbn1cblxuY2xhc3MgSGVhZGVyIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgc3RhdGUgPSB7XG4gICAgdGltZTogZ2V0VGltZSgpLFxuICB9XG5cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgdGhpcy5pbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHRoaXMuc2V0U3RhdGUoeyB0aW1lOiBnZXRUaW1lKCkgfSksIDEwMDApXG4gIH1cblxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWwpXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyBjdXJyZW50VXNlciwgY2xhc3NlcyB9ID0gdGhpcy5wcm9wc1xuICAgIGNvbnN0IHsgdGltZSB9ID0gdGhpcy5zdGF0ZVxuXG4gICAgaWYgKCFjdXJyZW50VXNlcikge1xuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2PlxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwic2lnbmFsXCIgLz5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJibHVldG9vdGggYWx0ZXJuYXRpdmVcIiAvPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImNsb2NrXCIgLz5cbiAgICAgICAgICAgIDxIIGFzPVwiaDRcIj57dGltZX08L0g+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgeyBjdXJyZW50VXNlclxuICAgICAgICAgICAgICA/IDxIIGFzPVwiaDRcIj57Y3VycmVudFVzZXIubmFtZX08L0g+XG4gICAgICAgICAgICAgIDogbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2VsZWN0LXByb2ZpbGVcIj5cbiAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwidWkgYnV0dG9uIGljb24gYmFzaWMgaW52ZXJ0ZWQgcHJvZmlsZXMtYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgUGVyZmlzIDxJY29uIG5hbWU9XCJyaWdodCBhcnJvd1wiIC8+XG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9oZWFkZXI+XG5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIGhlYWRlciB7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgzNCwgMzksIDUzLCAuNik7XG4gICAgICAgICAgICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAuNik7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgMCAwIDEwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIHRvcDogMDtcbiAgICAgICAgICAgIHotaW5kZXg6IDEwMDA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLmNvbnRhaW5lciA6Z2xvYmFsKC51aS5iYXNpYy5idXR0b24ucHJvZmlsZXMtYnV0dG9uKSB7XG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLmNvbnRhaW5lciA6Z2xvYmFsKC51aS5iYXNpYy5idXR0b24ucHJvZmlsZXMtYnV0dG9uKSA6Z2xvYmFsKC5pY29uKSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZGl2IHtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuXG4gICAgICAgICAgICAmIDpudGgtY2hpbGQoMikge1xuICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGhlYWRlciA6Z2xvYmFsKC5pY29uKSB7XG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBoZWFkZXIgOmdsb2JhbCgudWkuaGVhZGVyKSB7XG4gICAgICAgICAgICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAuNik7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChzdGF0ZSA9PiBzdGF0ZSkoSGVhZGVyKVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vY29tcG9uZW50cy9oZWFkZXIuanMiLCJpbXBvcnQgaW8gZnJvbSAnc29ja2V0LmlvLWNsaWVudCdcblxuaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXG5pbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy1mZXRjaCdcblxuaW1wb3J0IEhlYWRlciBmcm9tICcuLi9jb21wb25lbnRzL2hlYWRlcidcbmltcG9ydCBGb290ZXIgZnJvbSAnLi4vY29tcG9uZW50cy9mb290ZXInXG5pbXBvcnQgeyBzZXRVc2VycyB9IGZyb20gJy4uL2hlbHBlcnMvc3RvcmUnXG5cbmNsYXNzIExheW91dCBleHRlbmRzIENvbXBvbmVudCB7XG4gIGNvbXBvbmVudFdpbGxNb3VudCgpIHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgIXdpbmRvdy5zb2NrZXQpIHtcbiAgICAgIHdpbmRvdy5zb2NrZXQgPSBpbyh3aW5kb3cubG9jYXRpb24ub3JpZ2luKVxuICAgIH1cblxuICAgIGNvbnN0IHsgZGlzcGF0Y2gsIHVzZXJzIH0gPSB0aGlzLnByb3BzXG5cbiAgICBpZiAoIXVzZXJzICYmIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBmZXRjaChgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufS91c2Vyc2ApXG4gICAgICAgIC50aGVuKHJlcyA9PiByZXMuanNvbigpKVxuICAgICAgICAudGhlbih1c2VycyA9PiBkaXNwYXRjaChzZXRVc2Vycyh1c2VycykpKVxuICAgIH1cbiAgfVxuXG4gIHJlbmRlciAoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxtYWluPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICAgIHt0aGlzLnByb3BzLmNoaWxkcmVufVxuXG4gICAgICAgICAgeyAhdGhpcy5wcm9wcy5oaWRlSGVhZGVyICYmIDxIZWFkZXIgLz4gfVxuICAgICAgICAgIHsgIXRoaXMucHJvcHMuaGlkZUZvb3RlciAmJiA8Rm9vdGVyIC8+IH1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIC5jb250YWluZXIge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogIzJlMzQ0NTtcbiAgICAgICAgICAgIGhlaWdodDogNjAwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB3aWR0aDogODAwcHg7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICA8L21haW4+XG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3Qoc3RhdGUgPT4gc3RhdGUsIGRpc3BhdGNoID0+ICh7IGRpc3BhdGNoIH0pKShMYXlvdXQpXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9jb21wb25lbnRzL2xheW91dC5qcyIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgSWNvbiB9IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBUcmFpbmluZ092ZXJsYXkgZXh0ZW5kcyBDb21wb25lbnQge1xuICByZW5kZXIgKCkge1xuICAgIGNvbnN0IHsgcGVyY2VudGFnZSB9ID0gdGhpcy5wcm9wc1xuXG4gICAgY29uc3QgZGFzaE9mZnNldCA9IE1hdGgubWF4KDAsIDEyNjAgLSAocGVyY2VudGFnZSAqIDEyNjAgLyAxMDApKVxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgIDxJY29uIG5hbWU9XCJjaGVja21hcmtcIiBzaXplPVwiaHVnZVwiIGNsYXNzTmFtZT17cGVyY2VudGFnZSA+PSAxMDAgPyAndmlzaWJsZScgOiAnJ30gLz5cblxuICAgICAgICA8c3ZnIHdpZHRoPVwiODAwXCIgaGVpZ2h0PVwiNjAwXCI+XG4gICAgICAgICAgPGRlZnM+XG4gICAgICAgICAgICA8bWFzayBpZD1cIm1hc2tcIj5cbiAgICAgICAgICAgICAgPHJlY3QgeT1cIjBcIiB3aWR0aD1cIjgwMFwiIGhlaWdodD1cIjYwMFwiIGZpbGw9XCJ3aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCI0MDBcIiBjeT1cIjMwMFwiIHI9XCIxNzVcIiBmaWxsPVwiYmxhY2tcIiAvPlxuICAgICAgICAgICAgPC9tYXNrPlxuICAgICAgICAgIDwvZGVmcz5cblxuICAgICAgICAgIDxyZWN0IGZpbGw9XCJibGFja1wiIHdpZHRoPVwiODAwXCIgaGVpZ2h0PVwiNjAwXCIgbWFzaz17cGVyY2VudGFnZSA+PSAxMDAgPyBudWxsIDogJ3VybCgjbWFzayknfSBmaWxsPVwicmdiKDQ2LCA1MiwgNjkpXCIgZmlsbE9wYWNpdHk9XCIuOVwiIC8+XG5cbiAgICAgICAgICA8Y2lyY2xlXG4gICAgICAgICAgICBjeD1cIjQwMFwiXG4gICAgICAgICAgICBjeT1cIjMwMFwiXG4gICAgICAgICAgICByPVwiMTc1XCJcbiAgICAgICAgICAgIGZpbGw9XCJ0cmFuc3BhcmVudFwiXG4gICAgICAgICAgICBzdHJva2VEYXNob2Zmc2V0PXtkYXNoT2Zmc2V0fVxuICAgICAgICAgICAgdHJhbnNmb3JtPVwicm90YXRlKC05MCA0MDAgMzAwKVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9zdmc+XG5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIC5jb250YWluZXIge1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHRvcDogMDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAuY29udGFpbmVyIDpnbG9iYWwoLmljb24pIHtcbiAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpIHNjYWxlKDApO1xuICAgICAgICAgICAgY29sb3I6ICMxY2I1YWM7XG4gICAgICAgICAgICB0cmFuc2l0aW9uOiBhbGwgLjE1cyBjdWJpYy1iZXppZXIoLjE3NSwgLjg4NSwgLjMyMCwgMS4yNzUpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5jb250YWluZXIgOmdsb2JhbCguaWNvbi52aXNpYmxlKSB7XG4gICAgICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgc2NhbGUoMSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgc3ZnID4gY2lyY2xlIHtcbiAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAuMXMgZWFzZS1pbi1vdXQ7XG4gICAgICAgICAgICBzdHJva2U6ICMxY2I1YWM7XG4gICAgICAgICAgICBzdHJva2Utd2lkdGg6IDU7XG4gICAgICAgICAgICBzdHJva2UtZGFzaGFycmF5OiAxMjYwO1xuICAgICAgICAgICAgc3Ryb2tlLWxpbmVjYXA6IHJvdW5kO1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9jb21wb25lbnRzL3RyYWluaW5nLW92ZXJsYXkuanMiXSwic291cmNlUm9vdCI6IiJ9
            return { page: comp.default }
          })
        